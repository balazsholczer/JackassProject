package com.balazsholczer.adapter;

import com.balazsholczer.android.R;

import android.view.View;
import android.widget.TextView;


public class ViewHolder {

	private TextView currencyNameId;
	private TextView currencyRate;

	ViewHolder(View view) {
		currencyNameId = (TextView) view.findViewById(R.id.firmNameTextView);
		currencyRate = (TextView) view
				.findViewById(R.id.firmIdentifierTextView);
	}

	public TextView getFirmName() {
		return currencyNameId;
	}

	public void setFirmName(TextView firmName) {
		this.currencyNameId = firmName;
	}

	public TextView getFirmIdentifier() {
		return currencyRate;
	}

	public void setFirmIdentifier(TextView firmIdentifier) {
		this.currencyRate = firmIdentifier;
	}
}
