package com.balazsholczer.adapter;

import java.util.List;

import com.balazsholczer.android.R;
import com.balazsholczer.model.Currency;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;


public class CurrencyAdapter extends BaseAdapter {

    private List<Currency> currencies;
    private Context context;
    
    public CurrencyAdapter(Context context,List<Currency> currencies){        
        this.context=context;    
        this.currencies=currencies;             
    }
    
    public void refreshCurrencies(List<Currency> currencyList){
    	this.currencies=currencyList;
    	notifyDataSetChanged();
    }
    
    @Override
    public int getCount() {      
        return currencies.size();
    }

    @Override
    public Object getItem(int position) {      
        return currencies.get(position);
    }

    @Override
    public long getItemId(int position) {      
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {  // itt is hasznalhato a viewholder pattern ami 175%os hatekonysagnovelest jelent
     
        View row = convertView;
        ViewHolder holder = null;
        
        if( row == null ){
            LayoutInflater layoutInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);           
            row = layoutInflater.inflate(R.layout.list_item, parent,false);         
            holder = new ViewHolder(row);
            row.setTag(holder);
        }else{
            holder = (ViewHolder) row.getTag();
        }
        
        Currency currencyTemp = currencies.get(position);
        holder.getFirmName().setText(currencyTemp.getCurrencySymbol());
        holder.getFirmIdentifier().setText("Currency: "+currencyTemp.getCurrencySymbol()+"\t\tUnit: "+currencyTemp.getUnit());
        holder.getFirmName().setTag(currencyTemp.getCurrencySymbol());
        
        return row;
    }
}