package com.balazsholczer.model;

public class Currency {

	private String currencySymbol;
	private String unit;
	private String rate;

	public Currency() {

	}

	public Currency(String currencySymbol, String unit, String rate) {
		this.currencySymbol = currencySymbol;
		this.unit = unit;
		this.rate = rate;
	}

	public String getCurrencySymbol() {
		return currencySymbol;
	}

	public void setCurrencySymbol(String currencySymbol) {
		this.currencySymbol = currencySymbol;
	}

	public String getUnit() {
		return unit;
	}

	public void setUnit(String unit) {
		this.unit = unit;
	}

	public String getRate() {
		return rate;
	}

	public void setRate(String rate) {
		this.rate = rate;
	}
}
