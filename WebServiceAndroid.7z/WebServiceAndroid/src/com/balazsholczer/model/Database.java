package com.balazsholczer.model;

public class Database {

	private static String xmlString;

	public static String getXmlString() {
		return xmlString;
	}

	public static void setXmlString(String xml) {
		xmlString = xml;
	}
}
