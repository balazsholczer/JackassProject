package com.balazsholczer.callbacks;

public interface ServiceObserver {
	public void downloadStarted();
	public void downloadEnded();
}
