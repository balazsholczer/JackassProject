package com.balazsholczer.services;

import java.util.ArrayList;

import org.ksoap2.SoapEnvelope;
import org.ksoap2.serialization.SoapObject;
import org.ksoap2.serialization.SoapPrimitive;
import org.ksoap2.serialization.SoapSerializationEnvelope;
import org.ksoap2.transport.HttpTransportSE;

import android.app.ProgressDialog;
import android.app.Service;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Binder;
import android.os.Bundle;
import android.os.IBinder;
import android.util.Log;

import com.balazsholczer.android.Constants;
import com.balazsholczer.android.util.CurrencyHelper;
import com.balazsholczer.callbacks.ServiceObserver;
import com.balazsholczer.model.Currency;
import com.balazsholczer.model.Database;

public class CurrencyService extends Service {

	private String resultCurrenciesXml;
	private ArrayList<Currency> currencyList;
	private volatile boolean running = true;
	
	public CurrencyService(){
	}
	
	public class MyBinderClass extends Binder {
		public CurrencyService getService() {
			return CurrencyService.this;
		}
	}

	@Override
	public void onCreate() {	
		new Thread(new Runnable() {
			public void run() {				
				while (running) {
					try {										
						startDownloading();
						Thread.sleep(60*1000*60*24);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
			}
		}).start();
	}

	@Override
	public int onStartCommand(Intent intent, int flags, int startId) {
		return START_STICKY;
	}

	private class DwonloadService extends AsyncTask<Void, Void, Void> {
		
		@Override
		protected Void doInBackground(Void... params) {
			downloadCurrencies();
			return null;
		}

		@Override
		protected void onPostExecute(Void result) {
			parseXml(resultCurrenciesXml);
			sendData();		
		}
	}

	public void parseXml(String xml) {
		currencyList = CurrencyHelper.getCurrenciesFromWebService(xml);
		Database.setXmlString(xml);
	}

	public void downloadCurrencies() {

		SoapObject request = new SoapObject(Constants.NAMESPACE,Constants.METHOD_NAME);
		SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
		envelope.dotNet = true;
		envelope.setOutputSoapObject(request);
		HttpTransportSE androidHttpTransport = new HttpTransportSE(Constants.URL);

		try {
			androidHttpTransport.call(Constants.SOAP_ACTION, envelope);
			SoapPrimitive response = (SoapPrimitive) envelope.getResponse();
			resultCurrenciesXml = response.toString();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void startDownloading() {
		DwonloadService downloadTask = new DwonloadService();
		downloadTask.execute();	
	}

	private void sendData() {
		Intent intent = new Intent(Constants.FILTER_FOR_SERVICE);	
		sendBroadcast(intent);
	}

	@Override
	public IBinder onBind(Intent intent) {
		return new MyBinderClass();
	}
	
	@Override
	public void onDestroy() { // ez akkor hivodik meg amikor a main activityben a destroyban a stopService() meghivodik
		running=false;
		stopSelf();
		super.onDestroy();
	}
}
