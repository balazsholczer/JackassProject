package com.balazsholczer.fragments;

import java.util.Random;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.balazsholczer.android.Constants;
import com.balazsholczer.android.R;
import com.balazsholczer.model.Currency;
import com.jjoe64.graphview.GraphView;
import com.jjoe64.graphview.GraphView.GraphViewData;
import com.jjoe64.graphview.GraphViewSeries;
import com.jjoe64.graphview.LineGraphView;

public class SingleCurrencyFragment extends Fragment {

	private TextView countrySymbolTextView;
	private TextView rateTextView;
	private TextView unitTextView;

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {

		View view = inflater.inflate(R.layout.single_currency_fragment,
				container, false);

		countrySymbolTextView = (TextView) view
				.findViewById(R.id.countrySymbolTextView);
		rateTextView = (TextView) view.findViewById(R.id.rateTextView);
		unitTextView = (TextView) view.findViewById(R.id.unitTextView);

		Bundle bundle = getArguments();
		Currency currentCurrency = (Currency) bundle
				.get(Constants.KEY_DATA_FRAGMENTS);

		countrySymbolTextView.setText(currentCurrency.getCurrencySymbol());
		rateTextView.setText(currentCurrency.getRate() + " HUF ");
		unitTextView.setText(currentCurrency.getUnit());

		setupGraph(view);

		return view;
	}

	private void setupGraph(View view) {
		
		GraphViewData[] data = new GraphViewData[1000];
		Random random = new Random();
		
		double v = 0;
		for (int i = 0; i < 1000; i++) {
			v += 0.1;
			data[i] = new GraphViewData(i, Math.sin(v));
		}
		
		int coordinateY = 0;
		for (int i = 0; i < 1000; i++) {
			if( random.nextInt(100) >= 50 ){
				coordinateY--;
			}else{
				coordinateY++;
			}
			
			data[i] = new GraphViewData(i, coordinateY);
	
		}
		
		GraphViewSeries randomWalkSeries = new GraphViewSeries("Stock Volatility", null, data);
		GraphView graphView = new LineGraphView(getActivity(), "Volatility");
		graphView.addSeries(randomWalkSeries);
		graphView.setViewPort(0, 1000);
		
		graphView.setScalable(true);
		graphView.setShowLegend(true);

		LinearLayout layout = (LinearLayout) view.findViewById(R.id.subLayout);
		layout.addView(graphView);
	}
}
