package com.balazsholczer.fragments;

import java.util.ArrayList;
import java.util.List;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.provider.Settings;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListView;
import android.widget.Toast;

import com.balazsholczer.adapter.CurrencyAdapter;
import com.balazsholczer.android.Constants;
import com.balazsholczer.android.R;
import com.balazsholczer.android.util.CurrencyHelper;
import com.balazsholczer.model.Currency;
import com.balazsholczer.model.Database;
import com.balazsholczer.services.CurrencyService;

public class CurrenciesListFragment extends Fragment {

	private ListView currencyListView;
	private List<Currency> currencyList;
	private CurrencyAdapter currencyAdapter;
	
	public View onCreateView(android.view.LayoutInflater inflater,android.view.ViewGroup container, Bundle savedInstanceState) {
		super.onCreateView(inflater, container, savedInstanceState);
		
		View view = inflater.inflate(R.layout.list_currencies_fragment,container, false);
		currencyListView = (ListView) view.findViewById(R.id.stockListView);

		currencyListView.setOnItemClickListener(new OnItemClickListener() {
			public void onItemClick(AdapterView<?> parent, View view,int position, long id) {
				Toast.makeText(getActivity(),"ID: " + currencyList.get(position).getCurrencySymbol(),Toast.LENGTH_SHORT).show();
				
				Bundle bundle = new Bundle();
				bundle.putSerializable(Constants.KEY_DATA_FRAGMENTS, currencyList.get(position));
				SingleCurrencyFragment singleCurrencyFragment = new SingleCurrencyFragment();
				singleCurrencyFragment.setArguments(bundle);
				
				getFragmentManager().beginTransaction().addToBackStack(null).replace(R.id.fragmentContainer,singleCurrencyFragment).commit();
			}
		});
		
		currencyListSetup();
		checkInternetConnection();
		updateListData();

		return view;
	};

	private void checkInternetConnection() {
		ConnectivityManager connectionManager = (ConnectivityManager) getActivity().getSystemService(Context.CONNECTIVITY_SERVICE);
		NetworkInfo networkInfo = connectionManager.getActiveNetworkInfo();

		if (networkInfo == null) {
			startActivity(new Intent(Settings.ACTION_WIFI_SETTINGS));
		}
	}

	private void currencyListSetup() {
		currencyList = new ArrayList<>();
		currencyAdapter = new CurrencyAdapter(getActivity(), currencyList);
		currencyListView.setAdapter(currencyAdapter);
	}

	public void updateListData() {
		
		if( Database.getXmlString() != null ){
			this.currencyList = CurrencyHelper.getCurrenciesFromWebService(Database.getXmlString());
		}
			
		this.currencyAdapter.refreshCurrencies(currencyList);
	}
}
