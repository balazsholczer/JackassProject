package com.balazsholczer.android;

import java.util.ArrayList;
import java.util.List;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.provider.Settings;
import android.support.v4.app.FragmentActivity;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListView;
import android.widget.Toast;

import com.balazsholczer.adapter.CurrencyAdapter;
import com.balazsholczer.callbacks.ServiceObserver;
import com.balazsholczer.fragments.CurrenciesListFragment;
import com.balazsholczer.fragments.SingleCurrencyFragment;
import com.balazsholczer.model.Currency;
import com.balazsholczer.services.CurrencyService;

public class MainActivity extends FragmentActivity{

	private Intent intent;
	private CurrenciesListFragment currenciesListFragment;
	
	private BroadcastReceiver myBroadcastReceiver = new BroadcastReceiver() {
		public void onReceive(Context context, Intent intent) {
			Toast.makeText(MainActivity.this,"Refreshing...", Toast.LENGTH_SHORT).show();
			currenciesListFragment.updateListData();
		}
	};
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.fragment_container);
		
		currenciesListFragment = new CurrenciesListFragment();	
		getSupportFragmentManager().beginTransaction().add(R.id.fragmentContainer, currenciesListFragment).commit();
		
		startService();
		
	}
	
	public void startService() {
		intent = new Intent(this, CurrencyService.class);
		startService(intent);
	}
	
	@Override
	public void onStart() {
		super.onResume();
		IntentFilter intentFilter = new IntentFilter(Constants.FILTER_FOR_SERVICE);
		registerReceiver(myBroadcastReceiver, intentFilter);
	}

	@Override
	public void onDestroy() {
		super.onPause();
		unregisterReceiver(myBroadcastReceiver);
		stopService(intent); // ez azert jo mert bindolas nelkul is megszuntethetjuk a service-t
	}
}
