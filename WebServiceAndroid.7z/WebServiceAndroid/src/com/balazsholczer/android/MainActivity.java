package com.balazsholczer.android;

import java.util.List;

import android.app.SearchManager;
import android.app.SearchableInfo;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.SearchView;
import android.widget.Toast;

import com.balazsholczer.fragments.CurrenciesListFragment;
import com.balazsholczer.services.CurrencyService;

public class MainActivity extends FragmentActivity implements
		SearchView.OnQueryTextListener {

	private Intent intent;
	private CurrenciesListFragment currenciesListFragment;
	private SearchView searchView;

	private BroadcastReceiver myBroadcastReceiver = new BroadcastReceiver() {
		public void onReceive(Context context, Intent intent) {
			Toast.makeText(MainActivity.this, "Refreshing...",Toast.LENGTH_SHORT).show();
			currenciesListFragment.updateListData();
		}
	};

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.fragment_container);

		currenciesListFragment = new CurrenciesListFragment();
		getSupportFragmentManager().beginTransaction().add(R.id.fragmentContainer, currenciesListFragment).commit();
		startService();

	}

	public void startService() {
		intent = new Intent(this, CurrencyService.class);
		startService(intent);
	}

	@Override
	public void onStart() {
		super.onResume();
		IntentFilter intentFilter = new IntentFilter(Constants.FILTER_FOR_SERVICE);
		registerReceiver(myBroadcastReceiver, intentFilter);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		super.onCreateOptionsMenu(menu);

		MenuInflater inflater = getMenuInflater();
		inflater.inflate(R.menu.main, menu);
		MenuItem searchItem = menu.findItem(R.id.action_search);
		searchView = (SearchView) searchItem.getActionView();
		setupSearchView(searchItem);

		return true;
	}

	private void setupSearchView(MenuItem searchItem) {

		if (isAlwaysExpanded()) {
			searchView.setIconifiedByDefault(false);
		} else {
			searchItem.setShowAsActionFlags(MenuItem.SHOW_AS_ACTION_IF_ROOM | MenuItem.SHOW_AS_ACTION_COLLAPSE_ACTION_VIEW);
		}

		SearchManager searchManager = (SearchManager) getSystemService(Context.SEARCH_SERVICE);
		if (searchManager != null) {
			List<SearchableInfo> searchables = searchManager.getSearchablesInGlobalSearch();

			SearchableInfo info = searchManager.getSearchableInfo(getComponentName());
			for (SearchableInfo inf : searchables) {
				if (inf.getSuggestAuthority() != null && inf.getSuggestAuthority().startsWith("applications")) {
					info = inf;
				}
			}
			searchView.setSearchableInfo(info);
		}

		searchView.setOnQueryTextListener(this);
	}

	protected boolean isAlwaysExpanded() {
		return false;
	}

	@Override
	public void onDestroy() {
		super.onPause();
		unregisterReceiver(myBroadcastReceiver);
		stopService(intent); // ez azert jo mert bindolas nelkul is	 megszuntethetjuk a service-t
	}

	@Override
	public boolean onQueryTextChange(String newText) {
		currenciesListFragment.updateSearhItems(newText);
		return false;
	}

	@Override
	public boolean onQueryTextSubmit(String query) {
		Log.e("---------------", "Query = " + query + " : submitted");
		return false;
	}
}
