package com.balazsholczer.android;

import java.util.ArrayList;
import java.util.List;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.IBinder;
import android.util.Log;
import android.widget.ListView;
import android.widget.Toast;

import com.balazsholczer.adapter.CurrencyAdapter;
import com.balazsholczer.model.Currency;
import com.balazsholczer.services.CurrencyService;
import com.balazsholczer.services.CurrencyService.MyBinderClass;

public class MainActivity extends Activity {

	private ListView currencyListView;
	private List<Currency> currencyList;
	private CurrencyAdapter currencyAdapter;
	private CurrencyService currencyService;
	
	private BroadcastReceiver myBroadcastReceiver = new BroadcastReceiver() {
		public void onReceive(Context context, Intent intent) {
			
			Bundle bundle=intent.getExtras();

			currencyList = (List<Currency>) bundle.getSerializable(Constants.KEY_FOR_MESSAGE);			
			Log.e("------- main actiity","Size is : "+currencyList.size());			
			currencyAdapter.refreshCurrencies(currencyList);
			
			Toast.makeText(getApplicationContext(), "Refreshing...", Toast.LENGTH_SHORT).show();
			
		}
	};
	private Intent intent;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
			
		currencyListSetup();	
		startService();
		
	}
	
	public void startService(){
		intent = new Intent(this,CurrencyService.class);
		startService(intent);
	}

	private void currencyListSetup() {
		currencyList=new ArrayList<>();
		currencyListView = (ListView) findViewById(R.id.stockListView);
		currencyAdapter = new CurrencyAdapter(MainActivity.this,currencyList);
		currencyListView.setAdapter(currencyAdapter);
	}
	
	@Override
	protected void onStart() {
		super.onResume();
		IntentFilter intentFilter = new IntentFilter(Constants.FILTER_FOR_SERVICE);
		registerReceiver(myBroadcastReceiver, intentFilter);
	}


	@Override
	protected void onDestroy() {
		unregisterReceiver(myBroadcastReceiver);
		stopService(intent); // ez azert jo mert bindolas nelkul is megszuntethetjuk a service-t
		super.onPause();
	}
}
