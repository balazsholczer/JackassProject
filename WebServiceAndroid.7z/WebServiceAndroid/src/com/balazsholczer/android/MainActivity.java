package com.balazsholczer.android;

import java.util.List;

import org.ksoap2.SoapEnvelope;
import org.ksoap2.serialization.SoapObject;
import org.ksoap2.serialization.SoapPrimitive;
import org.ksoap2.serialization.SoapSerializationEnvelope;
import org.ksoap2.transport.HttpTransportSE;

import android.app.Activity;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

import com.balazsholczer.android.util.CurrencyHelper;
import com.balazsholczer.model.Currency;

public class MainActivity extends Activity {

	private TextView dataTextView;
	private String resultCurrenciesXml;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		dataTextView = (TextView) findViewById(R.id.resultTextView);
	}

	public void startDownloading(View view) {
		AsyncCallWS downloadTask = new AsyncCallWS();
		downloadTask.execute();
	}

	public void parseXml(String xml) {

		List<Currency> currencies =   CurrencyHelper.getCurrenciesFromWebService(xml);
		Log.e("----size of list",""+currencies.size());
		
		dataTextView.setText("");
		
		for(Currency currency : currencies ){
			dataTextView.append(currency.getCurrencySymbol()+" - "+currency.getRate()+"\n");
		}

	}

	private class AsyncCallWS extends AsyncTask<String, Void, Void> {
		@Override
		protected Void doInBackground(String... params) {
			downloadCurrencies();
			return null;
		}

		@Override
		protected void onPostExecute(Void result) {
			parseXml(resultCurrenciesXml);
		}

		@Override
		protected void onPreExecute() {
			dataTextView.setText("Calculating...");
		}
	}

	public void downloadCurrencies() {

		SoapObject request = new SoapObject(Constants.NAMESPACE,
				Constants.METHOD_NAME);
		SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(
				SoapEnvelope.VER11);
		envelope.dotNet = true;
		envelope.setOutputSoapObject(request);
		HttpTransportSE androidHttpTransport = new HttpTransportSE(
				Constants.URL);

		try {

			androidHttpTransport.call(Constants.SOAP_ACTION, envelope);
			SoapPrimitive response = (SoapPrimitive) envelope.getResponse();
			resultCurrenciesXml = response.toString();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
