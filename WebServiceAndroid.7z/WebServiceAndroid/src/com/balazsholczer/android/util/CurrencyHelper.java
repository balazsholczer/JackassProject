package com.balazsholczer.android.util;

import java.io.IOException;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import com.balazsholczer.model.Currency;

public class CurrencyHelper {

	public static List<Currency> getCurrenciesFromWebService(String xmlString){
			
		List<Currency> actualCurrencies = new ArrayList<>();
		
		try {
			
			SAXParserFactory factory = SAXParserFactory.newInstance();
			SAXParser saxParser = factory.newSAXParser();
			CurrencyHandler currencyHandler = new CurrencyHandler();
			saxParser.parse(new InputSource(new StringReader(xmlString)),currencyHandler);
			actualCurrencies = currencyHandler.getListCurrencies();
			return actualCurrencies;
			
		} catch (ParserConfigurationException | SAXException | IOException e) {
			e.printStackTrace();
		}
		
		return actualCurrencies;
	}
}
