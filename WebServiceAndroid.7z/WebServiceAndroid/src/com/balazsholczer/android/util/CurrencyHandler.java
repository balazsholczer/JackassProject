package com.balazsholczer.android.util;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

import android.util.Log;

import com.balazsholczer.model.Currency;

public class CurrencyHandler extends DefaultHandler {

	private String tempCountryId;
	private String tempRate;
	private String tempUnit;
	private ArrayList<Currency> listCurrencies=new ArrayList<Currency>();
	private boolean booleanRate = false;

	@Override
	public void startElement(String uri, String localName, String qName,
			Attributes attributes) throws SAXException {

		if (qName.equalsIgnoreCase("RATE")) {
			booleanRate = true;
			tempCountryId = attributes.getValue(0);
			tempUnit = attributes.getValue(1);
		}
	}

	@Override
	public void characters(char ch[], int start, int length)
			throws SAXException {

		if (booleanRate) {
			tempRate = new String(ch, start, length);
			booleanRate = false;

			listCurrencies.add(new Currency(tempCountryId, tempUnit, tempRate));
		}
	}

	public ArrayList<Currency> getListCurrencies() {	
		
		Collections.sort(listCurrencies, new Comparator<Currency>() {
			public int compare(Currency currency1, Currency currency2) {
				return currency1.getCurrencySymbol().compareTo(currency2.getCurrencySymbol());
			}
		});
			
		return listCurrencies;
	}
}
