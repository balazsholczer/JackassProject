package com.balazsholczer.android.util;

import java.util.ArrayList;
import java.util.List;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

import android.util.Log;

import com.balazsholczer.model.Currency;

public class CurrencyHandler extends DefaultHandler {

	private String tempCountryId;
	private String tempRate;
	private String tempUnit;
	private List<Currency> listCurrencies=new ArrayList<Currency>();
	boolean booleanRate = false;

	@Override
	public void startElement(String uri, String localName, String qName,
			Attributes attributes) throws SAXException {

		// System.out.println("Start Element :" + qName);

		if (qName.equalsIgnoreCase("RATE")) {
			booleanRate = true;
			tempCountryId = attributes.getValue(0);
			tempUnit = attributes.getValue(1);
			// System.out.println("Unit: "+attributes.getValue(1));
		}
	}

	@Override
	public void endElement(String uri, String localName, String qName)
			throws SAXException {

		// System.out.println("End Element :" + qName);

	}

	@Override
	public void characters(char ch[], int start, int length)
			throws SAXException {

		if (booleanRate) {
			tempRate = new String(ch, start, length);
			// System.out.println("Rate : "+ tempCountryId);
			booleanRate = false;

			Log.e("----------------------","CURRENCY: "+tempCountryId+"-"+tempRate+"-"+tempUnit);
			listCurrencies.add(new Currency(tempCountryId, tempUnit, tempRate));

		}
	}

	public List<Currency> getListCurrencies() {
		return listCurrencies;
	}
}
