package com.balazsholczer.android.util;

import java.util.ArrayList;
import java.util.List;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

import android.util.Log;

import com.balazsholczer.model.Currency;

public class CurrencyHandler extends DefaultHandler {

	private String tempCountryId;
	private String tempRate;
	private String tempUnit;
	private ArrayList<Currency> listCurrencies=new ArrayList<Currency>();
	boolean booleanRate = false;

	@Override
	public void startElement(String uri, String localName, String qName,
			Attributes attributes) throws SAXException {

		if (qName.equalsIgnoreCase("RATE")) {
			booleanRate = true;
			tempCountryId = attributes.getValue(0);
			tempUnit = attributes.getValue(1);
		}
	}

	@Override
	public void characters(char ch[], int start, int length)
			throws SAXException {

		if (booleanRate) {
			tempRate = new String(ch, start, length);
			booleanRate = false;

			listCurrencies.add(new Currency(tempCountryId, tempUnit, tempRate));
		}
	}

	public ArrayList<Currency> getListCurrencies() {	
		return listCurrencies;
	}
}
