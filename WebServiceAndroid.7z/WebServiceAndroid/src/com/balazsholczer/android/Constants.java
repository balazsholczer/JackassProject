package com.balazsholczer.android;

public class Constants {

	public static final String NAMESPACE = "http://www.mnb.hu/webservices/";
	public static String URL = "http://www.mnb.hu/arfolyamok.asmx";
	public static String SOAP_ACTION = "http://www.mnb.hu/webservices/GetCurrentExchangeRates";
	public static String METHOD_NAME = "GetCurrentExchangeRates";
	public static final String FILTER_FOR_SERVICE = "filter_for_Service";
	public static final String KEY_FOR_MESSAGE ="keyforthemessage";
	public static final String KEY_FOR_SAVED_LIST ="keyforsavedlist";
	public static final String MY_PREFERENCES ="MyPreferences";
	public static final String KEY_DATA_FRAGMENTS = "change_data";
	
	private Constants(){
		
	}
}
