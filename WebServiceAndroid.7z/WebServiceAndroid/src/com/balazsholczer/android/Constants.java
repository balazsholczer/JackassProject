package com.balazsholczer.android;

public class Constants {

	public static final String NAMESPACE = "http://www.mnb.hu/webservices/";
	public static String URL = "http://www.mnb.hu/arfolyamok.asmx";
	public static String SOAP_ACTION = "http://www.mnb.hu/webservices/GetCurrentExchangeRates";
	public static String METHOD_NAME = "GetCurrentExchangeRates";
	
	private Constants(){
		
	}
}
