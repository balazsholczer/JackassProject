package com.example.consensusfragmentsviewpager;

import java.util.ArrayList;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.ListFragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.ListView;
import android.widget.TextView;

public class FragmentContactList extends ListFragment {

    private ArrayList<Contact> contactList;
    
    @Override
    public void onCreate(Bundle savedInstanceState) {    
        super.onCreate(savedInstanceState);
        
        getActivity().setTitle("Contact List");
        contactList = AllContacts.get(getActivity()).getContactList();
        
        ContactAdapter contactAdapter = new ContactAdapter(contactList);
        
        setListAdapter(contactAdapter);
        
    }
    
    @Override
    public void onListItemClick(ListView l, View v, int position, long id) {     
        super.onListItemClick(l, v, position, id);
        
        Contact clickedContact = ((ContactAdapter) getListAdapter()).getItem(position);
        Intent intent = new Intent(getActivity(),ContactViewPager.class);
        intent.putExtra(ContactFragment.CONTACT_ID, clickedContact.getIdNumber());
        startActivityForResult(intent, 0);
    }
    
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {     
        super.onActivityResult(requestCode, resultCode, data);
        
        ((ContactAdapter) getListAdapter()).notifyDataSetChanged();
        
    }
    
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        
        return super.onCreateView(inflater, container, savedInstanceState);
    }
    
    private class ContactAdapter extends ArrayAdapter<Contact>{
        
        public ContactAdapter(ArrayList<Contact> contacts) {
          super(getActivity(),android.R.layout.simple_list_item_1,contacts);
        }
        
        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            
            if(convertView==null){
                convertView = getActivity().getLayoutInflater().inflate(R.layout.list_item_layout, null);
            }
            
            Contact contact = getItem(position);
            
            TextView contactName = (TextView) convertView.findViewById(R.id.list_item_name);
            contactName.setText(contact.getName());
            
            TextView contactStreet = (TextView) convertView.findViewById(R.id.list_item_street);
            contactStreet.setText(contact.getStreetAddress());
            
            CheckBox checkBox = (CheckBox) convertView.findViewById(R.id.list_item_checkbox);
            checkBox.setChecked(contact.isContacted());
            
            return convertView;
        }
    }  
}
