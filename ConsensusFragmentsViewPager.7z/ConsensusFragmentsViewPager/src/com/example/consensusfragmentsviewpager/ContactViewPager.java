package com.example.consensusfragmentsviewpager;

import java.util.ArrayList;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;
import android.support.v4.view.ViewPager;

public class ContactViewPager extends FragmentActivity{

    private ViewPager viewPager;
    private ArrayList<Contact> contactList;
    
    @Override
    protected void onCreate(Bundle arg0) {    
        super.onCreate(arg0);
        
        viewPager = new ViewPager(this);
        viewPager.setId(R.id.viewPager);
        
        setContentView(viewPager);     
       
        contactList = AllContacts.get(this).getContactList();
      
        FragmentManager fragmentManager = getSupportFragmentManager();
        
        viewPager.setAdapter(new FragmentStatePagerAdapter(fragmentManager) {
            
            @Override
            public int getCount() {
                return contactList.size();
            }
            
            @Override
            public Fragment getItem(int position) {
                
                Contact theContact = contactList.get(position);           
                return ContactFragment.newContactFragment(theContact.getIdNumber());            
            }
        });
    }
    
}
