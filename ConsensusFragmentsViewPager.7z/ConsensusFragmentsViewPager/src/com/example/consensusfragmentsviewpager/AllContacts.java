package com.example.consensusfragmentsviewpager;

import java.util.ArrayList;
import java.util.UUID;

import android.content.Context;
import android.location.Address;

public class AllContacts {
    
    private Context applicationContext;
    private ArrayList<Contact> contactList;
    private static AllContacts allContacts; 

    private AllContacts(Context context){
        this.applicationContext=context;
        contactList = new ArrayList<Contact>();
        
        Contact contact1 = new Contact();
        contact1.setName("John Smith");
        contact1.setStreetAddress("123 Main Street");
        contact1.setContacted(true);
        contactList.add(contact1);
        
        Contact contact2 = new Contact();
        contact2.setName("Sally Smith");
        contact2.setStreetAddress("125 Main Street");
        contact2.setContacted(false);
        contactList.add(contact2);
        
        Contact contact3 = new Contact();
        contact3.setName("Mark Smith");
        contact3.setStreetAddress("127 Main Street");
        contact3.setContacted(false);
        contactList.add(contact3);
        
    }

    public static AllContacts get(Context context){
        if( allContacts == null ){
            allContacts=new AllContacts(context.getApplicationContext());
        }
        return allContacts;
    }
    
    public ArrayList<Contact> getContactList(){
        return contactList;
    }
    
    public Contact getContact(UUID id){
        for(Contact contact : contactList){
            if(contact.getIdNumber() == id ){
                return contact;         
            }
        }
        return null;
    }
}
