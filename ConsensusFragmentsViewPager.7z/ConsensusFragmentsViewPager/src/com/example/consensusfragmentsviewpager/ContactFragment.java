package com.example.consensusfragmentsviewpager;

import java.util.UUID;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.EditText;


public class ContactFragment extends Fragment{

    public static final String CONTACT_ID = "com.example.consensusfragmentsviewpager";
    
    private Contact contact;
    private EditText contactNameEditText;
    private EditText contactCityEditText;
    private EditText contactPhoneNumberEditText;
    private EditText contactStreetEditText;
    private CheckBox contactContactedCheckbox;
    
    public static ContactFragment newContactFragment(UUID contactID){
        Bundle passData = new Bundle();
        passData.putSerializable(CONTACT_ID, contactID);
        ContactFragment contactFragment = new ContactFragment();
        contactFragment.setArguments(passData);
        return contactFragment;
    }
    
    @Override
    public void onCreate(Bundle savedInstanceState) {       
        super.onCreate(savedInstanceState);
        
        UUID contactId = (UUID) getArguments().getSerializable(CONTACT_ID);
        contact = AllContacts.get(getActivity()).getContact(contactId);
        
        if(contact == null){
            contact=new Contact();
        }
        
        
    }
    
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {   
        
        View theView = inflater.inflate(R.layout.fragment_contact, container,false);
        
        contactNameEditText = (EditText) theView.findViewById(R.id.contactNameEditText);
        contactCityEditText = (EditText) theView.findViewById(R.id.contactCityEditText);
        contactPhoneNumberEditText = (EditText) theView.findViewById(R.id.contactPhoneNumberEditText);
        contactStreetEditText = (EditText) theView.findViewById(R.id.contactStreetEditText);
        contactContactedCheckbox = (CheckBox) theView.findViewById(R.id.contactContactedCheckbox);
        
        contactContactedCheckbox.setOnCheckedChangeListener(new OnCheckedChangeListener() {           
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
               contact.setContacted(isChecked);
            }
        });
      
        TextWatcher editTextWatcher = new TextWatcher() {
            
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if(contactCityEditText.hasFocus()) contact.setCity(s.toString());
                if(contactNameEditText.hasFocus()) contact.setName(s.toString());
                if(contactPhoneNumberEditText.hasFocus()) contact.setName(s.toString());
                if(contactStreetEditText.hasFocus()) contact.setStreetAddress(s.toString());
            }
            
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}   
            @Override
            public void afterTextChanged(Editable s) {}
        };
        
        contactNameEditText.addTextChangedListener(editTextWatcher);
        contactCityEditText.addTextChangedListener(editTextWatcher);
        contactPhoneNumberEditText.addTextChangedListener(editTextWatcher);
        contactStreetEditText.addTextChangedListener(editTextWatcher);
        
        contactNameEditText.setText(contact.getName());
        contactCityEditText.setText(contact.getCity());
        contactPhoneNumberEditText.setText(contact.getPhoneNumber());
        contactStreetEditText.setText(contact.getStreetAddress());
        
        contactContactedCheckbox.setChecked(contact.isContacted());
        
        return theView;
    } 
}
