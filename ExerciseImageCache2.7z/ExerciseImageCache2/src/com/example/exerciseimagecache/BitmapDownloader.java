package com.example.exerciseimagecache;

import java.net.URL;
import java.net.URLConnection;

import android.content.AsyncTaskLoader;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Log;

public class BitmapDownloader extends AsyncTaskLoader<Bitmap> {

    private String url;
    
    public BitmapDownloader(Context context,String url) {
        super(context);
        this.url=url;
    }

    @Override
    public Bitmap loadInBackground() {

        Bitmap tempImage = null;

        try {
              
            URLConnection conn = new URL( url ).openConnection();
            conn.connect();
            tempImage = BitmapFactory.decodeStream( conn.getInputStream() );       
            
        } catch (Exception e) {
            Log.e("Error", "Hiba a downloaderben ..."+e.getMessage());
            e.printStackTrace();
        }

        return tempImage;
    }
}