package com.example.exerciseimagecache;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import com.nostra13.universalimageloader.core.DisplayImageOptions;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.display.RoundedBitmapDisplayer;

public class ImageListAdapter extends BaseAdapter {

	private Context context;
	private ImageLoader imageLoader;

	public ImageListAdapter(Context context) {
		this.context = context;
		imageLoader = ImageLoader.getInstance();
	}

	@Override
	public int getCount() {
		return Constants.urls.length;
	}

	@Override
	public Object getItem(int arg0) {
		return null;
	}

	@Override
	public long getItemId(int arg0) {
		return 0;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup viewGroup) {
		View v = convertView;

		ViewHolder vh = null;
		if (v == null) {
			v = View.inflate(context, R.layout.list_item, null);

			vh = new ViewHolder();
			vh.imageView = (ImageView) v.findViewById(R.id.imageView);

			v.setTag(vh);
		} else {
			vh = (ViewHolder) v.getTag();
		}

		DisplayImageOptions options = new DisplayImageOptions.Builder()
				.showImageOnLoading(R.drawable.ic_stub)
				.showImageForEmptyUri(R.drawable.ic_empty)
				.showImageOnFail(R.drawable.ic_error).cacheInMemory(true)
				.cacheOnDisk(true).considerExifParams(true)
				.displayer(new RoundedBitmapDisplayer(20)).build();

		imageLoader.displayImage(Constants.urls[position], vh.imageView,
				options);

		return v;
	}

	private class ViewHolder {
		ImageView imageView;
	}
}
