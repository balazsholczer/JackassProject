package com.example.exerciseimagecache;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListView;
import android.widget.Toast;

import com.nostra13.universalimageloader.cache.disc.naming.Md5FileNameGenerator;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.ImageLoaderConfiguration;
import com.nostra13.universalimageloader.core.assist.QueueProcessingType;

public class MainActivity extends Activity {

	private ListView listView;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		listView = (ListView)findViewById(R.id.listView);
		listView.setAdapter(new ImageListAdapter(this));
		
		listView.setOnItemClickListener(new OnItemClickListener() {
			public void onItemClick(AdapterView<?> parent, View view,int position, long id) {
				
				Toast.makeText(getApplicationContext(), ""+position, Toast.LENGTH_SHORT).show();
				Intent intent = new Intent(MainActivity.this,ImageActivity.class);
				intent.putExtra("position", position);
				startActivity(intent);
				
			}
		});
		
		
		
//		ImageLoaderConfiguration config = new ImageLoaderConfiguration.Builder(getApplicationContext())
//		.threadPriority(Thread.NORM_PRIORITY - 2)
//		.denyCacheImageMultipleSizesInMemory()
//		.discCacheFileNameGenerator(new Md5FileNameGenerator())
//		.tasksProcessingOrder(QueueProcessingType.LIFO)
//		.build();
//		
		ImageLoader.getInstance().init(ImageLoaderConfiguration.createDefault(this));
		
	}

}