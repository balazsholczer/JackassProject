package com.example.exerciseimagecache;

import android.app.Activity;
import android.app.LoaderManager;
import android.content.Intent;
import android.content.Loader;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.text.method.ScrollingMovementMethod;
import android.util.Log;
import android.widget.ImageView;
import android.widget.TextView;

public class ImageActivity extends Activity implements LoaderManager.LoaderCallbacks<Bitmap>  {
	
	private ImageView imageView;
	private TextView textView;
	private int position;
	private Handler handler = new Handler(new Handler.Callback() {
        public boolean handleMessage(Message msg) {

            if (msg.what == Constants.UPDATE_IMAGE_MESSAGE) {         
                
            	Bitmap bitmap = (Bitmap) msg.obj;           	
                imageView.setImageBitmap(bitmap);

            }
            return true;
        }
    });
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {		
		super.onCreate(savedInstanceState);
		setContentView(R.layout.image_activity);
		
		Intent intent = getIntent();
		position = intent.getIntExtra("position", 0);
		
		imageView = (ImageView) findViewById(R.id.imageActivityImageView);
		textView = (TextView) findViewById(R.id.textViewImageView);	
		textView.setMovementMethod(new ScrollingMovementMethod());
		
		getLoaderManager().restartLoader(Constants.UPDATE_IMAGE, null, this).forceLoad();
		
	}

	@Override
	public Loader<Bitmap> onCreateLoader(int id, Bundle args) {		
		return new BitmapDownloader(this, Constants.urls[position]);
	}

	@Override
	public void onLoadFinished(Loader<Bitmap> loader, Bitmap data) {
		
		switch (loader.getId()) {
		case Constants.UPDATE_IMAGE:
			sendMessageToHandler(data, Constants.UPDATE_IMAGE_MESSAGE);
			break;

		default:
			break;
		}
		
	}

	private void sendMessageToHandler(Bitmap data, int updateImageMessage) {	
		Message message = new Message();
        message.obj = data;
        message.what = updateImageMessage;
        handler.sendMessage(message);
	}

	@Override
	public void onLoaderReset(Loader<Bitmap> loader) {
	}
}
