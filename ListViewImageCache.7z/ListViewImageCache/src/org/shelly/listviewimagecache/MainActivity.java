package org.shelly.listviewimagecache;

import java.util.ArrayList;

import android.app.Activity;
import android.app.ActivityManager;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.AbsListView.OnScrollListener;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

public class MainActivity extends Activity implements OnScrollListener {	
		
	private Cache cache;	
	private ListView listView;
	private ListAdapter listAdapter;
	private boolean isScrolling;
	
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main_activity);
         
        final int memoryClass = ((ActivityManager) getSystemService(Context.ACTIVITY_SERVICE)).getMemoryClass();
        final int size = 1024 * 1024 * memoryClass / 8;     
        
        // Handle orientation change.
        RetainCache c = RetainCache.getOrCreateRetainableCache();
        cache = c.mRetainedCache;
        
        if (cache == null) {
        	// The maximum bitmap pixels allowed in respective direction.
        	// If exceeding, the cache will automatically scale the 
        	// bitmaps.
        	final int MAX_PIXELS_WIDTH = 100;
        	final int MAX_PIXELS_HEIGHT = 100;
        	cache = new Cache(size, MAX_PIXELS_WIDTH, MAX_PIXELS_HEIGHT);
            c.mRetainedCache = cache;
        } 
        
        // Initialize the row objects with some random text.
        final int amountOfItems = Constants.urls.length;
        listView = (ListView) findViewById(android.R.id.list);
        ArrayList<Row> objects = new ArrayList<Row>(amountOfItems);
        
        for (int x = 0; x < amountOfItems; x++) {
        	Row object = new Row();
        	object.text = "Hey image number " + Integer.toString(x + 1) + "!";
        	object.bitmapUrl = Constants.urls[x];
        	objects.add(object);
        }
        
        listAdapter = new ListAdapter(objects);
        listView.setAdapter(listAdapter);
        listView.setOnScrollListener(this);
    }
    
    private static class ViewHolder {
		private TextView textView;
		private ImageView imageView;
		  
		private ViewHolder(View base) {
			textView = (TextView) base.findViewById(R.id.text);
			imageView = (ImageView) base.findViewById(R.id.image);
		}
	}
    
    private class Row {
    	private String text;
    	private String bitmapUrl;
    }
    
    public class ListAdapter extends ArrayAdapter<Row> {
    	
    	public ListAdapter(ArrayList<Row> objects) {
    		super(MainActivity.this, R.layout.main_listview_row, objects);    		
    	}      

    	@Override
    	public View getView(final int position, View convertView, ViewGroup parent) {     		
    		View row = convertView;
    		final ViewHolder holder;
    		
    		if (row == null) {
    			LayoutInflater inflater = getLayoutInflater();
    			row = inflater.inflate(R.layout.main_listview_row, parent, false);  
    			holder = new ViewHolder(row);
    			row.setTag(holder);
    		} else {
    			holder = (ViewHolder) row.getTag();
    		}	

    		final Row rowObject = getItem(position);
    		  		
    		holder.textView.setText(rowObject.text); 		
    		cache.loadBitmap(MainActivity.this,rowObject.bitmapUrl, holder.imageView,isScrolling);  
    		
    	    return row;
    	} 	
    }
    
    public ListAdapter getAdapter() {
    	return listAdapter;
    }
    
    public boolean internetIsAvailable() {
        ConnectivityManager cm =
            (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo netInfo = cm.getActiveNetworkInfo();
        if (netInfo != null && netInfo.isConnected()) {
            return true;
        }
        return false;
    }
    
	public void onScrollStateChanged(AbsListView view, int scrollState) {
		if (view.getId() == android.R.id.list) {
			// Set scrolling to true only if the user has flinged the		
			// ListView away, hence we skip downloading a series
			// of unnecessary bitmaps that the user probably
			// just want to skip anyways. If we scroll slowly it
			// will still download bitmaps - that means
			// that the application won't wait for the user
			// to lift its finger off the screen in order to
			// download.
			if (scrollState == SCROLL_STATE_FLING) {
				isScrolling = true;
			} else {
				isScrolling = false;
				listAdapter.notifyDataSetChanged();
			}
		} 
	}

	public void onScroll(AbsListView view, int firstVisibleItem,
			int visibleItemCount, int totalItemCount) {		
	}
}
