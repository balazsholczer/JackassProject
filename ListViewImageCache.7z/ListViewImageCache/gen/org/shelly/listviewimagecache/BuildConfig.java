/** Automatically generated file. DO NOT MODIFY */
package org.shelly.listviewimagecache;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}