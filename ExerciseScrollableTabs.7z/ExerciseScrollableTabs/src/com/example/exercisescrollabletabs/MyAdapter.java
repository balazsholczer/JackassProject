package com.example.exercisescrollabletabs;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;

/*
 * HA FRAGMENTPAGERADAPTERT HASZNALUNK
 * itt csak egyszer hivodik meg minden egyes fragmentre a getItem() metodus, hiszen utana eltarolodik az objektum
 * szervesen kotodve az adott activityhez
 *  Ennel a FragmentPagerAdapternel ez igy van: akkor jo, ha keves option van!!! kulonben soka teruletet foglal a memoriaban
 *  
 *      FragmentState...nel minden egyes lapozasnal meghivodik a getItem() metodus
 */

public class MyAdapter extends FragmentStatePagerAdapter {

    public MyAdapter(FragmentManager fm) {
        super(fm);     
    }

    @Override
    public Fragment getItem(int arg) {
     
        switch (arg) {
        case 0:
            return new FragmentA();
        case 1:
            return new FragmentB();
        case 2:
            return new FragmentC();
        default: return null;
        }
    }

    @Override
    public int getCount() {
        return 3;
    }
    
    @Override
    public CharSequence getPageTitle(int position) {
        switch (position) {
        case 0:
            return "Tab 1";
        case 1:
            return "Tab 2";
        case 2:
            return "Tab 3";
        default: return null;
        }
    }
}
