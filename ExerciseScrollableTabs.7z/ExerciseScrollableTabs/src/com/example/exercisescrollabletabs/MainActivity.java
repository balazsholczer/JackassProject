package com.example.exercisescrollabletabs;

import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.support.v4.view.ViewPager;

/*
 *          https://www.youtube.com/watch?v=Oa1mlObffiA&list=PLonJJ3BVjZW5JdoFT0Rlt3ry5Mjp7s8cT
 * 
 *  Van a swipe vs scroll tabs: az elso akkor jo, ha keves opcio van, azok stabilan ott maradnak vegig, viewpager
 *  seg�tsegevel tudjuk cserelni a fragmenteket pl: facebooknal android okostelefonon ilyen van
 *      Scroll: ha sok opcio van: es nem ferne ki..jobban nez ki kicsit
 *      
 *      Adaptert kell hasznalni a viewpager miatt: FragmentPagerAdapter vs FragmentStatePagerAdapter
 *              Elso adapter: kis lapszamoknal jo, amikor fixek a lapok szama. Mindegy egyes fragment egy kulon object az   
 *                  activityhez rendelve...ha user elnavigal, a UI megszunik/destroyed...de az object megmarad az activityhez rendelve
 *              MAsodik adapter: ha nagyon sok fragment kozott akarunk swipeolni akkor jo
 *                  itt meghivodik az onSaveInstanceState() metodus...az elsonel nem
 *                      Itt az egesz minden megsemmisul, az onSave... miatt lehet visszaallitani mindent
 *                          -itt ha elkezdunk tolteni valami az A fragmentben �s kozben atnavigalunk a masik ketto valamelyikere, akkor is 
 *                              folytatodik a download...eltarolodik a data a savedInstanceban...az elso adapternel elveszik az adat!!!! 
 *                     
 */

public class MainActivity extends FragmentActivity {

    private ViewPager viewPager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        viewPager = (ViewPager) findViewById(R.id.myViewPager);
        
        FragmentManager fragmentManager = getSupportFragmentManager();
        
        viewPager.setAdapter(new MyAdapter(fragmentManager));
        
    }

}
