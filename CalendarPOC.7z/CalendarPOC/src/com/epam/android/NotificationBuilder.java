package com.epam.android;

import android.app.Activity;
import android.app.Notification;
import android.app.Notification.Builder;
import android.os.Bundle;

public class NotificationBuilder extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		 
		
	}
}
