package com.example.exerciseandroidgridview;

import java.util.ArrayList;
import java.util.Currency;
import java.util.List;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;

public class MyAdapter extends BaseAdapter {

    private List<Country> countries;
    private Context context;
    
    public MyAdapter(Context context){
        
        this.context=context;
        
        countries = new ArrayList<Country>();
        String[] countryNames = context.getResources().getStringArray(R.array.country_names);
        int[] countryImages = {R.drawable.somaliland,R.drawable.sweden,R.drawable.ukraine,R.drawable.uzbekistan,R.drawable.vanutau,R.drawable.venezuela,R.drawable.yemen,R.drawable.zambia,R.drawable.zimbabwe};
        
        for(int i=0;i<countryNames.length;i++){
            Country country = new Country(countryImages[i], countryNames[i]);
            countries.add(country);
        }  
    }
    
    @Override
    public int getCount() {      
        return countries.size();
    }

    @Override
    public Object getItem(int position) {      
        return countries.get(position);
    }

    @Override
    public long getItemId(int position) {      
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {  // itt is hasznalhato a viewholder pattern ami 175%os hatekonysagnovelest jelent
     
        View row = convertView;
        ViewHolder holder = null;
        
        if( row == null ){
            LayoutInflater layoutInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);           
            row = layoutInflater.inflate(R.layout.single_item, parent,false);         
            holder = new ViewHolder(row);
            row.setTag(holder);
        }else{
            holder = (ViewHolder) row.getTag();
        }
        
        Country countryTemp = countries.get(position);
        holder.imageView.setImageResource(countryTemp.getImageId());
        holder.imageView.setTag(countryTemp);
        
        return row;
    }
}

class ViewHolder{
   
    ImageView imageView;    
 
    ViewHolder(View view){
        imageView=(ImageView) view.findViewById(R.id.singleImage); 
    }
}
