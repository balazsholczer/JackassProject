package com.example.exerciseandroidgridview;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.GridView;


/*
 *  A BaseAdapter mindig egy lekepzes a View <-> data kozott
 *      Egy 1-1es megfeleltetes a ket halmaz kozott
 *      
 *      A GridView is a ViewGroup that displays items in two-dimensional scrolling grid. The items in the grid come from the ListAdapter associated with this view.
 *   This is what you'd want to use (keep using). Because a GridView gets its data from a ListAdapter, the only data loaded in memory will be the one displayed 
 *    on screen. GridViews, much like ListViews reuse and recycle their views for better performance.
 *     Whereas a GridLayout is a layout that places its children in a rectangular grid.
 *      It was introduced in API level 14, and was recently backported in the Support Library. Its main purpose is to solve alignment 
 *       and performance problems in other layouts. Check out this tutorial if you want to learn more about GridLayout.
 */

public class MainActivity extends Activity implements OnItemClickListener{

    private GridView gridView;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        gridView = (GridView) findViewById(R.id.gridView);
        gridView.setAdapter(new MyAdapter(this));
        gridView.setOnItemClickListener(this);
        
    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        Intent intent = new Intent(this,MyDialog.class);
        
        ViewHolder holder = (ViewHolder) view.getTag();
        Country currentCountry = (Country) holder.imageView.getTag();
        
        intent.putExtra("countryImage", currentCountry.getImageId());
        intent.putExtra("countryName", currentCountry.getCountryName());
        
        startActivity(intent);
    }
}
