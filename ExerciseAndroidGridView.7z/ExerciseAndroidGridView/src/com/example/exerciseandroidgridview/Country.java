package com.example.exerciseandroidgridview;

public class Country {

    private int imageId;
    private String countryName;

    public Country(int imageId, String countryName) {
        this.imageId = imageId;
        this.countryName = countryName;
    }

    public int getImageId() {
        return imageId;
    }

    public void setImageId(int imageId) {
        this.imageId = imageId;
    }

    public String getCountryName() {
        return countryName;
    }

    public void setCountryName(String countryName) {
        this.countryName = countryName;
    }
}
