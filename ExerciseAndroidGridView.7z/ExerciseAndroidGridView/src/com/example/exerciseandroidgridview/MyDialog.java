package com.example.exerciseandroidgridview;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class MyDialog extends Activity {
    
    private ImageView imageView;
    private TextView countryName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_dialog);
        
        imageView = (ImageView) findViewById(R.id.dialogImage);
        countryName = (TextView) findViewById(R.id.countryName);

        Intent intent = getIntent();
        
        int imageId = intent.getIntExtra("countryImage", R.drawable.ic_launcher);
        String name = intent.getStringExtra("countryName");
        
        imageView.setImageResource(imageId);
        countryName.setText(name);
        
    }

    public void closeDialog(View view) {
        finish();
    }
}
