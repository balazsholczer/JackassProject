package com.example.exercisenavigationdrawer2;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

public class MyAdapter extends BaseAdapter {

    private String[] topics;
    private int[] images = {R.drawable.facebook,R.drawable.youtube,R.drawable.twitter,R.drawable.physics32};
    private Context context;
    
    public MyAdapter(Context context){
        this.context=context;
        topics = context.getResources().getStringArray(R.array.topics);
    }
    
    @Override
    public int getCount() {
        return topics.length;
    }

    @Override
    public Object getItem(int position) {
        return topics[position];
    }

    @Override
    public long getItemId(int position) {      
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
       
        View row = null;
        
        if( convertView == null ){
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            row = inflater.inflate(R.layout.custom_row, parent, false);
        }else{
            row = convertView;
        }
        
        ImageView imageView = (ImageView) row.findViewById(R.id.listItemImageView);
        TextView textView = (TextView) row.findViewById(R.id.listItemTextView);
        
        textView.setText(topics[position]);
        imageView.setImageResource(images[position]);
        
        return row;
    }
}
