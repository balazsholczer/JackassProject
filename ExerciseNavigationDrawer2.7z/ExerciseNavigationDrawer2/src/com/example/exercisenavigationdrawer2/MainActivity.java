package com.example.exercisenavigationdrawer2;

import com.example.fragments.FacebookFragment;
import com.example.fragments.YoutubeFragment;

import android.app.Activity;
import android.content.res.Configuration;
import android.os.Bundle;
import android.support.v4.app.ActionBarDrawerToggle;
import android.support.v4.widget.DrawerLayout;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

public class MainActivity extends Activity {

    private DrawerLayout drawerLayout;
    private ListView listView;
    private MyAdapter myAdapter;
    private ActionBarDrawerToggle drawerListener;
    private String[] topics;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    
        topics = getResources().getStringArray(R.array.topics);
        
        
        drawerLayout = (DrawerLayout) findViewById(R.id.drawer_layout);
        listView = (ListView) findViewById(R.id.draweList); 
              
        
        myAdapter = new MyAdapter(this);
        listView.setAdapter(myAdapter);
        
        drawerListener = new ActionBarDrawerToggle(this, drawerLayout, R.drawable.ic_drawer, R.string.drawer_open, R.string.drawer_close){         
            public void onDrawerOpened(View drawerView) {            
                Toast.makeText(MainActivity.this, "Drawer is open...", Toast.LENGTH_SHORT).show();
            }
            public void onDrawerClosed(View drawerView) {            
                Toast.makeText(MainActivity.this, "Drawer is closed...", Toast.LENGTH_SHORT).show();
            }
        };
        
        drawerLayout.setDrawerListener(drawerListener);
        
        listView.setOnItemClickListener(new OnItemClickListener() {
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {        
               selectItem(position);
            }      
        });      
        
        getActionBar().setHomeButtonEnabled(true);
        getActionBar().setDisplayHomeAsUpEnabled(true);  // hogy legyen egy nyil ami a home hoz og navigalni
    }
    
    private void selectItem(int position) {
        Toast.makeText(MainActivity.this, topics[position], Toast.LENGTH_SHORT).show();                   
        listView.setItemChecked(position, true);
        setTitle(topics[position]);
        
        switch (position) {
        case 0:
            getFragmentManager().beginTransaction().replace(R.id.mainContent,new FacebookFragment()).commit();
            drawerLayout.closeDrawers();
            break;
        case 1:
            getFragmentManager().beginTransaction().replace(R.id.mainContent,new YoutubeFragment()).commit();
            drawerLayout.closeDrawers();
            break;
        default:
            break;
        }            
    }
    
    private void setTitle(String title){
        getActionBar().setTitle(title);
    }
    
    @Override
    protected void onPostCreate(Bundle savedInstanceState) {      
        super.onPostCreate(savedInstanceState);
        drawerListener.syncState();
    }
    
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {   
        
        if( drawerListener.onOptionsItemSelected(item)){ // ha az actionbaros iconra klikkelunk akkor is elojon a drawer...atadja neki az if(...) miatt
            return true;
        }
        
        return super.onOptionsItemSelected(item);
    }
    
    @Override
    public void onConfigurationChanged(Configuration newConfig) {       
        super.onConfigurationChanged(newConfig);
        drawerListener.onConfigurationChanged(newConfig);
    }
}
