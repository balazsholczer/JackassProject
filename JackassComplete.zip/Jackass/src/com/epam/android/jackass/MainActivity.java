package com.epam.android.jackass;

import java.util.List;

import model.User;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends Activity {
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void startSimulation(View view) {
        Intent intent = new Intent(this, GatheringDataActivity.class);
        startActivity(intent);
    }

    public void showScores(View view) {
        Intent intent = new Intent(this,ScoresActivity.class);
        startActivity(intent);
    }

    public void logoutUser(View view) {    
        Intent intent = new Intent(this, LoginActivity.class);
        startActivity(intent);
    }
    
    public void postImageFacebook(View view){
//        Intent intent = new Intent(this, PostImageActivity.class);
//        startActivity(intent);
    }
}
