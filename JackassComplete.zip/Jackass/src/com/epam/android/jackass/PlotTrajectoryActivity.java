package com.epam.android.jackass;

import java.util.ArrayList;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PointF;
import android.os.Bundle;
import android.util.FloatMath;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.widget.Toast;

import com.androidplot.xy.BoundaryMode;
import com.androidplot.xy.LineAndPointFormatter;
import com.androidplot.xy.SimpleXYSeries;
import com.androidplot.xy.XYPlot;
import com.androidplot.xy.XYSeries;
import com.androidplot.xy.XYStepMode;
import com.epam.android.constants.Constants;

public class PlotTrajectoryActivity extends Activity {

    private XYPlot mySimpleXYPlot;
    private float velocity;
    private List<Number> coordinatesX;
    private List<Number> coordinatesY;
    private float x;
    private float dx = 0.1f;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.graph_view);

        Intent intent = getIntent();
        velocity = intent.getExtras().getFloat("velocity");

        MultitouchPlot multitouchPlot = (MultitouchPlot) findViewById(R.id.multitouchPlot);

        coordinatesY = new ArrayList<Number>();
        coordinatesX = new ArrayList<Number>();

        for (;;) {

            if (calculateY(x) < -0.1)
                break;

            coordinatesX.add(x);
            coordinatesY.add(calculateY(x));
            x += dx;

        }    

        XYSeries series1 = new SimpleXYSeries(coordinatesX, coordinatesY, "Points");

        LineAndPointFormatter series1Format = new LineAndPointFormatter(Color.rgb(0, 0, 0), Color.rgb(0, 0, 0), null, null);       
        
        multitouchPlot.addSeries(series1, series1Format);

        multitouchPlot.setTicksPerDomainLabel(1);
        multitouchPlot.setRangeStep(XYStepMode.INCREMENT_BY_VAL, 1);
        multitouchPlot.setDomainStep(XYStepMode.INCREMENT_BY_VAL, 1);

        multitouchPlot.setRangeBoundaries(0, 10, BoundaryMode.FIXED);
        multitouchPlot.setDomainBoundaries(0, 10, BoundaryMode.FIXED);

        multitouchPlot.setRangeLabel("Height [m]");
        multitouchPlot.setDomainLabel("Distance [m]");

    }

    public void backToMain(View view) {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }

    public float calculateY(float x) {
        return (x - ((Constants.GRAVITY_OF_EARTH * x * x) / (velocity * velocity)));
    }

}