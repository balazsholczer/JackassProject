package com.epam.android.jackass;

import java.io.File;
import java.util.Arrays;
import java.util.List;
import com.facebook.Request;
import com.facebook.Response;
import com.facebook.Session;
import com.facebook.SessionState;
import com.facebook.UiLifecycleHelper;
import com.facebook.widget.FacebookDialog;
import com.facebook.widget.LoginButton;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

public class PostImageActivity extends Activity{
    
    private static final List<String> PERMISSIONS = Arrays.asList("publish_actions");
    private UiLifecycleHelper uiLifecycleHelper;
    private ImageView imageView;
    private File imageFile;
    private Bitmap photo;
    private LoginButton facebookLoginButton;
    private static final int PHOTO_TAKEN = 1;
    private Session.StatusCallback callback = new Session.StatusCallback() {
        @Override
        public void call(Session session, SessionState state, Exception exception) {
            onSessionStateChange(session, state, exception);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.post_image_layout);

        imageView = (ImageView) findViewById(R.id.image_id);
        imageView.setImageBitmap(BitmapFactory.decodeResource(getResources(), R.drawable.ic_launcher));

        facebookLoginButton = (LoginButton) findViewById(R.id.scores_facebooklogin_button_id);
        facebookLoginButton.setReadPermissions(Arrays.asList("public_profile", "user_status"));   

        uiLifecycleHelper = new UiLifecycleHelper(this, callback);
        uiLifecycleHelper.onCreate(savedInstanceState);

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == PHOTO_TAKEN) {

            photo = BitmapFactory.decodeFile(imageFile.getAbsolutePath());

            if (photo != null) {
                imageView.setImageBitmap(photo);
            } else {
                Toast.makeText(this, "Unable to load file...", Toast.LENGTH_LONG).show();
            }
        }

        uiLifecycleHelper.onActivityResult(requestCode, resultCode, data, new FacebookDialog.Callback() {
            @Override
            public void onError(FacebookDialog.PendingCall pendingCall, Exception error, Bundle data) {
                Log.e("Activity", String.format("Error: %s", error.toString()));
            }

            @Override
            public void onComplete(FacebookDialog.PendingCall pendingCall, Bundle data) {
                Log.i("Activity", "Success!");
            }
        });

    }

    public void postImage(View view) {
        Request request = Request.newUploadPhotoRequest(Session.getActiveSession(), photo, new Request.Callback() {
            @Override
            public void onCompleted(Response response) {
                if (response.getError() == null) {

                }
            }
        });

        Bundle parameters = request.getParameters();
        parameters.putString("message", "Your photo has been posted via Jackass...");
        request.setParameters(parameters);
        Request.executeBatchAsync(request);
        
        Toast.makeText(this, "Posted successfully...", Toast.LENGTH_LONG).show();
    }

    public void takePhoto(View view) {
        File picturesDirectory = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES);
        imageFile = new File(picturesDirectory, "passpoints_image");
        Intent i = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        i.putExtra(MediaStore.EXTRA_OUTPUT, Uri.fromFile(imageFile));
        startActivityForResult(i, PHOTO_TAKEN);
    }
    
    public boolean checkPermissions() {
        Session s = Session.getActiveSession();
        if (s != null) {
            return s.getPermissions().contains("publish_actions");
        } else
            return false;
    }

    public void requestPermissions() {
        Session s = Session.getActiveSession();
        if (s != null)
            s.requestNewPublishPermissions(new Session.NewPermissionsRequest(this, PERMISSIONS));
    }

    private void onSessionStateChange(Session session, SessionState state, Exception exception) {
        if (state.isOpened()) {
            facebookLoginButton.setVisibility(View.GONE);
        } else if (state.isClosed()) {
            facebookLoginButton.setVisibility(View.VISIBLE);          
        }
    }
    
    @Override
    protected void onResume() {
        super.onResume();

        Session session = Session.getActiveSession();
        if (session != null && (session.isOpened() || session.isClosed())) {
            onSessionStateChange(session, session.getState(), null);
        }

        uiLifecycleHelper.onResume();
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        uiLifecycleHelper.onSaveInstanceState(outState);
    }

    @Override
    public void onPause() {
        super.onPause();
        uiLifecycleHelper.onPause();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        uiLifecycleHelper.onDestroy();
    }

}

