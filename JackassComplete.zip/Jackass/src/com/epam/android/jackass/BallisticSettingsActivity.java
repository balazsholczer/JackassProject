package com.epam.android.jackass;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.SeekBar.OnSeekBarChangeListener;

public class BallisticSettingsActivity extends Activity implements OnSeekBarChangeListener {

    private int initialVelocity;
    private SeekBar velocitySeekbar;
    private SeekBar dragSeekbar;
    private SeekBar angleSeekbar;
    private TextView actualVelocity;
    private TextView actualDrag;
    private TextView actualAngle;
    private int velocity;
    private int angle;
    private float drag;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.ballistic_settings_layout);

        initializeSeekbars();
        setListeners();
        
    }
    
    private void setListeners() {
        velocitySeekbar.setOnSeekBarChangeListener(this);
        angleSeekbar.setOnSeekBarChangeListener(this);
        dragSeekbar.setOnSeekBarChangeListener(this);
    }

    private void initializeSeekbars(){
        actualAngle = (TextView) findViewById(R.id.angle_percent);
        actualVelocity = (TextView) findViewById(R.id.velocity_percent);
        actualDrag = (TextView) findViewById(R.id.drag_percent);

        velocity=100;
        drag=1f;
        angle=45;
        
        velocitySeekbar = (SeekBar) findViewById(R.id.velocity_slider);
        velocitySeekbar.setMax(200);
        velocitySeekbar.setProgress(100);   
        
        angleSeekbar = (SeekBar) findViewById(R.id.angle_slider);
        angleSeekbar.setMax(90);
        angleSeekbar.setProgress(45);   

        dragSeekbar = (SeekBar) findViewById(R.id.drag_slider);
        dragSeekbar.setMax(20);
        dragSeekbar.setProgress(10);
    }

    public void startSimulation(View view) {
        Toast.makeText(this, "Velocity: " + velocity + "\nDrag: " + drag +"\nAngle: "+angle+" deg", Toast.LENGTH_SHORT).show();
        Intent intent = new Intent(this,BallisticPlot.class);
        intent.putExtra("velocity", velocity);
        intent.putExtra("drag", drag);
        intent.putExtra("angle", angle);
        startActivity(intent);
    }

    @Override
    public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {

        switch (seekBar.getId()) {
        case R.id.velocity_slider:
            velocity = progress;
            actualVelocity.setText("" + velocity + " m/s");
            break;
        case R.id.drag_slider:
            drag = (float)progress/10;
            actualDrag.setText("" + drag + " kg/s");
            break;
        case R.id.angle_slider:
            angle=progress;
            actualAngle.setText("" + angle+" deg");
            break;    
        }
    }

    @Override
    public void onStartTrackingTouch(SeekBar seekBar) {

    }

    @Override
    public void onStopTrackingTouch(SeekBar seekBar) {

    }
}