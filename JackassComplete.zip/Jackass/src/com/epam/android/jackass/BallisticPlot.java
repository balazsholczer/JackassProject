package com.epam.android.jackass;

import java.util.ArrayList;
import java.util.List;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

import com.androidplot.xy.BoundaryMode;
import com.androidplot.xy.LineAndPointFormatter;
import com.androidplot.xy.SimpleXYSeries;
import com.androidplot.xy.XYPlot;
import com.androidplot.xy.XYSeries;
import com.androidplot.xy.XYStepMode;
import com.epam.android.constants.Constants;

public class BallisticPlot extends Activity {

    private XYPlot mySimpleXYPlot;
    private float velocity;
    private List<Number> coordinatesX;
    private List<Number> coordinatesY;
    private float x = 0;
    private float y = 0;
    private float m = 10;
    private float k = 0.05f;
    private float t = 0;
    private float dt = 0.01f;
    private float vx0;
    private float vy0;
    private float g = 9.81f;
    private int angle;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.graph_view);

        initiateVariables();
        calculateXYCoordinates();
        initiatePlot();

    }

    public void initiateVariables() {
        Intent intent = getIntent();
        velocity = intent.getExtras().getInt("velocity");
        k = intent.getExtras().getFloat("drag");
        angle = intent.getExtras().getInt("angle");

        vx0 = velocity * (float) Math.cos((angle * Constants.PI) / 180);
        vy0 = velocity * (float) Math.sin((angle * Constants.PI) / 180);

        coordinatesY = new ArrayList<Number>();
        coordinatesX = new ArrayList<Number>();
    }

    public void initiatePlot() {
        XYSeries series1 = new SimpleXYSeries(coordinatesX, coordinatesY, "Points");
        MultitouchPlot multitouchPlot = (MultitouchPlot) findViewById(R.id.multitouchPlot);
        LineAndPointFormatter series1Format = new LineAndPointFormatter(Color.rgb(0, 0, 0), Color.rgb(0, 0, 0), null, null);

        multitouchPlot.addSeries(series1, series1Format);

        multitouchPlot.setRangeStep(XYStepMode.INCREMENT_BY_VAL, 100);
        multitouchPlot.setDomainStep(XYStepMode.INCREMENT_BY_VAL, 100);

        multitouchPlot.setRangeBoundaries(0, 300, BoundaryMode.FIXED);
        multitouchPlot.setDomainBoundaries(0, 1000, BoundaryMode.FIXED);

        multitouchPlot.setRangeLabel("Height [m]");
        multitouchPlot.setDomainLabel("Distance [m]");
    }

    public void calculateXYCoordinates() {

        for (;;) {

            if (y < -0.5f)
                break;

            x = (float) (vx0 * ((m / k) * (1 - (Math.exp(-(((k * t) / m)))))));
            coordinatesX.add(x);

            y = (float) (((m / k) * (vy0 + ((m * g) / k)) * (1 - Math.exp(-((k * t) / m))) - ((m * g * t) / k)));
            coordinatesY.add(y);

            t += dt;
        }
    }

    public void backToMain(View view) {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }

}
