package com.epam.android.jackass;

import java.util.List;

import com.epam.android.constants.Constants;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

public class ResultActivity extends Activity {

    private float accelerationScalar;
    private float distance = 0;
    private List<Double> yCoordionates;
    private double dx = 0.1;
    private float velocity;
    private float angle;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.result_layout);

        getArgumentsFromIntent();
        calculateDistance();
        showResults();

    }

    private void showResults() {
        TextView information = (TextView) findViewById(R.id.result_id);

        information.setText("Acceleration: " + accelerationScalar + "\nDistance: " + distance + "m\nTime elapsed: " + timeElapsed() + "s"
                + "\nMax height: " + calculateMaxHeight() + "m");
    }

    private void getArgumentsFromIntent() {

        Intent intent = getIntent();
        String acceleration = intent.getStringExtra("acceleration");
        accelerationScalar = Float.parseFloat(acceleration);
        angle = intent.getFloatExtra("angle", 0.f);

        if (Math.abs(accelerationScalar) < 1) {
            accelerationScalar = 0.f;
        }

    }

    private void calculateDistance() {

        velocity = accelerationScalar * Constants.TIME_OF_ACCELERATION;
        distance = (velocity * velocity) / Constants.GRAVITY_OF_EARTH;
        
        if (distance < 0.5)
            distance = 0;

        if (distance > 1) {
            LoginActivity.databaseManager.updateResult(LoginActivity.getCurrentUserName(), distance);
        }
    }

    public void showPlot(View view) {

        Intent intent = new Intent(this, PlotTrajectoryActivity.class);
        intent.putExtra("velocity", velocity);
        startActivity(intent);

    }

    public void ballisticSimulation(View view) {
        Intent intent = new Intent(this, BallisticSettingsActivity.class);
        startActivity(intent);
    }

    public float timeElapsed() {
        float timeTemp = (2 * velocity) / Constants.GRAVITY_OF_EARTH;

        if (timeTemp < 1)
            return 0.f;

        return timeTemp;
    }

    public float calculateMaxHeight() {
        float heightTemp = ((velocity * velocity) / (4 * Constants.GRAVITY_OF_EARTH));

        if (heightTemp < 0.5)
            return 0.f;

        return heightTemp;
    }
}
