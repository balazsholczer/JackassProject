package com.epam.android.jackass;

import android.hardware.SensorManager;

public class AccelerationValue {

    private double accelerationX;
    private double accelerationY;
    private double accelerationZ;
    private double totalAcceleration;

    public AccelerationValue() {

    }

    public AccelerationValue(double accelerationX, double accelerationY, double accelerationZ, double totalAcceleration) {
        this.accelerationX = accelerationX;
        this.accelerationY = accelerationY;
        this.accelerationZ = accelerationZ;
        this.totalAcceleration = totalAcceleration;
    }

    public double getAccelerationX() {
        return accelerationX;
    }

    public void setAccelerationX(double accelerationX) {
        this.accelerationX = accelerationX;
    }

    public double getAccelerationY() {
        return accelerationY;
    }

    public void setAccelerationY(double accelerationY) {
        this.accelerationY = accelerationY;
    }

    public double getAccelerationZ() {
        return accelerationZ;
    }

    public void setAccelerationZ(double accelerationZ) {
        this.accelerationZ = accelerationZ;
    }

    public double getTotalAcceleration() {
        return totalAcceleration;
    }

    public void setTotalAcceleration(double totalAcceleration) {
        this.totalAcceleration = totalAcceleration;
    }
    
    public String toString() {
        return accelerationX + " - " + accelerationY + " - " + accelerationZ;
    }
    
    public double getAccelerationScalar(){
       return Math.sqrt((accelerationX * accelerationX) + (accelerationY * accelerationY) + (accelerationZ * accelerationZ)) - SensorManager.GRAVITY_EARTH;
    }
    
    public double getAngle(){
        
        double tempX = accelerationX;
        double tempY = 0.0;
        double tempZ = accelerationZ;
        
        // a*b=|a|*|b|*cos(phi)
        
        double absAcc = getAccelerationScalar();
        double absTemp = Math.sqrt((accelerationX * accelerationX) + (accelerationZ * accelerationZ));
        double absTogether= absAcc*absTemp;
        
        return Math.acos( ((accelerationX*tempX)+(accelerationZ*tempZ))/absTogether );            
    }
}
