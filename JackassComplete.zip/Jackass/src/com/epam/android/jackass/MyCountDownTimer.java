package com.epam.android.jackass;

import android.os.CountDownTimer;

public class MyCountDownTimer extends CountDownTimer {

    private volatile boolean running = false;

    public MyCountDownTimer(long millisInFuture, long countDownInterval) {
            super(millisInFuture, countDownInterval);
    }

    @Override
    public void onFinish() {
            running = false;
    }

    @Override
    public void onTick(long millisUntilFinished) {
            running = true;
    }

    public boolean isRunning() {
            return running;
    }

    public void cancelTimer() {
            running = false;
            cancel();
    }
}