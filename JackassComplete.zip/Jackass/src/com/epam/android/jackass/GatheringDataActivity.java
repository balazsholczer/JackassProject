package com.epam.android.jackass;

import java.util.ArrayList;
import java.util.List;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.location.Criteria;
import android.os.Bundle;

public class GatheringDataActivity extends Activity implements SensorEventListener {

    private List<AccelerationValue> accelerations;
    SensorEvent lastEvent;
    MyCountDownTimer timer;
    private SensorManager manager;

    public GatheringDataActivity() {
        accelerations = new ArrayList<AccelerationValue>();
        accelerations.add(new AccelerationValue(0,0,0,0));
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.gathering_data);

        manager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        Sensor accelSensor = manager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        manager.registerListener(this, accelSensor, SensorManager.SENSOR_DELAY_FASTEST);

        timer = new MyCountDownTimer(5000, 1000);
        timer.start();

    }

    @Override
    protected void onStop() {
        super.onStop();
        timer.cancelTimer();
    }

    @Override
    public void onSensorChanged(SensorEvent event) {

        double tempAccelerationX = event.values[0];
        double tempAccelerationY = event.values[1]; // this is the Y, the direction of g
        double tempAccelerationZ = event.values[2];
        double totalAcceleration = Math.sqrt((tempAccelerationX * tempAccelerationX) + (tempAccelerationY * tempAccelerationY)
                + (tempAccelerationZ * tempAccelerationZ))
                - SensorManager.GRAVITY_EARTH;

        if (timer.isRunning()) {
            accelerations.add(new AccelerationValue(tempAccelerationX, tempAccelerationY, tempAccelerationZ, totalAcceleration));
        } else {
            manager.unregisterListener(this);         
            evaluateMethod();          
        }
    }

    private void evaluateMethod()  {
        
            AccelerationValue tempAcc = new AccelerationValue();
            double tempMax = accelerations.get(0).getAccelerationScalar();
            
            for (AccelerationValue acceleratioValue : accelerations) {
                if (acceleratioValue.getAccelerationScalar() > tempMax) {
                    tempMax = acceleratioValue.getAccelerationScalar();
                    tempAcc = acceleratioValue;
                }
            }
            
            double tempX = tempAcc.getAccelerationX();
            double tempZ = tempAcc.getAccelerationZ();
            
            // a*b=|a|*|b|*cos(phi)
            
            double absAcc = tempAcc.getAccelerationScalar();
            double absTemp = Math.sqrt((tempX * tempX) + (tempZ * tempZ));
            double absTogether= absAcc*absTemp;        
            double angle =  Math.acos( ((tempAcc.getAccelerationX()*tempX)+(tempAcc.getAccelerationZ()*tempZ))/absTogether );                
            
            Intent intent = new Intent(this, ResultActivity.class);
            intent.putExtra("acceleration", "" + tempMax);         
            startActivity(intent);
        
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {
        Criteria c = new Criteria();
        c.setAccuracy(Criteria.ACCURACY_FINE);
    }
}
