package com.epam.android.jackass;

import model.DatabaseManager;
import model.DatabaseSingleton;
import model.User;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class LoginActivity extends Activity {

    private EditText username;
    private EditText password;
    public static DatabaseManager databaseManager;
    public static String currentUserName;
    public static User currentUser;
    private String errorMessage = "Registration cancelled...";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.login_layout);
        initializeVariables();

    }

    private void initializeVariables() {
        username = (EditText) findViewById(R.id.login_username_id);
        password = (EditText) findViewById(R.id.login_password_id);
        databaseManager = new DatabaseManager(this);
    }

    public void loginUser(View view) {
        if (databaseManager.validateUser(username.getText().toString(), password.getText().toString())) {

            currentUserName = username.getText().toString();
            Intent intent = new Intent(this, MainActivity.class);
            startActivity(intent);

        } else {
            Toast.makeText(this, "Login error..", Toast.LENGTH_SHORT).show();
        }
    }

    public void registrateUser(View view) {

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Registration");
        builder.setIcon(R.drawable.ballistic);

        final View dialogView = LayoutInflater.from(getApplicationContext()).inflate(R.layout.registration_layout, null);
        builder.setView(dialogView);

        OnClickListener myListener = new OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog, int which) {
                if (DialogInterface.BUTTON_POSITIVE == which) {

                    EditText username = (EditText) dialogView.findViewById(R.id.registration_username_id);
                    EditText password = (EditText) dialogView.findViewById(R.id.registration_password_id);
                    EditText passwordAgain = (EditText) dialogView.findViewById(R.id.registration_password_again_id);

                    if (isUsernameCorrect(username.getText().toString())) {
                        if (isPasswordsCorrect(username.getText().toString(), password.getText().toString(), passwordAgain.getText().toString())) {

                            User user = new User(username.getText().toString(), password.getText().toString(), 0);
                            databaseManager.insertUser(user);

                            errorMessage = "Successful registration...";

                            username.setText("");
                            password.setText("");

                        } else {
                            errorMessage = "Passwords do not match or username already in use...";
                        }
                    } else {
                        errorMessage = "Invalid username...";
                    }

                }

                Toast.makeText(LoginActivity.this, errorMessage, Toast.LENGTH_SHORT).show();

                username.setText("");
                password.setText("");

            }
        };

        builder.setPositiveButton("Ok", myListener);
        builder.setNegativeButton("Cancel", myListener);

        builder.create().show();

    }

    public boolean isUsernameCorrect(String username) {
        if (username != null && !username.equals("")) {
            return true;
        }
        return false;
    }

    public boolean isPasswordsCorrect(String username, String password, String passwordAgain) {
        if (!password.equals("") && password != null && password.equals(passwordAgain) && databaseManager.notDuplicated(username)) {
            return true;
        }
        return false;
    }

    public static String getCurrentUserName() {
        return currentUserName;
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        databaseManager.closeDatabase();
    }
}
