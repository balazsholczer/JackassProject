package com.epam.android.jackass;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.net.URLConnection;
import java.util.Arrays;
import java.util.List;

import model.User;
import android.app.Activity;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.provider.MediaStore.Images.Media;
import android.support.v4.app.NotificationCompat;
import android.util.Log;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import com.facebook.Request;
import com.facebook.Response;
import com.facebook.Session;
import com.facebook.SessionState;
import com.facebook.UiLifecycleHelper;
import com.facebook.widget.FacebookDialog;
import com.facebook.widget.LoginButton;

public class ScoresActivity extends Activity {

    private static final List<String> PERMISSIONS = Arrays.asList("publish_actions");
    private TextView scoresTextView;
    private int count = 0;
    private UiLifecycleHelper uiLifecycleHelper;
    private LoginButton facebookLoginButton;
    private User currentUser;
    private ImageButton shareFeacebookButton;
    private static final int PHOTO_TAKEN = 3456;
    private File imageFile;
    private static final int BROWSE_GALLERY_REQUEST = 1;

    private Session.StatusCallback callback = new Session.StatusCallback() {
        @Override
        public void call(Session session, SessionState state, Exception exception) {
            onSessionStateChange(session, state, exception);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.scores_layout);

        initializeVariables(savedInstanceState);
        showCurrentScores();

    }

    private void showCurrentScores() {

        List<User> users = LoginActivity.databaseManager.getAllUsers();

        TableLayout tableLayout = (TableLayout) findViewById(R.id.myTableLayout);

        TableRow row1 = new TableRow(this);
        TextView ranking = new TextView(this);
        ranking.setPadding(5, 5, 5, 5);
        ranking.setText("Ranking");
        ranking.setTypeface(ranking.getTypeface(), Typeface.BOLD);
        ranking.setGravity(android.view.Gravity.CENTER);
        ranking.setBackground(getResources().getDrawable(R.drawable.title_cell));
        TextView username = new TextView(this);
        username.setText("Username");
        username.setTypeface(username.getTypeface(), Typeface.BOLD);
        username.setGravity(android.view.Gravity.CENTER);
        username.setBackground(getResources().getDrawable(R.drawable.title_cell));
        username.setPadding(5, 5, 5, 5);
        TextView distance = new TextView(this);
        distance.setText("Distance [m]");
        distance.setBackground(getResources().getDrawable(R.drawable.title_cell));
        distance.setGravity(android.view.Gravity.CENTER);
        distance.setTypeface(username.getTypeface(), Typeface.BOLD);
        distance.setPadding(5, 5, 5, 5);
        row1.addView(ranking);
        row1.addView(username);
        row1.addView(distance);
        tableLayout.addView(row1);

        // population table rows from database 
        for (User user : users) {

            if (user.getUsername().equals(LoginActivity.currentUserName)) {
                currentUser = user;
            }

            count++;

            TableRow rowTemp = new TableRow(this);

            TextView rankingTemp = new TextView(this);
            rankingTemp.setText("" + count);
            rankingTemp.setBackground(getResources().getDrawable(R.drawable.cell_shape));
            rankingTemp.setGravity(android.view.Gravity.CENTER);

            TextView usernameTemp = new TextView(this);
            usernameTemp.setText(user.getUsername());
            usernameTemp.setBackground(getResources().getDrawable(R.drawable.cell_shape));
            usernameTemp.setGravity(android.view.Gravity.CENTER);
            TextView distanceTemp = new TextView(this);

            distanceTemp.setText("" + user.getDistanceOfThrow());
            distanceTemp.setBackground(getResources().getDrawable(R.drawable.cell_shape));
            distanceTemp.setGravity(android.view.Gravity.CENTER);

            rowTemp.addView(rankingTemp);
            rowTemp.addView(usernameTemp);
            rowTemp.addView(distanceTemp);

            tableLayout.addView(rowTemp);

        }

        tableLayout.invalidate();
    }

    private void initializeVariables(Bundle savedInstanceState) {
        //scoresTextView = (TextView) findViewById(R.id.scores_text_id);
        facebookLoginButton = (LoginButton) findViewById(R.id.scores_facebooklogin_button_id);
        facebookLoginButton.setReadPermissions(Arrays.asList("public_profile", "user_status"));

        shareFeacebookButton = (ImageButton) findViewById(R.id.score_layout_sharefacebook);

        uiLifecycleHelper = new UiLifecycleHelper(this, callback);
        uiLifecycleHelper.onCreate(savedInstanceState);

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        uiLifecycleHelper.onActivityResult(requestCode, resultCode, data, new FacebookDialog.Callback() {
            @Override
            public void onError(FacebookDialog.PendingCall pendingCall, Exception error, Bundle data) {
                Log.e("Activity", String.format("Error: %s", error.toString()));
            }

            @Override
            public void onComplete(FacebookDialog.PendingCall pendingCall, Bundle data) {
                Log.i("Activity", "Success!");
            }
        });            

    }

    public void postOnFacebook(View view) {

        Session.openActiveSession(this, true, new Session.StatusCallback() {
            @Override
            public void call(Session session, SessionState state, Exception exception) {
                if (checkPermissions()) {

                    Request request = Request.newStatusUpdateRequest(Session.getActiveSession(), "This is a post via Jackass app...\nPlayer name: "
                            + currentUser.getUsername() + "\nDistance: " + currentUser.getDistanceOfThrow()+"m", new Request.Callback() {

                        @Override
                        public void onCompleted(Response response) {
                            if (response.getError() == null) {

                            }
                        }

                    });
                    request.executeAsync();
                    showNotification();

                } else {
                    requestPermissions();
                }

            }
        });
    }

    public void postImageOnFacebook(View view) {      

                Request request = Request.newUploadPhotoRequest(Session.getActiveSession(), BitmapFactory.decodeResource(getResources(), R.drawable.minimal_design),
                        new Request.Callback() {
        
                            @Override
                            public void onCompleted(Response response) {
                                if (response.getError() == null) {
                                    
                                }
                            }
        
                        });     
                
                Bundle parameters = request.getParameters();
                parameters.putString("message", "Yout image on Jackass...");
                request.setParameters(parameters);
                Request.executeBatchAsync(request);
    }

    public boolean checkPermissions() {
        Session s = Session.getActiveSession();
        if (s != null) {
            return s.getPermissions().contains("publish_actions");
        } else
            return false;
    }

    public void requestPermissions() {
        Session s = Session.getActiveSession();
        if (s != null)
            s.requestNewPublishPermissions(new Session.NewPermissionsRequest(this, PERMISSIONS));
    }

    private void onSessionStateChange(Session session, SessionState state, Exception exception) {
        if (state.isOpened()) {
            facebookLoginButton.setVisibility(View.GONE);
            shareFeacebookButton.setVisibility(View.VISIBLE);
        } else if (state.isClosed()) {
            facebookLoginButton.setVisibility(View.VISIBLE);
            shareFeacebookButton.setVisibility(View.INVISIBLE);
        }
    }

    public void showNotification() {
        NotificationCompat.Builder mBuilder = new NotificationCompat.Builder(this).setSmallIcon(R.drawable.ballistic).setContentTitle("Sharing")
                .setContentText("Successfull sharing on facebook...");

        mBuilder.setAutoCancel(true);

        NotificationManager mNotificationManager = (NotificationManager) getSystemService(this.NOTIFICATION_SERVICE);

        mNotificationManager.notify(1234, mBuilder.build());
    }

    @Override
    protected void onResume() {
        super.onResume();

        Session session = Session.getActiveSession();
        if (session != null && (session.isOpened() || session.isClosed())) {
            onSessionStateChange(session, session.getState(), null);
        }

        uiLifecycleHelper.onResume();
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        uiLifecycleHelper.onSaveInstanceState(outState);
    }

    @Override
    public void onPause() {
        super.onPause();
        uiLifecycleHelper.onPause();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        uiLifecycleHelper.onDestroy();
    }
}
