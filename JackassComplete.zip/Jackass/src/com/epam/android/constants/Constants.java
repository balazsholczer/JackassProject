package com.epam.android.constants;

public class Constants {

    public static final float PI = 3.14159f;
    public static final float GRAVITY_OF_EARTH = 9.83f;
    public static final float TIME_OF_ACCELERATION = 0.5f;
    
}
