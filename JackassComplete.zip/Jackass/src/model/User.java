package model;

public class User {
    
    private String username; 
    private String password;
    private float distanceOfThrow = 0.0f;

    public User() {

    }

    public User(String username, String password, float distanceOfThrow) {
  
        this.username = username;
        this.password = password;
        this.distanceOfThrow = distanceOfThrow;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

   

    public float getDistanceOfThrow() {
        return distanceOfThrow;
    }

    public void setDistanceOfThrow(float distanceOfThrow) {
        this.distanceOfThrow = distanceOfThrow;
    }
}
