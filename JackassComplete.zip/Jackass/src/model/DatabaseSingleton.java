package model;

import android.content.Context;

public class DatabaseSingleton {

    private static DatabaseManager databaseManagerInstance;
    
    private DatabaseSingleton(){
        
    }
    
    public static DatabaseManager getInsatnce(){
        return databaseManagerInstance;
    }
    
   public static void setDatabaseContext(Context context){  
       databaseManagerInstance = new DatabaseManager(context);
   }
}
