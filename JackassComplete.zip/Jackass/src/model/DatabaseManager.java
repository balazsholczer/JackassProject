package model;

import java.util.ArrayList;
import java.util.List;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.epam.android.jackass.EncryptionClass;

public class DatabaseManager extends SQLiteOpenHelper {

    private SQLiteDatabase database;
    private static final String USER_TABLE = "user_table";
    private static final String USER_ID = "user_id";
    private static final String USER_USERNAME = "user_username";
    private static final String USER_PASSWORD = "user_password";
    private static final String USER_MAX_DISTANCE = "user_max_distance";
    private static final String CREATE_TABLE_USER = "CREATE TABLE " + USER_TABLE + " ( " + USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT , "
            + USER_USERNAME + " TEXT , " + USER_PASSWORD + " TEXT , " + USER_MAX_DISTANCE + " INTEGER );";

    public DatabaseManager(Context applicationContext) {
        super(applicationContext, "my database", null, 1);
        database = getWritableDatabase();
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        database=db;
        database.execSQL(CREATE_TABLE_USER);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        database.execSQL("DROP TABLE " + USER_TABLE);
        onCreate(db);
    }

    public List<User> getAllUsers() {

        List<User> users = new ArrayList<User>();
        Cursor result = database.query(USER_TABLE, null, null, null, null, null, USER_MAX_DISTANCE + " DESC");

        if (result.moveToFirst()) {
            do {      
                String username = result.getString(result.getColumnIndex(USER_USERNAME));
                String password = result.getString(result.getColumnIndex(USER_PASSWORD));
                float maxDistance = result.getFloat(result.getColumnIndex(USER_MAX_DISTANCE));

                User user = new User(username, password, maxDistance);
                users.add(user);

            } while (result.moveToNext());
        }

        return users;
    }

    public void insertUser(User user) {
              
        String passwordHash = EncryptionClass.MD5(user.getPassword());
        user.setPassword(passwordHash);

        ContentValues contentValues = new ContentValues();

        contentValues.put(USER_USERNAME, user.getUsername());
        contentValues.put(USER_PASSWORD, user.getPassword());
        contentValues.put(USER_MAX_DISTANCE, user.getDistanceOfThrow());

        database.insert(USER_TABLE, null, contentValues);
    }

    public void closeDatabase() {
        database.close();
    }

    public boolean validateUser(String username, String passwordClearText) {

        String passwordCrypted = EncryptionClass.MD5(passwordClearText);
        Cursor cursor = database.query(USER_TABLE, null, USER_USERNAME + " = ? AND " + USER_PASSWORD + " = ? ", new String[]{username,
            passwordCrypted}, null, null, null);

        if (cursor.moveToNext()) {
            return true;
        }

        return false;
    }

    public void updateResult(String currentUserName, float distance) {

        User user = null;
        Cursor cursor = database.query(USER_TABLE, null, USER_USERNAME + " = ? ", new String[]{currentUserName}, null, null, null);

        if (cursor.moveToFirst()) {
            do {
                String username = cursor.getString(cursor.getColumnIndex(USER_USERNAME));
                String password = cursor.getString(cursor.getColumnIndex(USER_PASSWORD));
                float maxDistance = cursor.getFloat(cursor.getColumnIndex(USER_MAX_DISTANCE));

                user = new User(username, password, maxDistance);

            } while (cursor.moveToNext());
        }

        if (user.getDistanceOfThrow() < distance) {
            ContentValues args = new ContentValues();
            args.put(USER_MAX_DISTANCE, distance);
            database.update(USER_TABLE, args, String.format("%s = ?", USER_USERNAME), new String[]{user.getUsername()});
        }
    }

    public boolean notDuplicated(String name) {

        Cursor cursor = database.query(USER_TABLE, null, USER_USERNAME + " = ? ", new String[]{name}, null, null, null);

        if (cursor.moveToNext()) {
            return false;
        }

        return true;
    }
    
    public void clearDatabase(){
        database.execSQL("DROP TABLE " + USER_TABLE);
        database.execSQL(CREATE_TABLE_USER);
    }
}
