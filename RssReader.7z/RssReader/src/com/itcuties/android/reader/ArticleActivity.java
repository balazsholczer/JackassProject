package com.itcuties.android.reader;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebView;

import com.itcuties.android.reader.util.MyBrowser;

public class ArticleActivity extends Activity {

	private WebView browser;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.article_layout);
		
		Intent intent = getIntent();
		String url = intent.getExtras().getString("url");

		browser = (WebView) findViewById(R.id.webView);
		browser.setWebViewClient(new MyBrowser());

		browser.getSettings().setLoadsImagesAutomatically(true);
		browser.getSettings().setJavaScriptEnabled(true);
		browser.setScrollBarStyle(View.SCROLLBARS_INSIDE_OVERLAY);
		browser.loadUrl(url);
	}
}
