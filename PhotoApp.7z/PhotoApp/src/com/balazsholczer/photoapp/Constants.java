package com.balazsholczer.photoapp;

public class Constants {

	private Constants(){
		
	}

	public static final int RESULT_LOAD_IMAGE = 0;
	public static final int PHOTO_TAKEN = 1;
	public static int ACTUAL_POSITION_DEGREE = 0;

}
