package com.balazsholczer.photoapp;

import java.io.IOException;
import java.io.InputStream;

import android.content.ContentResolver;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;

public final class ImageUtils {
	
	private ImageUtils() {
	}
	
	public static Bitmap decodeBitmapByUri(ContentResolver contentResolver, Uri imageUri, int desiredWidth, int desiredHeight) {
		Bitmap bmp = null;
		InputStream inputStream = null;
		try {
			inputStream = contentResolver.openInputStream(imageUri);

			BitmapFactory.Options options = new BitmapFactory.Options();
			options.inJustDecodeBounds = true;
			BitmapFactory.decodeStream(inputStream, null, options);
			closeStream(inputStream);
			
			options.inSampleSize = calculateInSampleSize(options, desiredWidth, desiredHeight);
			
			inputStream = contentResolver.openInputStream(imageUri);
			
		    options.inJustDecodeBounds = false;
			bmp = BitmapFactory.decodeStream(inputStream, null, options);
			
		} catch (Exception e) {
			//throw new RuntimeException("Can't decode image", e);
		} finally {
			closeStream(inputStream);
		}
		
		return bmp;
	}
	
	private static void closeStream(InputStream in) {
		if (in != null) {
			try {
				in.close();
			} catch (IOException e) {
			}
		}
	}

	private static int calculateInSampleSize(BitmapFactory.Options options, int reqWidth, int reqHeight) {
		
		final int height = options.outHeight;
		final int width = options.outWidth;
		int inSampleSize = 1;

		if (height > reqHeight || width > reqWidth) {
			while ((height / inSampleSize) > reqHeight && (width / inSampleSize) > reqWidth) {
				inSampleSize *= 2;
			}
		}

		return inSampleSize;
	}
}
