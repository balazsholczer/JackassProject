package com.balazsholczer.photoapp;

import android.graphics.Bitmap;
import android.graphics.Bitmap.Config;
import android.graphics.BlurMaskFilter;
import android.graphics.BlurMaskFilter.Blur;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Point;
import android.graphics.PorterDuff;
import android.graphics.PorterDuff.Mode;
import android.graphics.PorterDuffXfermode;
import android.graphics.Rect;
import android.graphics.RectF;

public class ImageEffects {
	
	private ConvolutionMatrix convolutionMatrix;
	
	public ImageEffects(){
		this.convolutionMatrix = new ConvolutionMatrix(3);
	}

	public Bitmap doHighlightImage(Bitmap sourceBitmap){
		
	    Bitmap resultBitmap = Bitmap.createBitmap(sourceBitmap.getWidth() + 96, sourceBitmap.getHeight() + 96, Bitmap.Config.ARGB_8888);
	    Canvas canvas = new Canvas(resultBitmap);
	    canvas.drawColor(0, PorterDuff.Mode.CLEAR);
	 
	    Paint paintBlur = new Paint();
	    paintBlur.setMaskFilter(new BlurMaskFilter(100, Blur.NORMAL));
	    int[] offsetXY = new int[2];
	    
	    Bitmap bmAlpha = sourceBitmap.extractAlpha(paintBlur, offsetXY);
	   
	    Paint paintAlphaColor = new Paint();
	    paintAlphaColor.setColor(0xFFFFFFFF);
	    canvas.drawBitmap(bmAlpha, offsetXY[0], offsetXY[1], paintAlphaColor);
	    
	    bmAlpha.recycle();
	    canvas.drawBitmap(sourceBitmap, 0, 0, null);
	 
	    return resultBitmap;
	}
	
	public Bitmap doInvert(Bitmap src) {
	 
	    Bitmap bmOut = Bitmap.createBitmap(src.getWidth(), src.getHeight(), src.getConfig());
	   
	    int A, R, G, B;
	    int pixelColor;
	    int height = src.getHeight();
	    int width = src.getWidth();
	 
	    for (int y = 0; y < height; y++)
	    {
	        for (int x = 0; x < width; x++)
	        {         
	            pixelColor = src.getPixel(x, y);	       
	            A = Color.alpha(pixelColor);	         
	            R = 255 - Color.red(pixelColor);
	            G = 255 - Color.green(pixelColor);
	            B = 255 - Color.blue(pixelColor);          
	            bmOut.setPixel(x, y, Color.argb(A, R, G, B));
	        }
	    }
	
	    return bmOut;
	}
	
	public Bitmap doGreyscale(Bitmap src) {
		final double GS_RED = 0.299;
	    final double GS_GREEN = 0.587;
	    final double GS_BLUE = 0.114;
	 
	    Bitmap bmOut = Bitmap.createBitmap(src.getWidth(), src.getHeight(), src.getConfig());
	
	    int A, R, G, B;
	    int pixel;
	 
	    int width = src.getWidth();
	    int height = src.getHeight();
	 
	    for(int x = 0; x < width; ++x) {
	        for(int y = 0; y < height; ++y) {           
	            pixel = src.getPixel(x, y);	           
	            A = Color.alpha(pixel);
	            R = Color.red(pixel);
	            G = Color.green(pixel);
	            B = Color.blue(pixel);
          
	            R = G = B = (int)(GS_RED * R + GS_GREEN * G + GS_BLUE * B);
	         
	            bmOut.setPixel(x, y, Color.argb(A, R, G, B));
	        }
	    }
	 
	    return bmOut;
	}
	
	public Bitmap createSepiaToningEffect(Bitmap src, int depth, double red, double green, double blue) {
	   
	    int width = src.getWidth();
	    int height = src.getHeight();
	   
	    Bitmap bmOut = Bitmap.createBitmap(width, height, src.getConfig());
	  
	    final double GS_RED = 0.3;
	    final double GS_GREEN = 0.59;
	    final double GS_BLUE = 0.11;
	  
	    int A, R, G, B;
	    int pixel;
	 	  
	    for(int x = 0; x < width; ++x) {
	        for(int y = 0; y < height; ++y) {          
	            pixel = src.getPixel(x, y);
	            A = Color.alpha(pixel);
	            R = Color.red(pixel);
	            G = Color.green(pixel);
	            B = Color.blue(pixel);	         
	            B = G = R = (int)(GS_RED * R + GS_GREEN * G + GS_BLUE * B);
	 
	            R += (depth * red);
	            if(R > 255) { R = 255; }
	 
	            G += (depth * green);
	            if(G > 255) { G = 255; }
	 
	            B += (depth * blue);
	            if(B > 255) { B = 255; }	 
	         
	            bmOut.setPixel(x, y, Color.argb(A, R, G, B));
	        }
	    }
	 	  
	    return bmOut;
	}
	
	public Bitmap doBrightness(Bitmap src, int value) {
	   
	    int width = src.getWidth();
	    int height = src.getHeight();
	  
	    Bitmap bmOut = Bitmap.createBitmap(width, height, src.getConfig());
	    
	    int A, R, G, B;
	    int pixel;
	   
	    for(int x = 0; x < width; ++x) {
	        for(int y = 0; y < height; ++y) {         
	            pixel = src.getPixel(x, y);
	            A = Color.alpha(pixel);
	            R = Color.red(pixel);
	            G = Color.green(pixel);
	            B = Color.blue(pixel);
	     
	            R += value;
	            if(R > 255) { R = 255; }
	            else if(R < 0) { R = 0; }
	 
	            G += value;
	            if(G > 255) { G = 255; }
	            else if(G < 0) { G = 0; }
	 
	            B += value;
	            if(B > 255) { B = 255; }
	            else if(B < 0) { B = 0; }
	 
	            bmOut.setPixel(x, y, Color.argb(A, R, G, B));
	        }
	    }
	 
	    return bmOut;
	}
	
	public Bitmap applyMeanRemoval(Bitmap src) {
	    double[][] MeanRemovalConfig = new double[][] {
	        { -1 , -1, -1 },
	        { -1 ,  9, -1 },
	        { -1 , -1, -1 }
	    };
	    ConvolutionMatrix convMatrix = new ConvolutionMatrix(3);
	    convMatrix.applyConfig(MeanRemovalConfig);
	    convMatrix.Factor = 1;
	    convMatrix.Offset = 0;
	    return convolutionMatrix.computeConvolution3x3(src, convMatrix);
	}
	
	public Bitmap emboss(Bitmap src) {
	    double[][] EmbossConfig = new double[][] {
	        { -1 ,  0, -1 },
	        {  0 ,  4,  0 },
	        { -1 ,  0, -1 }
	    };
	    ConvolutionMatrix convMatrix = new ConvolutionMatrix(3);
	    convMatrix.applyConfig(EmbossConfig);
	    convMatrix.Factor = 1;
	    convMatrix.Offset = 127;
	    return convolutionMatrix.computeConvolution3x3(src, convMatrix);
	}
	
	public Bitmap boost(Bitmap src, int type, float percent) {
	    int width = src.getWidth();
	    int height = src.getHeight();
	    Bitmap bmOut = Bitmap.createBitmap(width, height, src.getConfig());
	 
	    int A, R, G, B;
	    int pixel;
	 
	    for(int x = 0; x < width; ++x) {
	        for(int y = 0; y < height; ++y) {
	            pixel = src.getPixel(x, y);
	            A = Color.alpha(pixel);
	            R = Color.red(pixel);
	            G = Color.green(pixel);
	            B = Color.blue(pixel);
	            if(type == 1) {
	                R = (int)(R * (1 + percent));
	                if(R > 255) R = 255;
	            }
	            else if(type == 2) {
	                G = (int)(G * (1 + percent));
	                if(G > 255) G = 255;
	            }
	            else if(type == 3) {
	                B = (int)(B * (1 + percent));
	                if(B > 255) B = 255;
	            }
	            bmOut.setPixel(x, y, Color.argb(A, R, G, B));
	        }
	    }
	    return bmOut;
	}
	
	public Bitmap roundCorner(Bitmap src, float round) {
	   
	    int width = src.getWidth();
	    int height = src.getHeight();
	   
	    Bitmap result = Bitmap.createBitmap(width, height, Config.ARGB_8888);
	    
	    Canvas canvas = new Canvas(result);
	    canvas.drawARGB(0, 0, 0, 0);
	 
	    final Paint paint = new Paint();
	    paint.setAntiAlias(true);
	    paint.setColor(Color.BLACK);
	 
	    final Rect rect = new Rect(0, 0, width, height);
	    final RectF rectF = new RectF(rect);
	 
	    canvas.drawRoundRect(rectF, round, round, paint);
	 
	    paint.setXfermode(new PorterDuffXfermode(Mode.SRC_IN));
	    canvas.drawBitmap(src, rect, rect, paint);
	 
	    return result;
	}
	
	public Bitmap drawText(Bitmap src, String watermark, Point location, int alpha, int size, boolean underline) {
	    int w = src.getWidth();
	    int h = src.getHeight();
	    Bitmap result = Bitmap.createBitmap(w, h, src.getConfig());
	 
	    Canvas canvas = new Canvas(result);
	    canvas.drawBitmap(src, 0, 0, null);
	 
	    Paint paint = new Paint();
	    paint.setColor(Color.RED);
	    paint.setAlpha(alpha);
	    paint.setTextSize(size);
	    paint.setAntiAlias(true);
	    paint.setUnderlineText(underline);
	    canvas.drawText(watermark, location.x, location.y, paint);
	 
	    return result;
	}
}
