package com.balazsholczer.photoapp;

import java.io.ByteArrayOutputStream;
import java.io.OutputStream;

import uk.co.senab.photoview.PhotoViewAttacher;
import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Matrix;
import android.graphics.Point;
import android.net.Uri;
import android.opengl.Visibility;
import android.os.AsyncTask;
import android.os.Bundle;
import android.provider.MediaStore;
import android.provider.MediaStore.Images;
import android.util.Log;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.SeekBar.OnSeekBarChangeListener;
import android.widget.TextView;
import android.widget.TextView.OnEditorActionListener;

public class MainActivity extends Activity implements OnClickListener {

	private PhotoViewAttacher photoViewAttacher;
	private ImageView photo;
	private ImageView rotateLeftImageView;
	private ImageView rotateRightImageView;
	private Bitmap actualPhoto;
	private Bitmap originalImage;
	private ImageEffects imageEffects;
	private SeekBar seekBar;
	private EditText editText;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		photo = (ImageView) findViewById(R.id.mainPhoto);
		photo.setOnClickListener(this);
		
		imageEffects = new ImageEffects();
		
		seekBar = (SeekBar) findViewById(R.id.mySeekBar);
		editText = (EditText) findViewById(R.id.textToShow);
		
		editText.setOnEditorActionListener(new OnEditorActionListener() {		
			public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
				actualPhoto = imageEffects.drawText(actualPhoto, ""+v.getText().toString(), new Point(100, 100), 100, 50, false);
				photo.setImageBitmap(actualPhoto);
				editText.setVisibility(View.GONE);
				return false;
			}
		});
		
		seekBar.setOnSeekBarChangeListener(new OnSeekBarChangeListener() {
			public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser){
				actualPhoto = imageEffects.doBrightness(originalImage,progress);
				photo.setImageBitmap(actualPhoto);
			}

			public void onStartTrackingTouch(SeekBar seekBar) {
			}

			public void onStopTrackingTouch(SeekBar seekBar) {
			}
		});

		rotateLeftImageView = (ImageView) findViewById(R.id.rotateLeftImageView);
		rotateLeftImageView.setOnClickListener(this);

		rotateRightImageView = (ImageView) findViewById(R.id.rotateRightImageView);
		rotateRightImageView.setOnClickListener(this);

		photoViewAttacher = new PhotoViewAttacher(photo);
		photoViewAttacher.update();
	}

	public void snapPhoto(View view) {
		Intent i = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
		startActivityForResult(i, Constants.PHOTO_TAKEN);
	}

	public void loadPhoto(View view) {
		Intent intent = new Intent(Intent.ACTION_PICK,android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
		startActivityForResult(intent, Constants.RESULT_LOAD_IMAGE);
	}

	public void sharePhoto(View view) {
		Intent share = new Intent(Intent.ACTION_SEND);
		share.setType("image/*");

		ContentValues values = new ContentValues();
		values.put(Images.Media.TITLE, "title");
		values.put(Images.Media.MIME_TYPE, "image/jpeg");

		Uri uri = getImageUri(actualPhoto);

		OutputStream outstream;
		try {
			outstream = getContentResolver().openOutputStream(uri);
			actualPhoto.compress(Bitmap.CompressFormat.JPEG, 100, outstream);
			outstream.close();
		} catch (Exception e) {
			System.err.println(e.toString());
		}

		share.putExtra(Intent.EXTRA_TEXT, "http://www.google.com");
		share.putExtra(Intent.EXTRA_STREAM, uri);
		startActivity(Intent.createChooser(share, "Share Image"));
	}

	public Uri getImageUri(Bitmap inImage) {
		ByteArrayOutputStream bytes = new ByteArrayOutputStream();
		inImage.compress(Bitmap.CompressFormat.JPEG, 100, bytes);
		String path = Images.Media.insertImage(getContentResolver(), inImage,
				"Title", null);
		return Uri.parse(path);
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		super.onActivityResult(requestCode, resultCode, data);

		if (requestCode == Constants.RESULT_LOAD_IMAGE && resultCode == RESULT_OK
				&& data != null) {
			loadSelectedImage(data);
		} else if (requestCode == Constants.PHOTO_TAKEN && resultCode == RESULT_OK
				&& data != null) {
			loadSelectedImage(data);
		}
	}

	private void loadSelectedImage(Intent data) {
		Uri imageUri = data.getData();
		new ImageLoaderTask().execute(imageUri);
	}

	class ImageLoaderTask extends AsyncTask<Uri, Void, Bitmap> {

		@Override
		protected Bitmap doInBackground(Uri... params) {
			Uri imageUri = params[0];
			int width = photo.getWidth();
			int height = photo.getHeight();
			return ImageUtils.decodeBitmapByUri(getContentResolver(), imageUri, width, height);
		}

		@Override
		protected void onPostExecute(Bitmap result) {
			if (result != null) {
				MainActivity.this.actualPhoto = result;
				MainActivity.this.originalImage=result;
				rotateAndShowImage(Rotation.NONE);
			}
		}
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		MenuInflater inflater = getMenuInflater();
		inflater.inflate(R.menu.main, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		
		seekBar.setVisibility(View.GONE);
		editText.setVisibility(View.GONE);
		
		originalImage=actualPhoto;
		
		switch (item.getItemId()) {
		case R.id.action_highlight:
			actualPhoto = imageEffects.doHighlightImage(actualPhoto);
			photo.setImageBitmap(actualPhoto);
			return true;
		case R.id.action_invert:
			actualPhoto = imageEffects.doInvert(actualPhoto);
			photo.setImageBitmap(actualPhoto);
			originalImage=actualPhoto;
			return true;
		case R.id.action_grayscale:
			actualPhoto = imageEffects.doGreyscale(originalImage);
			photo.setImageBitmap(actualPhoto);
			originalImage=actualPhoto;
			return true;
		case R.id.action_brightness:
			seekBar.setVisibility(View.VISIBLE);
			originalImage=actualPhoto;
			return true;
		case R.id.action_emboss:
			actualPhoto = imageEffects.emboss(actualPhoto);
			photo.setImageBitmap(actualPhoto);
			originalImage=actualPhoto;
			return true;
		case R.id.action_round_corner:
			actualPhoto = imageEffects.roundCorner(actualPhoto,50);
			photo.setImageBitmap(actualPhoto);
			originalImage=actualPhoto;
			return true;
		case R.id.action_draw_text:
			editText.setVisibility(View.VISIBLE);
			return true;
		default:
			return super.onOptionsItemSelected(item);
		}
	}

	@Override
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.rotateLeftImageView:
			
			if( actualPhoto != null ){
				rotateAndShowImage(Rotation.LEFT);
			}		
			
			break;
		case R.id.rotateRightImageView:
			
			if( actualPhoto != null ){
				rotateAndShowImage(Rotation.RIGHT);
			}
			
			break;
		default:
			break;
		}
	}

	private void rotateAndShowImage(Rotation rotation) {

		Matrix matrix = new Matrix();

		if (rotation == Rotation.LEFT) {
			Constants.ACTUAL_POSITION_DEGREE -= 90;
			matrix.setRotate(Constants.ACTUAL_POSITION_DEGREE);
		} else if (rotation == Rotation.RIGHT) {
			Constants.ACTUAL_POSITION_DEGREE += 90;
			matrix.setRotate(Constants.ACTUAL_POSITION_DEGREE);
		} else {
			Constants.ACTUAL_POSITION_DEGREE = 0;
			matrix.setRotate(Constants.ACTUAL_POSITION_DEGREE);
		}

		actualPhoto = Bitmap.createBitmap(actualPhoto, 0, 0,
				actualPhoto.getWidth(), actualPhoto.getHeight(), matrix, true);
		photo.setImageBitmap(actualPhoto);

		photoViewAttacher.update();

	}
}
