package com.balazsholczer.photoapp;

public enum Rotation {
	RIGHT,LEFT,NONE;
}
