package TrialDivision;

public class App {

	public static void main(String[] args) {
		
		System.out.println(isPrime(22));

	}
	
	public static boolean isPrime(long n){
		
		if( n == 2 ) return true;
		if( n < 2 || n % 2 == 0 ) return false;
		
		long limit = (long) Math.sqrt(n);
		
		for(int i=3;i<limit;i++){
			if( n % i == 0 ){
				return false;
			}
		}
		
		return true;
	}
}
