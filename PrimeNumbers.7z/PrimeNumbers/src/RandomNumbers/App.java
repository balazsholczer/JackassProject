package RandomNumbers;

import java.util.Random;

public class App {

	private static Random random = new Random();
	public static final double MEAN = 100.0f;
	public static final double VARIANCE = 5.0f;

	public static void main(String... aArgs) {

		for (int idx = 1; idx <= 10; ++idx) {
			log("Generated : " + getGaussian(MEAN, VARIANCE));
		}
	}

	static double getGaussian(double aMean, double aVariance) {
		return aMean + random.nextGaussian() * aVariance;
	}

	public static void log(Object aMsg) {
		System.out.println(String.valueOf(aMsg));
	}
}
