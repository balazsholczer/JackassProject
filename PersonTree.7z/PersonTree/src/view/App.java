package view;

import java.util.ArrayList;
import java.util.List;

import algorithm.BinarySearchTree;

import model.Person;

public class App {

	public static void main(String[] args) {
		
		List<Person> people = new ArrayList<>();
		
		people.add(new Person(19, "Szentirmai Balint", "balint@gmail.com"));
		people.add(new Person(27, "Barn�czky Peter", "peter@gmail.com"));
		people.add(new Person(25, "Holczer Adam", "adam@gmail.com"));
		people.add(new Person(51, "Holczer Istvan", "istvan@gmail.com"));
		people.add(new Person(86, "Szentirmai Attila", "szenirmai@gmail.com"));
		people.add(new Person(45, "Balla Melinda", "melinda@gmail.com"));
		people.add(new Person(54, "Kaso Mate", "mate@gmail.com"));
		people.add(new Person(33, "Lanczos Zsuzsi", "zsuzsi@gmail.com"));
		

		BinarySearchTree binarySearchTree = new BinarySearchTree();
		
		for (Person person : people) {
			binarySearchTree.insert(person);
		}
		
		System.out.println(binarySearchTree.find(people.get(3)));
		System.out.println(binarySearchTree.smallestPerson());
		System.out.println(binarySearchTree.largestPerson());
		
		System.out.println(binarySearchTree.numOfLeafNodes());
		binarySearchTree.traverseInOrder();
		
	}
}
