package algorithm;

import model.Person;

public class TreeNode {

	private Person data;
	private TreeNode leftChild;
	private TreeNode rightChild;

	public TreeNode(Person data) {
		this.data = data;
	}

	public int numOfLeafNodes() {

		if (isLeaf())
			return 1;

		int numOfLeftLeaves = 0;
		int numOfRightLeaves = 0;

		if (this.leftChild != null) {
			numOfLeftLeaves = leftChild.numOfLeafNodes();
		}

		if (this.rightChild != null) {
			numOfRightLeaves = rightChild.numOfLeafNodes();
		}

		return numOfLeftLeaves + numOfRightLeaves;
	}

	public boolean isLeaf() {
		return this.leftChild == null && this.rightChild == null;
	}

	public void traverseInOrder() {
		if (this.leftChild != null)
			this.leftChild.traverseInOrder();
		System.out.println(this + " ");
		if (this.rightChild != null)
			this.rightChild.traverseInOrder();
	}

	public TreeNode findPersonByName(Person person) {
		if (this.data == null)
			return this;

		if (person.getName().compareTo(data.getName()) > 0 && leftChild != null) {
			return leftChild.findPersonByName(person);
		}

		if (rightChild != null) {
			return rightChild.findPersonByName(person);
		}

		return null;
	}

	public void insert(Person person) {
		if (person.getName().compareTo(data.getName()) > 0) {
			if (this.rightChild == null)
				this.rightChild = new TreeNode(person);
			else
				this.rightChild.insert(person);
		} else {
			if (this.leftChild == null)
				this.leftChild = new TreeNode(person);
			else
				this.leftChild.insert(person);
		}
	}

	public Person largest() {
		if (this.rightChild == null)
			return this.data;
		return this.rightChild.largest();
	}

	public Person smallest() {
		if (this.leftChild == null)
			return this.data;
		return this.leftChild.smallest();
	}

	public Person getData() {
		return data;
	}

	public TreeNode getLeftChild() {
		return leftChild;
	}

	public void setLeftChild(TreeNode leftChild) {
		this.leftChild = leftChild;
	}

	public TreeNode getRightChild() {
		return rightChild;
	}

	public void setRightChild(TreeNode rightChild) {
		this.rightChild = rightChild;
	}

	@Override
	public String toString() {
		return data.toString();
	}
}