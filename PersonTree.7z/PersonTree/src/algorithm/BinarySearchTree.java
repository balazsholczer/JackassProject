package algorithm;

import model.Person;

public class BinarySearchTree {

	private TreeNode root;
	
	public TreeNode find(Person person){
		if( root != null ) return root.findPersonByName(person);
		return null;
	}
	
	public Person largestPerson(){
		if( this.root != null ) return root.largest();
		return null;
	}
	
	public Person smallestPerson(){
		if( this.root != null ) return root.smallest();
		return null;
	}

	public void insert(Person person) {
		if (root == null) this.root = new TreeNode(person);
		else root.insert(person);
	}
	
	public void traverseInOrder() {
		if (this.root != null) this.root.traverseInOrder();
		System.out.println();
	}

	public int numOfLeafNodes() {
		if (this.root == null) return 0;
		return this.root.numOfLeafNodes();
	}
}
