package com.balazsholczer.stockwatch.callbacks;

import java.util.List;

public interface StockDownloadCallback {
	public void downloadSuccess(List<String> stockDates,List<String> stockPrices);
	public void downloadFailure();
}
