package com.balazsholczer.stockwatch;

import java.io.IOException;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.http.HttpResponse;
import org.apache.http.ParseException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;

import android.app.SearchManager;
import android.app.SearchableInfo;
import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.SearchView;

import com.balazsholczer.stockwatch.fragments.StockListFragment;
import com.balazsholczer.stockwatch.model.Stock;
import com.balazsholczer.stockwatch.model.StockSymbolName;
import com.google.gson.Gson;
import com.google.gson.stream.JsonReader;

public class MainActivity extends FragmentActivity implements SearchView.OnQueryTextListener{

	private List<Stock> stocks=new ArrayList<>();
	private SearchView searchView;
	private StockListFragment stockListFragment;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.fragment_container);

		stockListFragment = new StockListFragment();
		
		getSupportFragmentManager().beginTransaction()
				.add(R.id.fragmentContainer, stockListFragment).commit();
	
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		super.onCreateOptionsMenu(menu);

		MenuInflater inflater = getMenuInflater();
		inflater.inflate(R.menu.main, menu);
		MenuItem searchItem = menu.findItem(R.id.action_search);
		searchView = (SearchView) searchItem.getActionView();
		setupSearchView(searchItem);

		return true;
	}

	private void setupSearchView(MenuItem searchItem) {

		if (isAlwaysExpanded()) {
			searchView.setIconifiedByDefault(false);
		} else {
			searchItem.setShowAsActionFlags(MenuItem.SHOW_AS_ACTION_IF_ROOM | MenuItem.SHOW_AS_ACTION_COLLAPSE_ACTION_VIEW);
		}

		SearchManager searchManager = (SearchManager) getSystemService(Context.SEARCH_SERVICE);
		if (searchManager != null) {
			List<SearchableInfo> searchables = searchManager.getSearchablesInGlobalSearch();

			SearchableInfo info = searchManager.getSearchableInfo(getComponentName());
			for (SearchableInfo inf : searchables) {
				if (inf.getSuggestAuthority() != null && inf.getSuggestAuthority().startsWith("applications")) {
					info = inf;
				}
			}
			searchView.setSearchableInfo(info);
		}

		searchView.setOnQueryTextListener(this);
	}

	protected boolean isAlwaysExpanded() {
		return false;
	}
	
	@Override
	public boolean onQueryTextChange(String newText) {
		stockListFragment.updateSearhItems(newText);
		return false;
	}

	@Override
	public boolean onQueryTextSubmit(String query) {
		stockListFragment.updateSearhItems(query);
		Log.e("-------------------------","onQueryTextSubmit");
		return false;
	}
}
