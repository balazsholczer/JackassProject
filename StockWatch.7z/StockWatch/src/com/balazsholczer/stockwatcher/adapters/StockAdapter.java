package com.balazsholczer.stockwatcher.adapters;

import java.util.List;

import com.balazsholczer.stockwatch.R;
import com.balazsholczer.stockwatch.model.Stock;
import com.balazsholczer.stockwatch.model.StockSymbolName;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;


public class StockAdapter extends BaseAdapter {

    private List<Stock> stockList;
    private Context context;
    private StockSymbolName stockSymbolName;
    
    public StockAdapter(Context context,List<Stock> currencies){        
        this.context=context;    
        this.stockList=currencies;      
        this.stockSymbolName = new StockSymbolName();
    }
    
    public void refreshCurrencies(List<Stock> currencyList){
    	this.stockList=currencyList;
    	notifyDataSetChanged();
    }
    
    @Override
    public int getCount() {      
        return stockList.size();
    }

    @Override
    public Object getItem(int position) {      
        return stockList.get(position);
    }

    @Override
    public long getItemId(int position) {      
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {  // itt is hasznalhato a viewholder pattern ami 175%os hatekonysagnovelest jelent
     
        View row = convertView;
        ViewHolder holder = null;
        
        if( row == null ){
            LayoutInflater layoutInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);           
            row = layoutInflater.inflate(R.layout.single_listitem_layout, parent,false);         
            holder = new ViewHolder(row);
            row.setTag(holder);
        }else{
            holder = (ViewHolder) row.getTag();
        }
        
        Stock currentStock = stockList.get(position);
        holder.getFirmName().setText(currentStock.getCompanyName());
        holder.getFirmIdentifier().setText(currentStock.getSymbolOnStockMarket());
        holder.getFirmName().setTag(currentStock.getCompanyName());
        
        return row;
    }
    
    private class ViewHolder {

    	private TextView companyName;
    	private TextView companySymbol;

    	ViewHolder(View view) {
    		companyName = (TextView) view.findViewById(R.id.companyNameTextView);
    		companySymbol = (TextView) view.findViewById(R.id.companyIdentifierTextView);
    	}

    	public TextView getFirmName() {
    		return companyName;
    	}

    	public void setFirmName(TextView firmName) {
    		this.companyName = firmName;
    	}

    	public TextView getFirmIdentifier() {
    		return companySymbol;
    	}

    	public void setFirmIdentifier(TextView firmIdentifier) {
    		this.companySymbol = firmIdentifier;
    	}
    }
}
