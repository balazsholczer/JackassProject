package com.example.exerciseandroidswipetab;

import android.app.ActionBar;
import android.app.ActionBar.Tab;
import android.app.ActionBar.TabListener;
import android.app.FragmentTransaction;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.support.v4.view.ViewPager;
import android.support.v4.view.ViewPager.OnPageChangeListener;

/*
 * Swipe tab: amikor a title bar nem mozog: fixen ott van
 * Ketfelekeppen navigalhatunk: swap the page mint page viewernel
 * Vagy ranyomunk a megfelelo swipe title bar sectionre...!!!
 * 
 *  Van az ActionBar felul...az alatt vannak a tabok: mint facebook okostelefonnal
 *      A tabot az action bartol lehet elkerni: ActionBar.newTab();
 *  Kicsit bonyolultabb: figyelni kell, hogy ha a tabok valtoznak akkor a viewpager is valtozzon
 *      es forditva. Konzisztensnek kell maradnia
 */

public class MainActivity extends FragmentActivity implements TabListener{

    private ActionBar actionBar;
    private ViewPager viewPager;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        actionBar = getActionBar();
        actionBar.setNavigationMode(ActionBar.NAVIGATION_MODE_TABS);
        
        viewPager = (ViewPager) findViewById(R.id.myViewPager);
        viewPager.setAdapter(new MyAdapter(getSupportFragmentManager()));
        
        viewPager.setOnPageChangeListener(new OnPageChangeListener() {       
            @Override
            public void onPageSelected(int position) {
                actionBar.setSelectedNavigationItem(position);
            }           
            @Override
            public void onPageScrolled(int arg0, float arg1, int arg2) {}
            @Override
            public void onPageScrollStateChanged(int arg0) {}
        });
        
        ActionBar.Tab tab1 = actionBar.newTab();
        tab1.setText("Tab 1");
        tab1.setTabListener(this);
        
        ActionBar.Tab tab2 = actionBar.newTab();
        tab2.setText("Tab 2");
        tab2.setTabListener(this);
        
        ActionBar.Tab tab3 = actionBar.newTab();
        tab3.setText("Tab 3");
        tab3.setTabListener(this);
      
        actionBar.addTab(tab1);
        actionBar.addTab(tab2);
        actionBar.addTab(tab3);      
    }

    @Override
    public void onTabSelected(Tab tab, FragmentTransaction ft) {
        viewPager.setCurrentItem(tab.getPosition());
    }

    @Override
    public void onTabUnselected(Tab tab, FragmentTransaction ft) {     
    }

    @Override
    public void onTabReselected(Tab tab, FragmentTransaction ft) {      
    }
}
