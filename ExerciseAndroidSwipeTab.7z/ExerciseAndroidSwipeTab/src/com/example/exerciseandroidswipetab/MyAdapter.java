package com.example.exerciseandroidswipetab;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;

public class MyAdapter extends FragmentPagerAdapter {

    public MyAdapter(FragmentManager fm) {
        super(fm);
    }

    @Override
    public Fragment getItem(int args) {
        switch (args) {
        case 0:
            return new FragmentA();
        case 1:
            return new FragmentB();
        case 2:
            return new FragmentC();

        default:
            return null;
        }
    }

    @Override
    public int getCount() {
        return 3;
    }
}
