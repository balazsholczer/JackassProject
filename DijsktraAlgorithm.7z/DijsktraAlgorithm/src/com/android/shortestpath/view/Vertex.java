package com.android.shortestpath.view;

public class Vertex {

	private float x;
	private float y;
	private String vertexName;
	private boolean visited;

	public Vertex() {

	}

	public Vertex(float x, float y, String vertexName) {
		this.x = x;
		this.y = y;
		this.vertexName = vertexName;
	}

	public float getX() {
		return x;
	}

	public void setX(float x) {
		this.x = x;
	}

	public float getY() {
		return y;
	}

	public void setY(float y) {
		this.y = y;
	}

	public String getVertexName() {
		return vertexName;
	}

	public void setVertexName(String vertexName) {
		this.vertexName = vertexName;
	}	

	public boolean isVisited() {
		return visited;
	}

	public void setVisited(boolean visited) {
		this.visited = visited;
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((vertexName == null) ? 0 : vertexName.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Vertex other = (Vertex) obj;
		if (vertexName == null) {
			if (other.vertexName != null)
				return false;
		} else if (!vertexName.equals(other.vertexName))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return vertexName;
	}	
}
