package com.android.shortestpath.view;

import java.util.LinkedList;
import java.util.List;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceHolder.Callback;
import android.view.SurfaceView;
import android.view.View;

import com.android.shortestpath.dialog.WeightDialog;
import com.android.shortestpath.dialog.WeightDialog.WeightCalculatorListener;
import com.android.shortestpath.model.Controller;
import com.android.shortestpath.util.Constants;
import com.android.shortestpath.util.State;

public class BoardView extends SurfaceView implements Callback,
		WeightCalculatorListener {

	private static Paint vertexPaint;
	private Paint edgeWeightPaint;
	private static Paint shortestPathPaint;
	private Paint vertexNamePaint;
	private static Paint vertexOrangePaint;
	private Paint edgePaint;
	private static Controller controller;
	private static int count = 1;
	private boolean isFirstSet;
	private static State currentState = State.ADD_EDGE;
	private float x;
	private float y;
	private String name;
	private int weight;
	private static Canvas canvas;
	private WeightDialog weightDialog;
	private static SurfaceHolder holder;

	public BoardView(Context context, AttributeSet attrs) {
		super(context, attrs);

		controller = new Controller();

		weightDialog = new WeightDialog(getContext(), this);

		vertexPaint = new Paint();
		vertexPaint.setColor(Color.BLACK);
		
		vertexOrangePaint = new Paint();
		vertexOrangePaint.setColor(Color.YELLOW);

		edgePaint = new Paint();
		edgePaint.setColor(Color.RED);
		edgePaint.setStrokeWidth(15);
		
		shortestPathPaint = new Paint();
		shortestPathPaint.setColor(Color.GREEN);
		shortestPathPaint.setStrokeWidth(15);

		vertexNamePaint = new Paint();
		vertexNamePaint.setColor(Color.BLACK);
		vertexNamePaint.setTextSize(40);

		edgeWeightPaint = new Paint();
		edgeWeightPaint.setColor(Color.BLUE);
		edgeWeightPaint.setTextSize(40);

	}

	@Override
	public boolean onTouchEvent(MotionEvent event) {

		holder = getHolder();

		canvas = holder.lockCanvas();

		if (canvas != null) {

			canvas.drawColor(Color.WHITE);
			canvas.drawText("Dijsktra-algorithm", 20, 50, vertexNamePaint);

			if (currentState == State.ADD_VERTEX) {
				addVertex(event);
			} else if (currentState == State.ADD_EDGE) {
				addEdge(event);
			} else if (currentState == State.SET_START_END_POINT) {
				addStartEndPoints(event);
			}

			plotEdges(canvas);
			plotVertexes(canvas);

			holder.unlockCanvasAndPost(canvas);
		}
		return true;
	}

	private void addStartEndPoints(MotionEvent event) {
		Vertex vertex = null;

		if (event.getAction() == MotionEvent.ACTION_UP) {
			if ((vertex = controller.containPoint(event.getX(), event.getY())) != null) {

				if (!isFirstSet && vertex != null) {
					x = vertex.getX();
					y = vertex.getY();
					name = vertex.getVertexName();
					isFirstSet = true;
					vertex = null;
				} else if (isFirstSet && vertex != null) {

					controller.setVertexEnd(vertex);
					controller.setVertexStart(new Vertex(x, y, name));
					
					updateSelectedNodes();
					
					isFirstSet = false;
					vertex = null;
				}
			}
		}
	}

	private void updateSelectedNodes() {
			
	}

	private void addEdge(MotionEvent event) {
		Vertex vertex = null;

		if (event.getAction() == MotionEvent.ACTION_UP) {
			if ((vertex = controller.containPoint(event.getX(), event.getY())) != null) {

				if (!isFirstSet && vertex != null) {
					x = vertex.getX();
					y = vertex.getY();
					name = vertex.getVertexName();
					isFirstSet = true;
					vertex = null;
				} else if (isFirstSet && vertex != null) {

					weightDialog.buildDialog();
					Edge edgeTemp = new Edge();
					edgeTemp.setVertexTo(vertex);
					edgeTemp.setVertexFrom(new Vertex(x, y, name));

					controller.addEdge(edgeTemp);
					isFirstSet = false;
					vertex = null;
				}
			}
		}
	}

	private void addVertex(MotionEvent event) {
		if (event.getAction() == MotionEvent.ACTION_UP) {
			Vertex vertex = new Vertex(event.getX(), event.getY(), "" + count++);
			controller.addVertex(vertex);
		}
		plotVertexes(canvas);
	}

	private void plotVertexes(Canvas canvas) {
		for (int i = 0; i < controller.getVertexListSize(); i++) {
			canvas.drawCircle(controller.getVertex(i).getX(),
					controller.getVertex(i).getY(), Constants.VERTEX_RADIUS,
					vertexPaint);
			canvas.drawText(controller.getVertex(i).getVertexName(), controller
					.getVertex(i).getX(), controller.getVertex(i).getY()
					- Constants.VERTEX_NAME_OFFSET, vertexNamePaint);
		}
		
		if( controller.getVertexStart() != null && controller.getVertexEnd() != null ){
			canvas.drawCircle(controller.getVertexStart().getX(),controller.getVertexStart().getY(),Constants.VERTEX_RADIUS,vertexOrangePaint);
			canvas.drawCircle(controller.getVertexEnd().getX(),controller.getVertexEnd().getY(),Constants.VERTEX_RADIUS,vertexOrangePaint);	
		}
		
	}

	private void plotEdges(Canvas canvas) {
		List<Edge> edges = controller.getAllEdges();
		for (Edge edge : edges) {
			canvas.drawLine(edge.getVertexFrom().getX(), edge.getVertexFrom()
					.getY(), edge.getVertexTo().getX(), edge.getVertexTo()
					.getY(), edgePaint);
			canvas.drawText(
					"" + edge.getWeight(),
					(edge.getVertexFrom().getX() + edge.getVertexTo().getX()) / 2,
					(edge.getVertexFrom().getY() + edge.getVertexTo().getY()) / 2,
					edgeWeightPaint);
		}
	}

	public static void updateState(State state) {
		currentState = state;
	}

	@Override
	public void surfaceCreated(SurfaceHolder holder) {
	}

	@Override
	public void surfaceChanged(SurfaceHolder holder, int format, int width,
			int height) {
	}

	@Override
	public void surfaceDestroyed(SurfaceHolder holder) {
	}

	public static void clearBoard(View view) {	
		holder.lockCanvas();
		controller.clearDatabase();
		count = 1;
		canvas.drawColor(Color.WHITE);
		holder.unlockCanvasAndPost(canvas);
	}

	@Override
	public void weightCalculated(int weight) {
		this.weight = weight;
		Edge e = controller.getEdge(controller.getEdgeListSize() - 1);
		e.setWeight(weight + 1);
		controller.removeEdge(controller.getEdgeListSize() - 1);
		controller.addEdge(e);
		getHolder().lockCanvas();
		plotEdges(canvas);
		plotVertexes(canvas);
		getHolder().unlockCanvasAndPost(canvas);
	}

	public static void showShortestPath(Vertex vertexStart, Vertex vertex) {
		
	}

	public static void showShortestPath(LinkedList<Vertex> path) {
		
		holder.lockCanvas();
		
		for(int i=0;i<path.size()-1;i++){
			
			canvas.drawLine(path.get(i).getX(),path.get(i).getY(),path.get(i+1).getX(), path.get(i+1).getY(), shortestPathPaint);
			canvas.drawCircle(path.get(i).getX(),path.get(i).getY(),Constants.VERTEX_RADIUS,vertexPaint);
			canvas.drawCircle(path.get(i+1).getX(),path.get(i+1).getY(),Constants.VERTEX_RADIUS,vertexPaint);
			
			Log.e("---------------------------","PAth from "+path.get(i)+" to "+path.get(i+1));
		}
		
		holder.unlockCanvasAndPost(canvas);
		
//		holder.lockCanvas();
//		canvas.drawLine(vertexStart.getX(), vertexStart.getY(), vertex.getX(), vertex.getY(), shortestPathPaint);
//		canvas.drawCircle(vertexStart.getX(),vertexStart.getY(), Constants.VERTEX_RADIUS,vertexPaint);
//		canvas.drawCircle(vertex.getX(),vertex.getY(), Constants.VERTEX_RADIUS,vertexPaint);
//		holder.unlockCanvasAndPost(canvas);
	}
}
