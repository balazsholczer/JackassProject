package com.android.shortestpath.view;

public class Edge {

	private String id;
	private Vertex vertexFrom;
	private Vertex vertexTo;
	private int weight;

	public Edge() {
	}

	public Edge(String id, Vertex vertex1, Vertex vertex2, int weight) {
		this.vertexFrom = vertex1;
		this.vertexTo = vertex2;
		this.weight = weight;
		this.id = id;
	}

	public Vertex getVertexFrom() {
		return vertexFrom;
	}

	public void setVertexFrom(Vertex vertex) {
		this.vertexFrom = vertex;
	}

	public Vertex getVertexTo() {
		return vertexTo;
	}

	public void setVertexTo(Vertex vertex) {
		this.vertexTo = vertex;
	}

	public int getWeight() {
		return weight;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public void setWeight(int weight) {
		this.weight = weight;
	}

	public void setVertexesVisited() {
		vertexFrom.setVisited(true);
		vertexTo.setVisited(true);
	}

	public boolean areVertexesVisited() {
		return (vertexFrom.isVisited() & vertexTo.isVisited());
	}
	

	@Override
	public String toString() {
		return "Edge [vertexFrom=" + vertexFrom + ", vertexTo=" + vertexTo
				+ ", weight=" + weight + "]";
	}
}
