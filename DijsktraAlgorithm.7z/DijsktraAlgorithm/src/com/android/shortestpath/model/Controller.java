package com.android.shortestpath.model;

import java.util.List;

import com.android.shortestpath.view.Edge;
import com.android.shortestpath.view.Vertex;

public class Controller {

	private static Database database = new Database();

	public List<Edge> getAllEdge() {
		return database.getAllEdges();
	}

	public Vertex containPoint(float x, float y) {
		return database.containPoint(x, y);
	}

	public void addEdge(Edge edgeTemp) {
		database.addEdge(edgeTemp);
	}

	public void addVertex(Vertex vertex) {
		database.addVertex(vertex);
	}

	public int getVertexListSize() {
		return database.getVertexListSize();
	}

	public Vertex getVertex(int i) {
		return database.getVertex(i);
	}

	public List<Edge> getAllEdges() {
		return database.getAllEdges();
	}

	public void clearDatabase() {
		database.clearDatabase();
	}

	public int getEdgeListSize() {
		return database.getEdgeListSize();
	}

	public Edge getEdge(int position) {
		return database.getEdge(position);
	}

	public void setVertexEnd(Vertex vertex) {
		database.setVertexEnd(vertex);
	}
	
	public void setVertexStart(Vertex vertex) {
		database.setVertexStart(vertex);
	}

	public Vertex getVertexStart() {
		return database.getVertexStart();
	}
	
	public Vertex getVertexEnd(){
		return database.getVertexEnd();
	}

	public List<Vertex> getAllVertexes() {
		return database.getAllVertex();
	}

	public void removeEdge(int i) {
		database.removeEdge(i);
	}
}
