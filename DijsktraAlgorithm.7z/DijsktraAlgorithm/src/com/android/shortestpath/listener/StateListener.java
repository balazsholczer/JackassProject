package com.android.shortestpath.listener;

import com.android.shortestpath.util.State;

public interface StateListener {
	public void stateChanged(State state);
}
