package com.android.shortestpath.dijksra;

import java.util.LinkedList;
import java.util.List;

import android.util.Log;

import com.android.shortestpath.model.Controller;
import com.android.shortestpath.view.BoardView;
import com.android.shortestpath.view.Edge;
import com.android.shortestpath.view.Vertex;

public class ShortestPath {
	
	private Controller controller;
	private Vertex vertexStart;
	private Vertex vertexEnd;
	private List<Vertex> nodes;
	private List<Edge> edges;
	
	public ShortestPath(){
		controller = new Controller();		
		vertexStart = controller.getVertexStart();
		vertexEnd = controller.getVertexEnd();		
		nodes = controller.getAllVertexes();
		edges = controller.getAllEdges();
	}

	public void runAlgorithm() {
		
		Graph graph = new Graph(nodes, edges);
	    DijkstraAlgorithm dijkstra = new DijkstraAlgorithm(graph);
	    dijkstra.execute(vertexStart);
	    LinkedList<Vertex> path = dijkstra.getPath(vertexEnd);
	    
	    BoardView.showShortestPath(path);
	    
//	    for (Vertex vertex : path) {
//	        Log.e("-----------------",""+vertex);
//	        BoardView.showShortestPath(vertexStart,vertex);
//	        vertexStart=vertex;
//	    }
	}
}
