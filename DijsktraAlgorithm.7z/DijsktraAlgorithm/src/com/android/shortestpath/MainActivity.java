package com.android.shortestpath;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

import com.android.shortestpath.dijksra.ShortestPath;
import com.android.shortestpath.util.State;
import com.android.shortestpath.view.BoardView;

public class MainActivity extends Activity {

	private Spinner stateSpinner;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		stateSpinner = (Spinner) findViewById(R.id.stateSpinner);
		stateSpinner.setOnItemSelectedListener(new OnItemSelectedListener() {

			@Override
			public void onItemSelected(AdapterView<?> parent, View view,int position, long id) {										
				
				State state;
				
				if( position == 0 ){
					state = State.ADD_VERTEX;
				}else if( position ==  1 ){
					state = State.ADD_EDGE;
				}else{
					state = State.SET_START_END_POINT;
				}
				
				BoardView.updateState(state);			
			}

			@Override
			public void onNothingSelected(AdapterView<?> parent) {			
			}
		});

		ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this, R.array.state_array,android.R.layout.simple_spinner_item);
		adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

		stateSpinner.setAdapter(adapter);
	}
	
	public void clearBoard(View view){
		BoardView.clearBoard(view);
	}
	
	public void runDijsktra(View view){
		ShortestPath shortestPath = new ShortestPath();
		shortestPath.runAlgorithm();
	}
}
