package com.android.shortestpath.util;

public enum State {

	ADD_EDGE, ADD_VERTEX,SET_START_END_POINT;

}
