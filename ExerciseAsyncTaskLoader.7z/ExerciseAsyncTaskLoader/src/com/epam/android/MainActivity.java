package com.epam.android;

import java.util.List;

import android.app.Activity;
import android.app.LoaderManager;
import android.app.ProgressDialog;
import android.content.Loader;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity implements LoaderManager.LoaderCallbacks<Response> {

    public static final int UPDATE_LIST = 11;
    public static final int UPDATE_USER_MASSAGE = 123;
    private TextView textView;
    private ProgressDialog progressDialog;
    
    private Handler handler = new Handler(new Handler.Callback() {    
        public boolean handleMessage(Message msg) {
            
            if( msg.what == UPDATE_USER_MASSAGE ){
                
                progressDialog.dismiss();
                
                Response response = (Response) msg.obj;                
                
                List<String> data = response.getData();
                
                for(String s : data){
                    textView.append(s+"\n");
                }
                
                Toast.makeText(getApplicationContext(), "Response size: "+response.getData().size(), Toast.LENGTH_SHORT).show();  
                
            }
            
            return false;
        }
    });
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        textView = (TextView) findViewById(R.id.textView);
        progressDialog = new ProgressDialog(this);
        
        getLoaderManager().restartLoader(UPDATE_LIST, null, this).forceLoad();
            
    }

    @Override
    public Loader<Response> onCreateLoader(int arg0, Bundle arg1) {  
        progressDialog.show();
        return new DataDownloader(getApplicationContext());
    }

    @Override
    public void onLoadFinished(Loader<Response> responseLoader, Response response) {
     
        switch(responseLoader.getId()){
        case UPDATE_LIST:       
            sendMessageToHandler(response,UPDATE_USER_MASSAGE);
            break;
        }
        
        
    }

    private void sendMessageToHandler(Response response, int updateUserMassage) {
        Message message = new Message();
        message.obj=response;
        message.what=updateUserMassage;
        handler.sendMessage(message);
    }

    @Override
    public void onLoaderReset(Loader<Response> arg0) {
        
    }
}
