package com.epam.android;

import java.util.ArrayList;
import java.util.List;

import android.content.AsyncTaskLoader;
import android.content.Context;

public class DataDownloader extends AsyncTaskLoader<Response>{

    public DataDownloader(Context context) {
        super(context);   
    }

    @Override
    public Response loadInBackground() {
       
        Response response = new Response();
        List<String> resultList = new ArrayList<String>();
        
        for(int i=0;i<5;i++){
            
            try {
                Thread.sleep(1000);
                resultList.add("Count -> "+i);
            } catch (InterruptedException e) {               
                e.printStackTrace();
            }          
        }
        
        response.setData(resultList);
        
        return response;
    }     
}
