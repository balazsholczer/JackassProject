package com.epam.android;

import java.util.ArrayList;
import java.util.List;

public class Response {

    private List<String> data;
    
    public Response(){
        this.data=new ArrayList<String>();
    }
    
    public List<String> getData(){
        return data;
    }
    
    public void setData(List<String> data){
        this.data=data;
    }
}
