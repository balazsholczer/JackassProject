package com.balazsholczer.android.constants;

public enum State {

}
