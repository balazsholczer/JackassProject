package Sorting;

public class App {

	public static void main(String[] args) {
		
		int[] numbers = {22,56,87,2,5,4,10,123,123,22};
		
		for(int i=1;i<numbers.length;i++){
			
			int temp = numbers[i];
			int j;
			
			for(j=i-1;j>=0 && temp<numbers[j];j--){
				numbers[j+1]=numbers[j];
			}
			
			numbers[j+1]=temp;
			
		}
		
		for(int i=0;i<numbers.length;i++){
			System.out.print(numbers[i]+" ");
		}

	}
}
