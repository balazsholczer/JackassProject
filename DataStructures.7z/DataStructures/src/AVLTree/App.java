package AVLTree;

public class App {

	public static void main(String[] args) {

		AVLTree<Integer> tree = new AVLTree<Integer>();
		
		for (int i = 1; i <= 5; i++)
			tree.insert(new Integer(i));
			
		tree.PrintTree();

	}
}
