package DFS;

import java.util.ArrayList;
import java.util.List;

public class Vertex {

	private String vertexName;
	private boolean visited;
	private List<Vertex> neighbourList;

	public Vertex(String vertexName) {
		this.vertexName = vertexName;
		neighbourList = new ArrayList<Vertex>();
	}

	public void addNeighbour(Vertex vertex){
		neighbourList.add(vertex);
	}
	
	public List<Vertex> getNeighbours(){
		return this.neighbourList;
	}
	
	public String getVertexName() {
		return vertexName;
	}

	public void setVertexName(String vertexName) {
		this.vertexName = vertexName;
	}	

	public boolean isVisited() {
		return visited;
	}

	public void setVisited(boolean visited) {
		this.visited = visited;
	}

	@Override
	public String toString() {
		return this.vertexName;
	}	
}
