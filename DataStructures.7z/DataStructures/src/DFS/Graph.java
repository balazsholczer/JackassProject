package DFS;

import java.util.Stack;

public class Graph {
	
	private Vertex rootVertex;
     
	public Graph(Vertex rootVertex){
		this.rootVertex=rootVertex;
	}
	
	public void depthFirstTraversal1() {

		Stack<Vertex> stack = new Stack<>();
		stack.add(rootVertex);
		rootVertex.setVisited(true);
		while(!stack.isEmpty()){
			Vertex n = (Vertex) stack.pop();
			System.out.print(n.getVertexName() +  " ");
			for(Vertex adj : n.getNeighbours()){
				if(!adj.isVisited()){
					adj.setVisited(true);
					stack.push(adj);
				}
			}
		}
	}
	
	public void depthFirstTraversal2(Vertex vertex) {

		if( vertex.isVisited() ) return;
		
		Stack<Vertex> stack = new Stack<>();
		stack.add(rootVertex);
		rootVertex.setVisited(true);
		while(!stack.isEmpty()){
			Vertex n = (Vertex) stack.pop();
			System.out.print(n.getVertexName() +  " ");
			for(Vertex adj : n.getNeighbours()){
				if(!adj.isVisited()){
					depthFirstTraversal2(adj);
				}
			}
		}
	}
}
