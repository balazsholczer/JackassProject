package DFS;

public class App {

	
	public static void main(String[] args) {
		
		Vertex rootVertex = new Vertex("A");
		
		Vertex vertex1 = new Vertex("B");
		Vertex vertex2 = new Vertex("C");
		Vertex vertex3 = new Vertex("D");
		Vertex vertex4 = new Vertex("E");
		Vertex vertex5 = new Vertex("F");
		
		rootVertex.addNeighbour(vertex1);
		rootVertex.addNeighbour(vertex4);
		vertex1.addNeighbour(vertex2);
		vertex1.addNeighbour(vertex3);
		vertex4.addNeighbour(vertex5);
		vertex4.addNeighbour(vertex3);
		
		
		Graph graph = new Graph(rootVertex);
		graph.depthFirstTraversal1();
		
		
	}
}
