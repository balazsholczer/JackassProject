package BinaryTree;

public class App {

	public static void main(String[] args) {
		
		int[] sample = { 212, 580, 6, 7, 28, 84, 112, 434};
		BinarySearchTree binarySearchTree = new BinarySearchTree();
		
		for (int x : sample) {
			binarySearchTree.insert(x);
		}
		
		System.out.println(binarySearchTree.find(65));
		System.out.println(binarySearchTree.smallest());
		System.out.println(binarySearchTree.largest());
//		bst.delete(84);
		System.out.println(binarySearchTree.numOfLeafNodes());
		System.out.println(binarySearchTree.height());
		binarySearchTree.traverseInOrder();

	}
}
