package DijsktraAlgorithm;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;


public class App {

	private static List<Vertex> nodes;
	private static List<Edge> edges;
	
	public static void main(String[] args) {
		
		nodes = new ArrayList<Vertex>();
	    edges = new ArrayList<Edge>();
	    
	    nodes.add(new Vertex("1", "A"));
	    nodes.add(new Vertex("2", "B"));
	    nodes.add(new Vertex("3", "C"));
	    nodes.add(new Vertex("4", "D"));
	    
	    edges.add(new Edge("1", nodes.get(0), nodes.get(1),1));
	    edges.add(new Edge("2", nodes.get(1), nodes.get(2),1));
	    edges.add(new Edge("3", nodes.get(2), nodes.get(3),1));
	    edges.add(new Edge("4", nodes.get(0), nodes.get(3),4));
	   
	    Graph graph = new Graph(nodes, edges);
	    Algorithm dijkstra = new Algorithm(graph);
	    dijkstra.execute(nodes.get(0));
	    LinkedList<Vertex> path = dijkstra.getPath(nodes.get(3));
	    
	    for (Vertex vertex : path) {
	      System.out.println(vertex);
	    }

	}
}
