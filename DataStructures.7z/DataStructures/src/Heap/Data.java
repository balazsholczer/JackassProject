package Heap;

public class Data {

	private int key;

	public Data(int key) {
		this.key = key;
	}

	public int getKey() {
		return this.key;
	}

	public void setKey(int key) {
		this.key = key;
	}

	@Override
	public String toString() {
		return "Data [key=" + key + "]";
	}
}
