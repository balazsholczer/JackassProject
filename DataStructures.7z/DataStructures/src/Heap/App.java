package Heap;

import java.util.Arrays;

public class App {

	/**
	 *	A heap olyan, mint a tree: mindig a legnagyobb van a rootban -> elonyos, ha a legnagyobb elemet akarjuk elertni O(1) time complexitivel mindig megteheto
	 *		- nem feltetlenul ugy van az elrendezes, mint a binary treenel: itt minden parentnek a gyerekei kisebbek nala, de nincs meghatarozva, hogy
	 *			 melyik helyen allnak
	 *		- pl: lehet, hogy a bal also elem nagyobb a jobb szelsonel ... elofordulaht
	 *		- heapsort O(n*logn) time complexitivel lehet bejarni egy heapet sorrendben 
	 *		- ketfele heap van: maxHeap �s minHeap 
	 *			maxHeap -> amikor a root element a legnagyobb eleme a tombunknek + mindig a parent nagyobb a childoknal
	 *			minHeap -> amikor a root element a legkisebb elem + mindig a parent kisebb a childoknal
	 *
	 *		- fontos alkalmazasi terulet a gr�falgoritmusok: minHeappel lehet nagyon gyorsan implementalni a Dijsktra eljarast
	 *		- ketfelekeppen lehet megvalositani: tombokkel vagy faszerkezettel 
	 *		- OLYANKOR ELONYOS HASZNALNI, HA A LEGNAGYOPBB/LEGKISEBB ELEMET AKARJUK ELTAVOLITANI !!!
	 *			Viszont nem nagyon lehet hatekonyan in-order-travelsalt csinalni ... BST-nel ezt nagyon hatekonyan meg lehet tenni, itt nem annyira
	 *				pl: priotity queuet ezzel lehet megcsinalni
	 *
	 *
	 *		Fibonacci-heap nagyon hatekony: faszerkezet, de nem csak 2 gyereke lehet egy parent nodenak
	 *					Elonyos lehet, Dijsktra eljarasnal lehet hasznalni priority queuekent
	 *						Egy parentnak -> legfeljebb log*n gyereke lehet + ha egy parentnak k a fokszama, akkor a F(k+2) Fibonaci szamnak megfelelo subtreevel rendelkezik !!!!
	 *			O(1) 		finding minimum element
	 *			O(log n) 	deleting minimum element
	 *			O(1) 		inserting element
	 *			O(1)		decrease key
	 *			O(1)		merge
	 *
	 */
	public static void main(String[] args) {

		Heap newHeap = new Heap(7);
		newHeap.generateFilledArray(90);

		System.out.println("Original Array");
		System.out.println(Arrays.toString(newHeap.getTheHeap()));

		System.out.println();

		newHeap.printTree(4);
		System.out.println();

		for (int j = newHeap.getMaxSize() / 2 - 1; j >= 0; j--) {

			newHeap.heapTheArray(j);

		}

		System.out.println("Heaped Array");

		System.out.println(Arrays.toString(newHeap.getTheHeap()) + "\n");

		newHeap.printTree(4);

		System.out.println("HEAPED SORTED");

		newHeap.heapSort();

		System.out.println("\nSorted Array");
		System.out.println(Arrays.toString(newHeap.getTheHeap()));
	}
}
