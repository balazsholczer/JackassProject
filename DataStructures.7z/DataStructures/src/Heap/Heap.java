package Heap;

import java.util.Arrays;

public class Heap {

	private Data[] theHeap;
	private int itemsInArray = 0;
	private int maxSize;

	public Heap(int maxSize) {
		this.maxSize = maxSize;
		theHeap = new Data[maxSize];
	}

	public void insert(int index, Data newData) {
		this.theHeap[index] = newData;
	}

	public void incrementArray() {
		itemsInArray++;
	}

	public Data pop() {
		if (itemsInArray != 0) {

			int tempItemsInArray = itemsInArray - 1;

			System.out.println("Store " + theHeap[0] + " in root. Store " + theHeap[tempItemsInArray] + " in index 0");
			System.out.println(Arrays.toString(theHeap) + "\n");

			Data root = theHeap[0];
			theHeap[0] = theHeap[--itemsInArray];
			heapTheArray(0);

			return root;
		}

		return null;
	}

	public void printTree(int rows) {
		int spaces = 0;
		int iteration = 1;

		int[] indent = getIndentArray(rows);

		while (iteration <= rows) {
			int indexToPrint = (int) (.5 * (-2 + (Math.pow(2, iteration))));
			int itemsPerRow = (int) (Math.pow(2, iteration - 1));
			int maxIndexToPrint = indexToPrint + itemsPerRow;

			for (int j = 0; j < indent[iteration - 1]; j++)
				System.out.print(" ");

			for (int l = indexToPrint; l < maxIndexToPrint; l++) {
				if (l < itemsInArray) {
					System.out.print(String.format("%02d", theHeap[l].getKey()));
					for (int k = 0; k < spaces; k++)
						System.out.print(" ");
				}
			}

			spaces = indent[iteration - 1];
			iteration++;
			System.out.println();
		}

	}

	private int[] getIndentArray(int rows) {
		int[] indentArray = new int[rows];

		for (int i = 0; i < rows; i++) {
			indentArray[i] = (int) Math.abs((-2 + (Math.pow(2, i + 1))));
		}

		Arrays.sort(indentArray);
		indentArray = reverseArray(indentArray);
		return indentArray;
	}

	private int[] reverseArray(int[] theArray) {

		int leftIndex = 0;
		int rightIndex = theArray.length - 1;

		while (leftIndex < rightIndex) {
			int temp = theArray[leftIndex];
			theArray[leftIndex] = theArray[rightIndex];
			theArray[rightIndex] = temp;
			leftIndex++;
			rightIndex--;
		}

		return theArray;
	}

	public void generateFilledArray(int randNum) {

		Data randomData;

		for (int i = 0; i < this.maxSize; i++) {
			randomData = new Data((int) (Math.random() * randNum) + 1);
			this.insert(i, randomData);
			incrementArray();
		}
	}

	public void heapTheArray(int index) {

		int largestChild;
		Data root = theHeap[index];

		while (index < itemsInArray / 2) {
			int leftChild = 2 * index + 1;
			int rightChild = leftChild + 1;

			if (rightChild < itemsInArray && theHeap[leftChild].getKey() < theHeap[rightChild].getKey()) {
				System.out.println("Put Value " + theHeap[rightChild] + " in largestChild");
				largestChild = rightChild;
			} else {
				System.out.println("Put Value " + theHeap[leftChild] + " in largestChild");
				largestChild = leftChild;
			}

			if (root.getKey() >= theHeap[largestChild].getKey()) break;

			System.out.println("Put Index Value " + theHeap[largestChild]);

			theHeap[index] = theHeap[largestChild];
			index = largestChild;

			System.out.println();

			printTree(4);
			System.out.println();
		}

		theHeap[index] = root;
	}

	public void heapSort() {

		for (int k = maxSize - 1; k >= 0; k--) {
			Data largestNode = pop();
			insert(k, largestNode);
			System.out.println(Arrays.toString(theHeap));
		}
	}

	public Data[] getTheHeap() {
		return this.theHeap;
	}

	public int getMaxSize() {
		return maxSize;
	}
}