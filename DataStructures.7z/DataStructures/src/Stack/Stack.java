package Stack;

public class Stack {

	private int[] items = new int[100];
	private int top = -1;
	
	public boolean isEmpty(){
		return top < 0;
	}
	
	public void push(int item){
		if( top == items.length-1){
			throw new RuntimeException("Stack is full");
		}
		items[++top]=item;
	}
	
	public int pop() {
		if (isEmpty()) throw new RuntimeException("Stack is empty");
		return items[top--];
	}
	
	public int peek() {
		if (isEmpty())
			throw new RuntimeException("Stack is empty");
		return items[top];
	}	
}
