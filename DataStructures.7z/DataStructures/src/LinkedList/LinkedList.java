package LinkedList;

public class LinkedList<T> {

	private Node<T> head;
	
	private Node<T> getHead(){
		return this.head;
	}
	
	public void addAtStart(T data){
		Node<T> newNode = new Node<T>(data);
		newNode.setNextNode(this.head);
		this.head=newNode;
	}
	
	public void setHead(Node<T> node){
		this.head=node;
	}
	
	public Node<T> deleteAtStart(){
		Node<T> nodeToDelete = this.head;
		this.head=head.getNextNode();
		return nodeToDelete;
	}
	
	public Node<T> findNode(T dataToFind){
		Node<T> currentNode = this.head;
		while(currentNode!=null){
			if( currentNode.getData().equals(dataToFind)){
				return currentNode;
			}
			currentNode=currentNode.getNextNode();
		}
		return null;
	}
	
	public int length(){
		
		int length=0;	
		if( head==null ) return 0;
		
		Node<T> currentNode = this.head;
		
		while(currentNode!=null){
			length++;
			currentNode=currentNode.getNextNode();
		}
		
		return length;
	}
	
	public boolean isEmpty() {
		return this.head == null;
	}

	@Override
	public String toString() {
		String res = "";
		Node<T> curr = this.head;
		while (curr != null) {
			res += curr + ", ";
			curr = curr.getNextNode();
		}
		return res;
	}
}
