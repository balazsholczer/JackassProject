package LinkedList;


/*
 * 	Linked list time complexity: 
 * 		Search O(n)  pl: find max is linearis idoigenyu muvelet itt is midig mint a tombnel
 * 		Insertion/Deletion O(1)
 * 
 * 
 */

public class App {


	public static void main(String[] args) {
		
		LinkedList<Integer> myList = new LinkedList<Integer>();
		
		myList.addAtStart(10);
		myList.addAtStart(30);
		myList.addAtStart(50);
		myList.addAtStart(40);
		
		System.out.println(myList);
		
		myList.deleteAtStart();
		
		System.out.println(myList);
		
		System.out.println(myList.findNode(10));
		
		System.out.println(myList.length());

	}
}
