package com.android.shortestpath.model;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import com.android.shortestpath.util.Constants;
import com.android.shortestpath.view.Edge;
import com.android.shortestpath.view.Vertex;

public class Database {

	public static List<Vertex> vertexList;
	public static List<Edge> edgeList;
	public static Vertex startingVertex;

	public Database() {
		this.vertexList = new ArrayList<Vertex>();
		this.edgeList = new ArrayList<Edge>();
	}

	public Vertex getStartingVertex() {
		return startingVertex;
	}

	public void setStartingVertex(Vertex startingVertex) {
		this.startingVertex = startingVertex;
	}

	public List<Vertex> getAllVertex() {
		return this.vertexList;
	}

	public List<Vertex> getVertexList() {
		return vertexList;
	}

	public void setVertexList(List<Vertex> vertexList) {
		this.vertexList = vertexList;
	}

	public Vertex getVertex(int position) {
		return this.vertexList.get(position);
	}

	public void addVertex(Vertex vertex) {
		this.vertexList.add(vertex);
	}

	public int getVertexListSize() {
		return this.vertexList.size();
	}

	public Vertex containPoint(float x, float y) {

		Vertex vertexToReturn = new Vertex();

		for (Vertex vertex : vertexList) {

			float xDiff = vertex.getX() - x;
			float yDiff = vertex.getY() - y;

			float distSquared = xDiff * xDiff + yDiff * yDiff;

			if (distSquared < Constants.PRECISION * Constants.PRECISION) {
				vertexToReturn = vertex;
				break;
			}

		}
		return vertexToReturn;
	}

	// database edges problem

	public List<Edge> getAllEdges() {
		return this.edgeList;
	}

	public Edge getEdge(int position) {
		return this.edgeList.get(position);
	}

	public void addEdge(Edge edge) {
		this.edgeList.add(edge);
	}

	public int getEdgeListSize() {
		return this.edgeList.size();
	}

	public void clearDatabase() {
		startingVertex=null;
		edgeList.clear();
		vertexList.clear();
	}

	public void removeEdge(int i) {
		edgeList.remove(i);
	}

	public static void saveVisitedNode(Vertex vertex) {
		vertexList.get(vertexList.indexOf(vertex)).setVisited(true);
	}
}
