package com.android.shortestpath.listener;

public interface BoardClearListener {
	public void clearBoard();
}
