package com.android.shortestpath.dialog;

import com.android.shortestpath.R;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;

public class WeightDialog {
	
	private Context context;
	private WeightCalculatorListener listener;
	
	public WeightDialog(Context context,WeightCalculatorListener mListener){
		this.context=context;
		this.listener=mListener;
	}
	
	public void buildDialog(){
		AlertDialog.Builder builder = new AlertDialog.Builder(context);
	    builder.setTitle("Edge weight!")
	           .setItems(R.array.weight_array, new DialogInterface.OnClickListener() {
	               public void onClick(DialogInterface dialog, int which) {
	            	   listener.weightCalculated(which);
	           }
	    }).create().show();		
	}
	
	public interface WeightCalculatorListener {
		public void weightCalculated(int weight);
	}
}
