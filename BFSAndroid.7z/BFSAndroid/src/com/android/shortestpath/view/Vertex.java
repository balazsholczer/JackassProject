package com.android.shortestpath.view;

public class Vertex {

	private float x;
	private float y;
	private String vertexName;
	private boolean visited;

	public Vertex() {

	}

	public Vertex(float x, float y, String vertexName) {
		this.x = x;
		this.y = y;
		this.vertexName = vertexName;
	}

	public float getX() {
		return x;
	}

	public void setX(float x) {
		this.x = x;
	}

	public float getY() {
		return y;
	}

	public void setY(float y) {
		this.y = y;
	}

	public String getVertexName() {
		return vertexName;
	}

	public void setVertexName(String vertexName) {
		this.vertexName = vertexName;
	}	

	public boolean isVisited() {
		return visited;
	}

	public void setVisited(boolean visited) {
		this.visited = visited;
	}

	@Override
	public String toString() {
		return "Vertex [x=" + x + ", y=" + y + ", vertexName=" + vertexName
				+ "]";
	}
	
	
}
