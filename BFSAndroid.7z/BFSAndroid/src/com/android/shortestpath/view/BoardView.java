package com.android.shortestpath.view;

import java.util.List;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.text.Editable;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.KeyEvent.DispatcherState;
import android.view.SurfaceHolder.Callback;
import android.view.SurfaceView;
import android.view.View;
import android.widget.EditText;
import com.android.shortestpath.R;
import com.android.shortestpath.dialog.WeightDialog;
import com.android.shortestpath.dialog.WeightDialog.WeightCalculatorListener;
import com.android.shortestpath.model.Database;
import com.android.shortestpath.util.Constants;
import com.android.shortestpath.util.State;

public class BoardView extends SurfaceView implements Callback,
		WeightCalculatorListener {

	private static Paint vertexPaint;
	private static Paint visitedVertexPaint;
	private static Paint edgeWeightPaint;
	private static Paint vertexNamePaint;
	private static Paint edgePaint;
	private static Paint startPointPaint;
	private static Database database;
	private static int count = 1;
	private boolean isFirstSet;
	private static State currentState = State.ADD_EDGE;
	private float x;
	private float y;
	private String name;
	private int weight;
	private static Canvas canvas;
	private WeightDialog weightDialog;
	private static SurfaceHolder holder;

	public BoardView(Context context, AttributeSet attrs) {
		super(context, attrs);

		database = new Database();

		weightDialog = new WeightDialog(getContext(), this);

		vertexPaint = new Paint();
		vertexPaint.setColor(Color.BLACK);
		
		startPointPaint = new Paint();
		startPointPaint.setColor(Color.YELLOW);
		
		visitedVertexPaint = new Paint();
		visitedVertexPaint.setColor(Color.GREEN);

		edgePaint = new Paint();
		edgePaint.setColor(Color.RED);
		edgePaint.setStrokeWidth(15);

		vertexNamePaint = new Paint();
		vertexNamePaint.setColor(Color.BLACK);
		vertexNamePaint.setTextSize(40);

		edgeWeightPaint = new Paint();
		edgeWeightPaint.setColor(Color.BLUE);
		edgeWeightPaint.setTextSize(40);

	}

	@Override
	public boolean onTouchEvent(MotionEvent event) {

		holder = getHolder();

		canvas = holder.lockCanvas();

		if (canvas != null) {

			canvas.drawColor(Color.WHITE);
			canvas.drawText("Breadth-first search 'BFS'", 20, 50, vertexNamePaint);

			if (currentState == State.ADD_VERTEX) {
				addVertex(event);
			}else if (currentState == State.ADD_EDGE) {
				addEdge(event);
			}else if( currentState == State.ADD_START_POINT){
				addStartingPoint(event);
				Log.e("---------------","addStartingPoint()....");
			}

			plotEdges(canvas);
			plotVertexes(canvas);

			holder.unlockCanvasAndPost(canvas);
		}
		return true;
	}

	private void addStartingPoint(MotionEvent event) {
		Vertex vertex = null;

		if (event.getAction() == MotionEvent.ACTION_UP) {
			if ((vertex = database.containPoint(event.getX(), event.getY())) != null) {
				database.setStartingVertex(vertex);
				Log.e("---------------","addStartingPoint()....added to database");
				plotVertexes(canvas);
			}
		}
	}

	private void addEdge(MotionEvent event) {
		Vertex vertex = null;

		if (event.getAction() == MotionEvent.ACTION_UP) {
			if ((vertex = database.containPoint(event.getX(), event.getY())) != null) {

				if (!isFirstSet && vertex != null) {
					x = vertex.getX();
					y = vertex.getY();
					name = vertex.getVertexName();
					isFirstSet = true;
					vertex = null;
				} else if (isFirstSet && vertex != null) {

					weightDialog.buildDialog();
					Edge edgeTemp = new Edge();
					edgeTemp.setVertexTo(vertex);
					edgeTemp.setVertexFrom(new Vertex(x, y, name));

					database.addEdge(edgeTemp);
					isFirstSet = false;
					vertex = null;
				}
			}
		}
	}

	private void addVertex(MotionEvent event) {
		if (event.getAction() == MotionEvent.ACTION_UP) {
			Vertex vertex = new Vertex(event.getX(), event.getY(), "" + count++);
			database.addVertex(vertex);
		}
		plotVertexes(canvas);
	}

	private static void plotVertexes(Canvas canvas) {
		
		for (int i = 0; i < database.getVertexListSize(); i++) {
			
			if( database.getVertex(i).isVisited() ){
				canvas.drawCircle(database.getVertex(i).getX(),database.getVertex(i).getY(), Constants.VERTEX_RADIUS,visitedVertexPaint);
			}else{
				canvas.drawCircle(database.getVertex(i).getX(),database.getVertex(i).getY(), Constants.VERTEX_RADIUS,vertexPaint);
			}
			
			canvas.drawText(database.getVertex(i).getVertexName(), database.getVertex(i).getX(), database.getVertex(i).getY()- Constants.VERTEX_NAME_OFFSET, vertexNamePaint);
		}
		
		if( database.getStartingVertex() != null ){
			Log.e("---------------","addStartingPoint()....plotted to scren");
			canvas.drawCircle(database.getStartingVertex().getX(),
					database.getStartingVertex().getY(), Constants.VERTEX_RADIUS,startPointPaint);
		}
	}

	private static void plotEdges(Canvas canvas) {
		List<Edge> edges = database.getAllEdges();
		for (Edge edge : edges) {		
			canvas.drawLine(edge.getVertexFrom().getX(), edge.getVertexFrom().getY(), edge.getVertexTo().getX(), edge.getVertexTo().getY(), edgePaint);
			canvas.drawText("" + edge.getWeight(),(edge.getVertexFrom().getX() + edge.getVertexTo().getX()) / 2,(edge.getVertexFrom().getY() + edge.getVertexTo().getY()) / 2,edgeWeightPaint);
		}		
	}

	public static void updateState(State state) {
		currentState = state;
	}

	@Override
	public void surfaceCreated(SurfaceHolder holder) {
	}

	@Override
	public void surfaceChanged(SurfaceHolder holder, int format, int width,int height) {
	}

	@Override
	public void surfaceDestroyed(SurfaceHolder holder) {
	}

	public static void clearBoard(View view) {
		holder.lockCanvas();
		database.clearDatabase();
		count = 1;
		canvas.drawColor(Color.WHITE);
		canvas.drawText("BFS - a l g o r i t h m", 20, 50, vertexNamePaint);
		holder.unlockCanvasAndPost(canvas);
	}

	@Override
	public void weightCalculated(int weight) {
		this.weight = weight;
		Edge e = database.getEdge(database.getEdgeListSize() - 1);
		e.setWeight(weight + 1);
		database.removeEdge(database.getEdgeListSize() - 1);
		database.addEdge(e);
		getHolder().lockCanvas();
		plotEdges(canvas);
		plotVertexes(canvas);
		getHolder().unlockCanvasAndPost(canvas);
	}

	public static void addNextVisitedNode(Vertex vertex) {
		holder.lockCanvas();
		//canvas.drawCircle(vertex.getX(), vertex.getY(), Constants.VERTEX_RADIUS, visitedVertexPaint);	
		canvas.drawColor(Color.WHITE);
		canvas.drawText("BFS - a l g o r i t h m", 20, 50, vertexNamePaint);
		plotEdges(canvas);
		plotVertexes(canvas);
		holder.unlockCanvasAndPost(canvas);
	}
}
