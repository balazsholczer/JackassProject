package com.android.shortestpath.kruskal;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;

import android.util.Log;

import com.android.shortestpath.model.Database;
import com.android.shortestpath.view.BoardView;
import com.android.shortestpath.view.Edge;
import com.android.shortestpath.view.Vertex;

class Graph {
	
	private final int MAX_VERTEXES;
	private int adjacencyMatrix[][];
	private List<Edge> edges;
	private List<Vertex> nodes;
	private Vertex startVertex;

	public Graph(int size,List<Edge> edges,List<Vertex> nodes,Vertex startingVertex) {
		
		this.edges=edges;
		this.nodes=nodes;
		this.startVertex=startingVertex;
		
		MAX_VERTEXES=size;

		adjacencyMatrix = new int[MAX_VERTEXES][MAX_VERTEXES];
		
		for (int j = 0; j < MAX_VERTEXES; j++)
			for (int k = 0; k < MAX_VERTEXES; k++)
				adjacencyMatrix[j][k] = 0;
		
		constructMatrix();	
	}
	
	public void constructMatrix(){		
		for(Edge edge : edges ){
			addEdge(Integer.parseInt(edge.getVertexFrom().getVertexName())-1,Integer.parseInt(edge.getVertexTo().getVertexName())-1);			
		}	
	}

	public void addEdge(int start, int end) {
		adjacencyMatrix[start][end] = 1;
		adjacencyMatrix[end][start] = 1;
	}

	public void bfs() {	
		Queue<Vertex> queue = new LinkedList<Vertex>();
	
		queue.add(startVertex);
		startVertex.setVisited(true);
		Database.saveVisitedNode(startVertex);
				
		while(!queue.isEmpty()){
			Vertex node = (Vertex) queue.remove();
			int nodeIndex = nodes.indexOf(node);	
			
			Log.e("Node start", " "+node);
			
			System.out.println("Examining node " + node + ".");

			for(int i = 0; i < adjacencyMatrix.length; i++) {
				if(adjacencyMatrix[nodeIndex][i] == 1 && nodes.get(i).isVisited() == false ){
					queue.add(nodes.get(i));
					nodes.get(i).setVisited(true);
					Database.saveVisitedNode(nodes.get(i));
					Log.e("Node visited", " "+nodes.get(i));
					
					try {
						Thread.sleep(1500);
						BoardView.addNextVisitedNode(nodes.get(i));
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
					
				}
			}
		}
		
		Log.e("Node start", "All nodes have been visited so far");	
	}
}

