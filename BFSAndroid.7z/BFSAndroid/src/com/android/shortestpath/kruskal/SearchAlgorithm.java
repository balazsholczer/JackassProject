package com.android.shortestpath.kruskal;

import java.util.List;

import android.util.Log;

import com.android.shortestpath.model.Database;
import com.android.shortestpath.view.Edge;
import com.android.shortestpath.view.Vertex;

public class SearchAlgorithm {

	private Database database;
	
	public void runBsf(){
		
		List<Edge> edges = Database.edgeList;
		List<Vertex> nodes = Database.vertexList;
		Vertex startingVertex = Database.startingVertex;
		
		Graph theGraph = new Graph(nodes.size(),edges,nodes,startingVertex);			
		
//	      theGraph.addVertex('A');    // 0  (start for bfs)
//	      theGraph.addVertex('B');    // 1
//	      theGraph.addVertex('C');    // 2
//	      theGraph.addVertex('D');    // 3
//	      theGraph.addVertex('E');    // 4
//
//	      theGraph.addEdge(0, 1);     // AB
//	      theGraph.addEdge(1, 2);     // BC
//	      theGraph.addEdge(0, 3);     // AD
//	      theGraph.addEdge(3, 4);     // DE
//
//	      System.out.print("Visits: ");
	      theGraph.bfs();             // breadth-first search
//	      System.out.println();
		
	}
}
