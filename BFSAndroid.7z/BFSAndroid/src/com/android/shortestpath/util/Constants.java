package com.android.shortestpath.util;

public class Constants {

	public static final int VERTEX_RADIUS = 30;
	public static final int VERTEX_NAME_OFFSET = 50;
	public static final int PRECISION = 100;
	public static final int EDGE_WEIGHT_OFFSET = 20;
	
	private Constants(){
		
	}
	
}
