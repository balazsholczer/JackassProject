package com.android.shortestpath.util;

public enum State {

	ADD_EDGE, ADD_VERTEX,ADD_START_POINT;

}
