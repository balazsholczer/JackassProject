package App;

import org.apache.commons.math3.transform.FastFourierTransformer;

public class App {

	private static final String Log = null;

	public static void main(String[] args) {

		double [] input = new double[8];
	    input[0] = 0.0;
	    input[1] = 162.6345596729059;
	    input[2] = 230.0;
	    input[3] = 162.63455967290594;
	    input[4] = 2.8166876380389125E-14;
	    input[5] = -162.6345596729059;
	    input[6] = -230.0;
	    input[7] = -162.63455967290597;

	    double[] tempConversion = new double[input.length];

	    FastFourierTransformer transformer = new FastFourierTransformer();
	    try {           
	        
	    	Complex[] complx = transformer.transform(input);

	        for (int i = 0; i < complx.length; i++) {               
	            double rr = (complx[i].getReal());
	            double ri = (complx[i].getImaginary());

	            tempConversion[i] = Math.sqrt((rr * rr) + (ri * ri));
	            System.out.println(tempConversion[i]);
	        }

	    } catch (IllegalArgumentException e) {
	        System.out.println(e);
	    }

	   
	}
}
