package SwapWords;

public class SwapXOR {

	/*
	 * Ketfelekeppen lehet megoldani, egy kicsit szebb a bitwise XOR operatoros
	 */
	
	public static void main(String[] args) {
		
		int x = 123;
		int y = 4;
		
		System.out.println("Number x="+x+" and y="+y);
		System.out.println("...");
		
		swapNumbers(x, y);
		swapNumbersWithXor(x, y);

	}
	
	public static void swapNumbersWithXor(int x, int y){
		x = x ^ y;
		y = x ^ y;
		x = x ^ y;
		
		System.out.println("Without 3rd variable: x="+x+" and y="+y);
	}
	
	public static void swapNumbers(int x, int y){
		
		x = x + y;
		y = x - y;
		x = x - y;
		
		System.out.println("Without 3rd variable: x="+x+" and y="+y);	
	}
}
