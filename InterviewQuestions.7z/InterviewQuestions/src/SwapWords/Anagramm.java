package SwapWords;

public class Anagramm {

	/*
	 * Fastest algorithm for this problem would be to map each letter of the alphabet to a given 
	 * prime number. Then compute the sum of these multiplication based on this dictionary. Two strings are the same
	 * only and if only the sum is the same based on the number theory.
	 * 
	 * Anagram: amikor ugyanolyan betuket tartalmaz egy szo + a szavak mennyisege is megyegyezik pl: listen - silent
	 * Palindrome: amikor ugyanaz elolrol + hatolrol olvasva az adott szo/mondat 
	 */
	
	public static void main(String[] args) {
		
	}
}
