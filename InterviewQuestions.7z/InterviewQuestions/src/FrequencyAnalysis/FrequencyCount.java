package FrequencyAnalysis;

public class FrequencyCount {

	/**
	 * Zipf's law: az adott szovegben elofordulo szavak szamanak gyakorisagaval kapcsolatos torveny
	 * 		Az i. leggyakoribb elem elofordulasi gyakorisaga egy M szobol allo szovegben aranyos lesz 1/i vel mindig 
	 */
	
	public static void main(String[] args) {
		
		String text = "This is a program enables us to determine the relative frequencies of words in a given text";
		
		String[] words = text.split("\\s+");
		
		MergeSort.sort(words);
		
		Counter [] counters = new Counter[words.length];
		
		int M = 0;	
		for(int i=0;i<words.length;i++){
			if( i==0 || !words[i].equals(words[i-1])){
				counters[M++] = new Counter(words[i],words.length);
			}
			counters[M-1].increment();
		}
		
		MergeSort.sort(counters,0,M);
		
		for(int j=M-1;j>=0;j--){
			System.out.println(counters[j]);
		}
		
	}
}
