package FrequencyAnalysis;

public class Counter implements Comparable<Counter> {

	private final String name;
	private final int maxCount;
	private int count;
	
	public Counter(String id,int maxCount){
		this.name=id;
		this.maxCount=maxCount;
	}
	
	public void increment(){
		if( count < maxCount ) count++;
	}
	
	public int value(){
		return this.count;
	}
	
	@Override
	public int compareTo(Counter counter) {
		if( count < counter.count ) return -1;
		else if( count > counter.count ) return +1;
		else return 0;
	}
	
	@Override
	public String toString() {
		return name + ": " + count;
	}
}
