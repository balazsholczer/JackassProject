package com.example.downloadbitmapurl;

import android.graphics.Bitmap;

public class Image {

    private Bitmap bitmapImage;
    private String description;

    public Image() {

    }

    public Image(Bitmap bitmapImage, String description) {
        this.bitmapImage = bitmapImage;
        this.description = description;
    }

    public Bitmap getBitmapImage() {
        return bitmapImage;
    }

    public void setBitmapImage(Bitmap bitmapImage) {
        this.bitmapImage = bitmapImage;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}
