package com.example.downloadbitmapurl;

import java.io.InputStream;
import java.net.URL;

import android.content.AsyncTaskLoader;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Log;

public class BitmapDownloader extends AsyncTaskLoader<Image> {

    private String url;
    
    public BitmapDownloader(Context context,String url) {
        super(context);
        this.url=url;
    }

    @Override
    public Image loadInBackground() {

        Bitmap tempImage = null;

        try {
            InputStream in = new URL(url).openStream();
            tempImage = BitmapFactory.decodeStream(in);
        } catch (Exception e) {
            Log.e("Error", e.getMessage());
            e.printStackTrace();
        }

        Image image = new Image(tempImage, "This is an image donwloaded via HTTP from the web...");
        return image;

    }
}
