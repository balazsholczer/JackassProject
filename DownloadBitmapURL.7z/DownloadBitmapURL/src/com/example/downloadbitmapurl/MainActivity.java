package com.example.downloadbitmapurl;


import android.app.Activity;
import android.app.LoaderManager;
import android.content.Loader;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.widget.ImageView;

public class MainActivity extends Activity implements LoaderManager.LoaderCallbacks<Image> {

    private String url = "https://lh5.googleusercontent.com/-GoUQVw1fnFw/URquv6xbC0I/AAAAAAAAAbs/zEUVTQQ43Zc/s1024/Kauai.jpg";
    public static final int UPDATE_IMAGE = 11;
    public static final int UPDATE_IMAGE_MESSAGE = 123;
    private ImageView imageView;
    
    private Handler handler = new Handler(new Handler.Callback() {    
        public boolean handleMessage(Message msg) {
            
            if( msg.what == UPDATE_IMAGE_MESSAGE ){
                
                              
                Image image = (Image) msg.obj;                                          
                imageView.setImageBitmap(image.getBitmapImage());
               
            }        
            return true;
        }
    });
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        imageView = (ImageView) findViewById(R.id.imageView);                           
    }
    
    public void loadData(View view){
        getLoaderManager().restartLoader(UPDATE_IMAGE, null, this).forceLoad();
    }

    @Override
    public Loader<Image> onCreateLoader(int id, Bundle args) {
        return new BitmapDownloader(getApplicationContext(), url);
    }

    @Override
    public void onLoadFinished(Loader<Image> loader, Image data) {
        
        switch (loader.getId()) {
        case UPDATE_IMAGE:
            sendMessageToHandler(data,UPDATE_IMAGE_MESSAGE);
            break;
        default: break;
        }
        
    }

    private void sendMessageToHandler(Image data, int updateImageMessage) {
        Message message = new Message();
        message.obj=data;
        message.what=updateImageMessage;
        handler.sendMessage(message);
    }

    @Override
    public void onLoaderReset(Loader<Image> loader) {
       
    }   
}
