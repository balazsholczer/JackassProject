package AVLAlgorithm;


public class App {

	public static void main(String[] args) {

		AVLTree<String> tree = new AVLTree<String>();
		
//		for (int i = 1; i <= 5; i++)
//			tree.insert(new Integer(i));
//			
//		tree.PrintTree();
		
		tree.insert("Holczer Balazs");
		tree.insert("Kaso Mate");
		tree.insert("Szentirmai Attila");
		tree.insert("Horvath Gabor");
		
		tree.PrintTree();
		System.out.println();
		System.out.println(tree.Maximum());
		System.out.println(tree.Minimum());

	}
}
