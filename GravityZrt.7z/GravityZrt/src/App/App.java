package App;

import java.util.List;

public class App {

	public static void main(String[] args) {
		
		DataReader dataReader = new DataReader();
		dataReader.parseFile();
		
		List<Point> points = dataReader.getCoordinates();	
		calculateMinimalDistance(points);
	}

	private static void calculateMinimalDistance(List<Point> points) {
		
		int rowStart = 0;
		int rowEnd = 0;
		double minDistance = Integer.MAX_VALUE;
		
		for(int i=0;i<Constants.DIMENSION;i++){
			for(int j=0;j<Constants.DIMENSION;j++){
				
				if( i==j) continue;
				
				double minTempDistance = Math.sqrt((points.get(i).getX()-points.get(j).getX())*(points.get(i).getX()-points.get(j).getX())+
											       (points.get(i).getY()-points.get(j).getY())*(points.get(i).getY()-points.get(j).getY()) +
											       (points.get(i).getZ()-points.get(j).getZ())*(points.get(i).getZ()-points.get(j).getZ())									      
											      );
				
				System.out.println("From "+i+" to "+j + " the distance is : "+minTempDistance);
				
				if( minTempDistance - minDistance < Constants.epsilon  ){
					rowStart = i;
					rowEnd = j;
					minDistance=minTempDistance;
				}	
			}
			
				
		}	
		
		System.out.println("Dimension is: "+Constants.DIMENSION);
		System.out.println("Minimal distance: "+minDistance);
		System.out.println("The two rows in file are: "+(rowStart+1)+" and "+(rowEnd+1));
	}
}
