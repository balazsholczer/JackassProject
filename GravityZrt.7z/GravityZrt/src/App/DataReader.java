package App;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class DataReader {

	private BufferedReader bufferedReader;
	private List<Point> points;
	
	public void parseFile(){
		try {
			
			points = new ArrayList<>();
			bufferedReader = new BufferedReader(new FileReader("data.txt"));
			
			String line;
			
			while ((line = bufferedReader.readLine()) != null) {
				
				String[] splitedData = line.split("\\t");
				
				Constants.DIMENSION = splitedData.length;
				
				double x = Double.parseDouble(splitedData[0]);
				double y = Double.parseDouble(splitedData[1]);
				double z = Double.parseDouble(splitedData[2]);
				
				//points.add(new Point(x,y));
				points.add(new Point(x,y,z));
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally{
			try {
				bufferedReader.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}	
	}	
	
	public List<Point> getCoordinates(){
		return this.points;
	}
}
