package App;

public class Constants {

	public static int DIMENSION;
	public static final double epsilon = 0.001;
	
	private Constants(){
		
	}
}
