package com.example.epmbudn_249;

import java.io.File;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;
import android.widget.Toast;

public class MainActivity extends Activity implements OnClickListener {

	private static final int RESULT_LOAD_IMAGE = 0;
	private static final int PHOTO_TAKEN = 1;

	private ImageView imageView;
	private File imageFile;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		imageView = (ImageView) findViewById(R.id.imageView);
		imageView.setOnClickListener(this);

	}

	public void snapPhoto(View view) {
		Intent i = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
		startActivityForResult(i, PHOTO_TAKEN);
	}

	public void loadPhoto(View view) {
		Intent intent = new Intent(Intent.ACTION_PICK,
				android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
		startActivityForResult(intent, RESULT_LOAD_IMAGE);
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		super.onActivityResult(requestCode, resultCode, data);

		if (requestCode == RESULT_LOAD_IMAGE && resultCode == RESULT_OK
				&& data != null) {
			loadSelectedImage(data);

		} else if (requestCode == PHOTO_TAKEN && resultCode == RESULT_OK
				&& data != null) {
			loadSelectedImage(data);
		}
	}

	private void loadSelectedImage(Intent data) {
		Uri imageUri = data.getData();
		new ImageLoaderTask().execute(imageUri);
	}

	class ImageLoaderTask extends AsyncTask<Uri, Void, Bitmap> {

		@Override
		protected Bitmap doInBackground(Uri... params) {
			Uri imageUri = params[0];
			int width = imageView.getWidth();
			int height = imageView.getHeight();
			return ImageUtils.decodeBitmapByUri(getContentResolver(), imageUri, width, height);
		}

		@Override
		protected void onPostExecute(Bitmap result) {
			if (result != null) {
				
				imageView.setImageBitmap(result);
			}
		}
	}

	@Override
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.imageView:
			Toast.makeText(getApplicationContext(), "Click", Toast.LENGTH_SHORT).show();
			break;

		default:
			break;
		}
		
	}

}
