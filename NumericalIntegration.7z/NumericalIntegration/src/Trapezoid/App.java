package Trapezoid;

public class App {

	private static final double h = 0.1f;
	
	public static void main(String[] args) {

		
		
		System.out.println(integrate(0, 1, 100000));
		

	}
	
	public static double integrate(double a, double b, int N) {
	      double h = (b - a) / N;              // step size
	      double sum = 0.5 * (f(a) + f(b));    // area
	      for (int i = 1; i < N; i++) {
	         double x = a + h * i;
	         sum = sum + f(x);
	      }

	      return sum * h;
	   }
	
	public static double f(double x){
		return x*x;
	}
}
