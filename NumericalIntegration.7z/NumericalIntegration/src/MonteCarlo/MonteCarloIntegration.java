package MonteCarlo;

public class MonteCarloIntegration {

	public double f(double x){
		return x*x+x+1;
	}

	public double monteCarloIntegration(double a,double b,long iteration){
		
		if( a > b ) return monteCarloIntegration(b, a, iteration);
		
		double sum = 0;
		double x;
		
		for(long i = 0;i<iteration;i++){
			x=Math.random();
			sum+=f(a+((b-a)*x));
		}
		
		sum*=(b-a)/iteration;
		
		return sum;
	}
}
