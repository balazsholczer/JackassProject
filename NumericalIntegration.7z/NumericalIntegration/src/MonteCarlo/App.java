package MonteCarlo;

import java.util.Random;

public class App {

	public static void main(String[] args) {

		System.out.println("Monte Carlo integration...");

		MonteCarloIntegration monteCarlo = new MonteCarloIntegration();
		System.out.println(monteCarlo.monteCarloIntegration(-1, 1, 10000000));

	}

	public static double getPi(int numberOfThrows) {

		int inCircle = 0;

		for (int i = 0; i < numberOfThrows; i++) {
			double randomX = (Math.random() * 2) - 1; // range [-1,1]
			double randomY = (Math.random() * 2) - 1;

			double distanceFromOrigo = Math.sqrt(randomX * randomX + randomY
					* randomY);

			if (distanceFromOrigo < 1) {
				inCircle++;
			}
		}

		return 4.0 * inCircle / numberOfThrows; // Tk�r / Tnegyzet = inCircle /
												// allThrows -> ez az alapelv
												// mindig

	}
}
