package com.example.exerciseservicebroadcast;

import com.example.exerciseservicebroadcast.MyService.MyBinderClass;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.IBinder;
import android.widget.TextView;

public class MainActivity extends Activity {

    public static final String FILTER_FOR_SERVICE = "com.itk.kiralysag.ideirahatok.barmit";
    public static final String KEY_FOR_MESSAGE = "tokmind1_hogymi";
    private TextView countTextView;
    private boolean isBind;
    private MyService myService;
    
    private BroadcastReceiver broadcastReceiver = new BroadcastReceiver() {     
        @Override
        public void onReceive(Context context, Intent intent) {
            
            int text = intent.getExtras().getInt(KEY_FOR_MESSAGE);            
            countTextView.append(text+"\n");
            
        }
    };
    
    private ServiceConnection serviceConnection = new ServiceConnection() {     
        @Override
        public void onServiceDisconnected(ComponentName name) {
            isBind=false;
        }     
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
           MyBinderClass myBinderClass = (MyBinderClass) service;
           myService = myBinderClass.getService();
           isBind=true;
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        countTextView = (TextView) findViewById(R.id.countTextView);

        new Thread(new Runnable() {
            public void run() {
                Intent intent = new Intent(MainActivity.this,MyService.class);
                bindService(intent, serviceConnection, BIND_AUTO_CREATE);
            }
        }).start();
    }
    
    @Override
    protected void onResume() {     
        super.onResume();      
        IntentFilter intentFilter = new IntentFilter(FILTER_FOR_SERVICE);
        registerReceiver(broadcastReceiver, intentFilter);       
    }
       
    @Override
    protected void onPause() {
        unregisterReceiver(broadcastReceiver);
        super.onPause();
    }
}
