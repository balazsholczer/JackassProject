package com.example.exerciseservicebroadcast;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import android.app.Service;
import android.content.Intent;
import android.os.Binder;
import android.os.CountDownTimer;
import android.os.IBinder;
import android.util.Log;

public class MyService extends Service {

    private int count = 0;

    public MyService() {
        new CountDownTimer(10000 * 60, 2000) {
            @Override
            public void onTick(long millisUntilFinished) {
                Log.e("service", "onTick()");
                push();
            }

            @Override
            public void onFinish() {
            }
        }.start();
    }

    @Override
    public IBinder onBind(Intent arg0) {
        return new MyBinderClass();
    }
    
    private int getCount(){
        return count++;
    }

    public class MyBinderClass extends Binder {
        public MyService getService() {        
            return MyService.this;
        }
    }

    public String getCurrentTime() {
        SimpleDateFormat dateformat = new SimpleDateFormat("HH:mm:ss MM/dd/yyyy", Locale.US);
        return (dateformat.format(new Date()));
    }

    private void push() {   
        Intent intent = new Intent(MainActivity.FILTER_FOR_SERVICE);
        intent.putExtra(MainActivity.KEY_FOR_MESSAGE, getCount());
        sendBroadcast(intent);
    }
}
