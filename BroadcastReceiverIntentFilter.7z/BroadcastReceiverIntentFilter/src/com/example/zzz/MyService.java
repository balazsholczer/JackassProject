package com.example.zzz;
import android.app.IntentService;
import android.content.Intent;
import android.util.Log;

public class MyService extends IntentService {

	private int count = 0;
	
	public MyService(){
		super("myService");
	}

	public MyService(String name) {
		super(name);
	}

	@Override
	protected void onHandleIntent(Intent intent) {
		Log.e("onHandleIntent", "Done");
		
		while(true){
			push(intent);
			try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		
		
	}

	private void push(Intent broadcastIntent) {
		Log.e("push", "Done");
		broadcastIntent = new Intent(Constants.ACTION_RESP);
		//broadcastIntent.addCategory(broadcastIntent.CATEGORY_DEFAULT);
		broadcastIntent.putExtra(Constants.RESPONSE_STRING, getIncrementedCounter());
		sendBroadcast(broadcastIntent);
	}

	public int getIncrementedCounter() {
		return count++;
	}
}
