package com.example.zzz;

public class Constants {

	public static final String RESPONSE_STRING = "gdsahgshdhj";
	public static final String PROCESS_RESPONSE = "jujzzjjzjzzjj";
	public static final String ACTION_RESP = "456567zhg";
}
