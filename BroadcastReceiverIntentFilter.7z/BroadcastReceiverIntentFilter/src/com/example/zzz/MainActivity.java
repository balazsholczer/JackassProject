package com.example.zzz;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

public class MainActivity extends Activity {

	private TextView textView;
	private MyService myService;

	private BroadcastReceiver broadcastReceiver = new BroadcastReceiver() {
		public void onReceive(Context context, Intent intent) {
			
			Log.e("broadcastReceiver", "Done");
			Bundle bundle = intent.getExtras();
			textView.setText("HELLOGERI");
			textView.append("" + bundle.getInt(Constants.RESPONSE_STRING));
		}
	};

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		textView = (TextView) findViewById(R.id.textView);
		
		IntentFilter filter = new IntentFilter(Constants.ACTION_RESP);
		filter.addCategory(Intent.CATEGORY_DEFAULT);
		myService = new MyService();
		startService();
		registerReceiver(broadcastReceiver, filter);

	}

	public void startService() {
		Log.e("startService", "Done");
		Intent intent = new Intent(this, MyService.class);
		startService(intent);
	}
	
	@Override
    public void onDestroy() {
        this.unregisterReceiver(broadcastReceiver);
        super.onDestroy();
    }
}
