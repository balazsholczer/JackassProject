package Integration;

import java.util.Random;

public class App {

	
	public static void main(String[] args) {
		
		System.out.println("Monte Carlo integration...");
		
		MonteCarloIntegration monteCarlo = new MonteCarloIntegration();
		System.out.println(monteCarlo.monteCarloIntegration(-1 , 1, 10000000));	

	}
}
