package DeterminingPI;

public class App {

	public static void main(String[] args) {
		
		long start = System.currentTimeMillis();
		System.out.println(getPi(100000000));
		long end = System.currentTimeMillis();
		
		System.out.println("Simulation took: "+(end-start) + " milliseconds");

	}
	
	public static double getPi(int numberOfThrows){
		
		int inCircle = 0;
		
		for(int i=0;i<numberOfThrows;i++){
			double randomX = (Math.random()*2)-1;  // range [-1,1]
			double randomY = (Math.random()*2)-1;
			
			double distanceFromOrigo = Math.sqrt(randomX*randomX+randomY*randomY);
			
			if( distanceFromOrigo < 1){
				inCircle++;
			}
		}
		
		return 4.0*inCircle/numberOfThrows;  // Tk�r / Tnegyzet = inCircle / allThrows -> ez az alapelv mindig
		
	}
}
