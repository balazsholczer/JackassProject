package com.balazsholczer.stockwatch;

import java.util.ArrayList;
import java.util.List;

import android.app.ActionBar;
import android.app.ActionBar.Tab;
import android.app.ActionBar.TabListener;
import android.app.SearchManager;
import android.app.SearchableInfo;
import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.view.ViewPager;
import android.support.v4.view.ViewPager.OnPageChangeListener;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.SearchView;
import com.balazsholczer.stockwatch.fragments.StockListFragment;
import com.balazsholczer.stockwatch.model.Stock;
import com.balazsholczer.stockwatcher.adapters.ScrollTabAdapter;
import com.balazsholczer.stockwatcher.adapters.StockAdapter;

public class MainActivity extends FragmentActivity implements TabListener{

	private List<Stock> stocks=new ArrayList<>();
	private SearchView searchView;
	private StockListFragment stockListFragment;
	private ActionBar actionBar;
    private ViewPager viewPager;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.fragment_container);
        
        setupViewPager();
        setupSwipeTabs();     	
	}

	private void setupViewPager() {
		viewPager = (ViewPager) findViewById(R.id.myViewPager);
        viewPager.setAdapter(new ScrollTabAdapter(getSupportFragmentManager()));
            
        viewPager.setOnPageChangeListener(new OnPageChangeListener() {       
            @Override
            public void onPageSelected(int position) {
                actionBar.setSelectedNavigationItem(position);
            }           
            @Override
            public void onPageScrolled(int arg0, float arg1, int arg2) {}
            @Override
            public void onPageScrollStateChanged(int arg0) {}
        });
	}
	
	public void setupSwipeTabs(){
		actionBar = getActionBar();
        actionBar.setNavigationMode(ActionBar.NAVIGATION_MODE_TABS);
        
        ActionBar.Tab tab1 = actionBar.newTab();
        tab1.setTabListener(this);
        tab1.setText("Stock Market");
        
        ActionBar.Tab tab2 = actionBar.newTab();
        tab2.setTabListener(this);   
        tab2.setText("News");
      
        actionBar.addTab(tab1);
        actionBar.addTab(tab2);   
	}
	
	@Override
	public void onTabSelected(Tab tab, android.app.FragmentTransaction ft) {
		viewPager.setCurrentItem(tab.getPosition());
	}

	@Override
	public void onTabUnselected(Tab tab, android.app.FragmentTransaction ft) {	}

	@Override
	public void onTabReselected(Tab tab, android.app.FragmentTransaction ft) {	}
}
