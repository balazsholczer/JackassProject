package com.balazsholczer.stockwatch.fragments;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import android.app.ActionBar;
import android.app.SearchManager;
import android.app.SearchableInfo;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.SearchView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListView;

import com.balazsholczer.stockwatch.R;
import com.balazsholczer.stockwatch.activities.SingleStockActivity;
import com.balazsholczer.stockwatch.model.Stock;
import com.balazsholczer.stockwatch.model.StockSymbolName;
import com.balazsholczer.stockwatch.utils.Constants;
import com.balazsholczer.stockwatch.utils.DialogBuilder;
import com.balazsholczer.stockwatcher.adapters.StockAdapter;

public class StockListFragment extends Fragment implements SearchView.OnQueryTextListener{

	private ListView stocksListView;
	private StockSymbolName stockSymbolName;
	private List<Stock> stocksList;
	private List<Stock> finalStocksList;
	private StockAdapter stockAdapter;
	private SearchView searchView;
	private int alpha = 1;

	@Override
	public void onViewStateRestored(@Nullable Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		Log.e("own","own");
		super.onViewStateRestored(savedInstanceState);
	}
	
	public View onCreateView(android.view.LayoutInflater inflater,
			android.view.ViewGroup container, Bundle savedInstanceState) {
		super.onCreateView(inflater, container, savedInstanceState);

		View view = inflater.inflate(R.layout.stock_list_fragment, container,false);
		
		setHasOptionsMenu(true);

		stocksListView = (ListView) view.findViewById(R.id.stocksListView);
		stockSymbolName = new StockSymbolName();

		stocksList = new ArrayList<>();
		initializeList(stocksList);

		stockAdapter = new StockAdapter(getActivity(), stocksList);
		stocksListView.setAdapter(stockAdapter);

		stocksListView.setOnItemClickListener(new OnItemClickListener() {
			public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

				if (!isNetworkAvailable()) {
					DialogBuilder.showAlertDialog(getActivity(),"No Internet Connection","You don't have internet connection.", false);
					return;
				}

				navigateToSingleStockActivity(position);
			}
		});

		return view;
	}
	
	private void navigateToSingleStockActivity(int position) {
			
		Intent intent = new Intent(getActivity(),SingleStockActivity.class);
		intent.putExtra(Constants.KEY_DATA_POSITION, stocksList.get(position));
		startActivity(intent);
		
//		Bundle bundle = new Bundle();
//		bundle.putSerializable(Constants.KEY_DATA_FRAGMENTS,stocksList.get(position));
//		SingleStockFragment singleCurrencyFragment = new SingleStockFragment();
//		singleCurrencyFragment.setArguments(bundle);
//			
//		getFragmentManager().beginTransaction().addToBackStack(null).replace(R.id.fragmentContainer, singleCurrencyFragment).commit();
	}

	public boolean isNetworkAvailable() {
		ConnectivityManager connectivityManager = (ConnectivityManager) getActivity().getSystemService(Context.CONNECTIVITY_SERVICE);
		NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
		return activeNetworkInfo != null;
	}

	private List<Stock> initializeList(final List<Stock> list) {
		for (String key : stockSymbolName.getMap().keySet()) {
			String value = stockSymbolName.getMap().get(key);
			Stock stock = new Stock();
			stock.setCompanyName(value);
			stock.setSymbolOnStockMarket(key);
			list.add(stock);
		}

		finalStocksList=stocksList;
		return list;
	}

	public void updateSearhItems(String newText) {		
		List<Stock> updatedCurrencies = new ArrayList<Stock>();

		for (Stock stock : finalStocksList) {
			if (stock.getCompanyName().toLowerCase().contains(newText.toLowerCase())) {
				updatedCurrencies.add(stock);
			}
		}
		
		this.stocksList=updatedCurrencies;
		this.stockAdapter.refreshCurrencies(stocksList);
		//this.stockAdapter.getFilter().filter(newText);
	}

	@Override
	public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
		super.onCreateOptionsMenu(menu, inflater);
		
		MenuInflater menuInflater = getActivity().getMenuInflater();
		menuInflater.inflate(R.menu.main, menu);
		MenuItem searchItem = menu.findItem(R.id.action_search);
		searchView = (SearchView) searchItem.getActionView();
		setupSearchView(searchItem);	
	}
	
	private void setupSearchView(MenuItem searchItem) {
		
		searchItem.setShowAsActionFlags(MenuItem.SHOW_AS_ACTION_IF_ROOM | MenuItem.SHOW_AS_ACTION_COLLAPSE_ACTION_VIEW);

		SearchManager searchManager = (SearchManager) getActivity().getSystemService(Context.SEARCH_SERVICE);
		if (searchManager != null) {
			List<SearchableInfo> searchables = searchManager.getSearchablesInGlobalSearch();

			SearchableInfo info = searchManager.getSearchableInfo(getActivity().getComponentName());
			for (SearchableInfo inf : searchables) {
				if (inf.getSuggestAuthority() != null && inf.getSuggestAuthority().startsWith("applications")) {
					info = inf;
				}
			}
			searchView.setSearchableInfo(info);
		}
		searchView.setOnQueryTextListener(this);
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		super.onOptionsItemSelected(item);

		switch (item.getItemId()) {
		case R.id.sort:
			sortListAlphabeticalOrder();
			break;
		}

		return true;
	}

	private void sortListAlphabeticalOrder() {
		Collections.sort(stocksList,new Comparator<Stock>() {
			public int compare(Stock stock1, Stock stock2) {
				return alpha*stock1.getCompanyName().compareTo(stock2.getCompanyName());
			}
		});
		
		this.stockAdapter.refreshCurrencies(stocksList);
		alpha*=-1;
	}

	@Override
	public boolean onQueryTextSubmit(String query) {
		return false;
	}

	@Override
	public boolean onQueryTextChange(String newText) {
		updateSearhItems(newText);
		return false;	
	}
}
