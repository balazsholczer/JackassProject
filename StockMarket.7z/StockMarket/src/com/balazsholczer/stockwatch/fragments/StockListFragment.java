package com.balazsholczer.stockwatch.fragments;

import java.util.ArrayList;
import java.util.List;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListView;

import com.balazsholczer.stockwatch.R;
import com.balazsholczer.stockwatch.model.Stock;
import com.balazsholczer.stockwatch.model.StockSymbolName;
import com.balazsholczer.stockwatch.utils.Constants;
import com.balazsholczer.stockwatch.utils.DialogBuilder;
import com.balazsholczer.stockwatcher.adapters.StockAdapter;

public class StockListFragment extends Fragment{

	private ListView stocksListView;
	private StockSymbolName stockSymbolName;
	private List<Stock> stocksList;
	private StockAdapter stockAdapter;

	public View onCreateView(android.view.LayoutInflater inflater,android.view.ViewGroup container, Bundle savedInstanceState) {
		super.onCreateView(inflater, container, savedInstanceState);
		
		View view = inflater.inflate(R.layout.stock_list_fragment, container, false);
		
		stocksListView = (ListView) view.findViewById(R.id.stocksListView);
		stockSymbolName = new StockSymbolName();
		
		stocksList = new ArrayList<>();
		initializeList(stocksList);
		
		stockAdapter = new StockAdapter(getActivity(), stocksList);
		stocksListView.setAdapter(stockAdapter);
		
		stocksListView.setOnItemClickListener(new OnItemClickListener() {
			public void onItemClick(AdapterView<?> parent, View view,int position, long id) {
				
				if( !isNetworkAvailable() ){
					DialogBuilder.showAlertDialog(getActivity(), "No Internet Connection","You don't have internet connection.", false);
					return;
				}
				
				Bundle bundle = new Bundle();
				bundle.putSerializable(Constants.KEY_DATA_FRAGMENTS, stocksList.get(position));
				SingleStockFragment singleCurrencyFragment = new SingleStockFragment();
				singleCurrencyFragment.setArguments(bundle);
				
				getFragmentManager().beginTransaction().addToBackStack(null).replace(R.id.fragmentContainer,singleCurrencyFragment).commit();
			}
		});
		
		return view;
	}
	
	public boolean isNetworkAvailable() {
        ConnectivityManager connectivityManager = (ConnectivityManager) getActivity().getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
        return activeNetworkInfo != null;
    }

	private List<Stock> initializeList(final List<Stock> list) {
		for(String key : stockSymbolName.getMap().keySet() ){
			String value = stockSymbolName.getMap().get(key);
			Stock stock = new Stock();
			stock.setCompanyName(value);
			stock.setSymbolOnStockMarket(key);
			list.add(stock);
		}
		
		return list;
	}

	public void updateSearhItems(String newText) {
		List<Stock> updatedCurrencies= new ArrayList<Stock>();
		
		for(Stock stock : stocksList ){
			if( stock.getCompanyName().toLowerCase().contains(newText.toLowerCase()) ){
				updatedCurrencies.add(stock);
			}
		}
		
		stocksList=updatedCurrencies;
		
		this.stockAdapter.refreshCurrencies(updatedCurrencies);	
	}
}
