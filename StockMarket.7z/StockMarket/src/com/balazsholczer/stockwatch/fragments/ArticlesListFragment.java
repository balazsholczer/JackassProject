package com.balazsholczer.stockwatch.fragments;

import java.util.List;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListView;

import com.balazsholczer.stockwatch.R;
import com.balazsholczer.stockwatch.activities.NewsActivity;
import com.balazsholczer.stockwatch.activities.SingleStockActivity;
import com.balazsholczer.stockwatch.model.RssItem;
import com.balazsholczer.stockwatch.utils.Constants;
import com.balazsholczer.stockwatch.utils.RssReader;
import com.balazsholczer.stockwatcher.adapters.RssAdapter;

public class ArticlesListFragment extends Fragment {

	private List<RssItem> downloadedRssList;
	private RssAdapter rssAdapter;
	private ListView listView;

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {

		View view = inflater.inflate(R.layout.article_list_fragment_layout,container, false);

		listView = (ListView) view.findViewById(R.id.listView);	
		
		new RssDownloader().execute();
	
		listView.setOnItemClickListener(new OnItemClickListener() {
			public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
				navigateToNewsActivity(position);
			}
		});

		return view;
	}
	
	public void navigateToNewsActivity(int position){
		
		Intent intent = new Intent(getActivity(),NewsActivity.class);
		intent.putExtra(Constants.URL_KEY, downloadedRssList.get(position).getLink());
		startActivity(intent);
		
//		ArticleFragment articleFragment = new ArticleFragment();
//		
//		Bundle bundle = new Bundle();
//		bundle.putString(Constants.URL_KEY, downloadedRssList.get(position).getLink());
//		
//		articleFragment.setArguments(bundle);
//		
//		getFragmentManager().beginTransaction().addToBackStack(null).replace(R.id.fragmentContainer, articleFragment).commit();
	}
	
	private class RssDownloader extends AsyncTask<Void, Void, Void>{

		RssReader rssReader;
		
		@Override
		protected Void doInBackground(Void... params) {
			
			rssReader = new RssReader(Constants.RSS_URL);
			downloadedRssList = rssReader.getItems();
			
			return null;
		}	
		
		@Override
		protected void onPostExecute(Void result) {
			rssAdapter = new RssAdapter(getActivity(),downloadedRssList);
			listView.setAdapter(rssAdapter);
		}
	}
}
