package com.balazsholczer.stockwatch.fragments;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;

import com.balazsholczer.stockwatch.R;
import com.balazsholczer.stockwatch.utils.ArticleBrowser;
import com.balazsholczer.stockwatch.utils.Constants;
import com.balazsholczer.stockwatch.utils.DialogBuilder;

public class ArticleFragment extends Fragment{

	private WebView browser;
	
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		
		View view = inflater.inflate(R.layout.article_webview_layout, container, false);
		
		Bundle bundle = getArguments();	
		String url = (String) bundle.get(Constants.URL_KEY);

		setupWebPage(view, url);
		
		return view;
	}

	private void setupWebPage(View view, String url) {
		browser = (WebView) view.findViewById(R.id.webView);
		browser.setWebViewClient(new ArticleBrowser());
		browser.getSettings().setLoadsImagesAutomatically(true);
		browser.getSettings().setJavaScriptEnabled(true);
		browser.setScrollBarStyle(View.SCROLLBARS_INSIDE_OVERLAY);
		browser.loadUrl(url);
	}
}
