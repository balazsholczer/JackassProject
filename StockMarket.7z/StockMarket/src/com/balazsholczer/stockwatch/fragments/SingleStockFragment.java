package com.balazsholczer.stockwatch.fragments;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import android.app.ProgressDialog;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.balazsholczer.stockwatch.R;
import com.balazsholczer.stockwatch.callbacks.StockDownloadCallback;
import com.balazsholczer.stockwatch.model.Stock;
import com.balazsholczer.stockwatch.service.StockHistoryDataDownloader;
import com.balazsholczer.stockwatch.utils.Constants;
import com.balazsholczer.stockwatch.utils.DialogBuilder;
import com.jjoe64.graphview.GraphView;
import com.jjoe64.graphview.GraphView.GraphViewData;
import com.jjoe64.graphview.GraphViewSeries;
import com.jjoe64.graphview.LineGraphView;

public class SingleStockFragment extends Fragment implements StockDownloadCallback{

	private TextView growingRateTextView;
	private TextView firmNameTextView;
	private List<String> stockDates;
	private List<String> stockPrices;
	private String currentStockSymbol;
	private String companyName;
	private View view;
	private ImageView growingImageView;
	private ProgressDialog progressDialog;

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,Bundle savedInstanceState) {

		View view = inflater.inflate(R.layout.single_currency_fragment,container, false);
		this.view=view;
		
		firmNameTextView = (TextView) view.findViewById(R.id.firmNameTextView);
		growingImageView = (ImageView) view.findViewById(R.id.growingImageView);
		growingRateTextView = (TextView) view.findViewById(R.id.growingRateTextView);
		
		progressDialog = DialogBuilder.buildProgressDialog(getActivity(), "Download", "Downloading data...");
		
		Bundle bundle = getArguments();
		Stock stockCurrency = (Stock) bundle.get(Constants.KEY_DATA_FRAGMENTS);
		
		currentStockSymbol=stockCurrency.getSymbolOnStockMarket();
		companyName = stockCurrency.getCompanyName();

		downloadHistoricalData();	
		
		return view;
	}

	private void setupGraph(View view) {
			
		GraphViewData[] data = new GraphViewData[stockPrices.size()];	
		String[] years = {"2010","2011","2012","2013","2014"};
		
		for (int i = 0; i < stockPrices.size(); i++) {	
			data[i] = new GraphViewData(i,Double.parseDouble(stockPrices.get(i)));
		}
		
		GraphViewSeries randomWalkSeries = new GraphViewSeries("Stock Volatility", null, data);
		GraphView graphView = new LineGraphView(getActivity(), "Volatility");
		graphView.addSeries(randomWalkSeries);
		
		graphView.setScalable(true);
		graphView.setShowLegend(true);
		
		graphView.setHorizontalLabels(years);		
		
		LinearLayout layout = (LinearLayout) view.findViewById(R.id.subLayout);
		layout.addView(graphView);	
	}
	
	private void downloadHistoricalData(){	
		
		progressDialog.show();
		
		StockHistoryDataDownloader stockDownloader = new StockHistoryDataDownloader(this);
		stockDownloader.execute(currentStockSymbol);
	}

	@Override
	public void downloadSuccess(List<String> stockDates,List<String> stockPrices) {
		this.stockDates=stockDates; 
		this.stockPrices=stockPrices;
		Collections.reverse(stockPrices);
		Collections.reverse(stockDates);
			
		decideGrowingRate(stockPrices);
		
		setupGraph(view);
		
		progressDialog.dismiss();
	}

	private void decideGrowingRate(List<String> stockPrices) {
		double laterPrice = Double.parseDouble(stockPrices.get(stockPrices.size()-1));
		double beforePrice = Double.parseDouble(stockPrices.get(stockPrices.size()-2));
		
		if( (laterPrice - beforePrice) > 0 ){
			growingImageView.setImageBitmap(BitmapFactory.decodeResource(getResources(), R.drawable.rise));
		}else{
			growingImageView.setImageBitmap(BitmapFactory.decodeResource(getResources(), R.drawable.fall));	
		}
		
		double finalValue = (Math.floor((laterPrice-beforePrice)/beforePrice*10000))/100;
		
		growingRateTextView.setText("Growing rate: "+ (finalValue)+
				"%\nCurrent price: "+stockPrices.get(stockPrices.size()-1)+
				"$\nInterval: "+stockDates.get(0)+"  -  "+stockDates.get(stockDates.size()-1)+
				"\nHighest: "+findingMaximum()+
				"$\nLowest: "+findingMinimum()+"$");
		
		firmNameTextView.setText(companyName);	
	}
	
	public double findingMinimum(){
		double min = Double.parseDouble(stockPrices.get(0));
		
		for(int i=0;i<stockPrices.size();i++){
			if( Double.parseDouble(stockPrices.get(i)) < min ){
				min=Double.parseDouble(stockPrices.get(i));
			}
		}
		
		return min;
	}
	
	public double findingMaximum(){
		double max = Double.parseDouble(stockPrices.get(0));
		
		for(int i=0;i<stockPrices.size();i++){
			if( Double.parseDouble(stockPrices.get(i)) > max ){
				max=Double.parseDouble(stockPrices.get(i));
			}
		}
		
		return max;
	}

	@Override
	public void downloadFailure() {
		
	}
}
