package com.balazsholczer.stockwatch.activities;

import com.balazsholczer.stockwatch.R;
import com.balazsholczer.stockwatch.fragments.ArticleFragment;
import com.balazsholczer.stockwatch.fragments.SingleStockFragment;
import com.balazsholczer.stockwatch.model.Stock;
import com.balazsholczer.stockwatch.utils.Constants;

import android.app.ActionBar;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;

public class NewsActivity extends FragmentActivity{

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.fragment_container);
		
		getActionBar().setNavigationMode(ActionBar.NAVIGATION_MODE_STANDARD);
		
		Intent intent = getIntent();
		String url = (String) intent.getExtras().getString(Constants.URL_KEY);
		
		navigateToSingleArticleFragment(url);	
	}

	private void navigateToSingleArticleFragment(String url) {	
		ArticleFragment articleFragment = new ArticleFragment();	
		Bundle bundle = new Bundle();
		bundle.putString(Constants.RSS_URL, url);	
		articleFragment.setArguments(bundle);	
		getFragmentManager().beginTransaction().addToBackStack(null).replace(R.id.fragmentContainer, articleFragment).commit();
	}
}
