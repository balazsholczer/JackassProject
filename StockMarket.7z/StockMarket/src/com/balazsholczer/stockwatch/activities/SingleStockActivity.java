package com.balazsholczer.stockwatch.activities;

import android.app.ActionBar;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.util.Log;

import com.balazsholczer.stockwatch.R;
import com.balazsholczer.stockwatch.fragments.SingleStockFragment;
import com.balazsholczer.stockwatch.model.Stock;
import com.balazsholczer.stockwatch.utils.Constants;

public class SingleStockActivity extends FragmentActivity{

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.fragment_container);
		
		getActionBar().setNavigationMode(ActionBar.NAVIGATION_MODE_STANDARD);
		
		Intent intent = getIntent();
		Stock stock = (Stock) intent.getSerializableExtra(Constants.KEY_DATA_POSITION);
		
		navigateToSingleStockFragment(stock);
		
	}

	private void navigateToSingleStockFragment(Stock stock) {
		Bundle bundle = new Bundle();
		bundle.putSerializable(Constants.KEY_DATA_STOCK,stock);
		SingleStockFragment singleStockFragment = new SingleStockFragment();
		singleStockFragment.setArguments(bundle);
			
		getFragmentManager().beginTransaction().addToBackStack(null).replace(R.id.fragmentContainer, singleStockFragment).commit();
	}
}
