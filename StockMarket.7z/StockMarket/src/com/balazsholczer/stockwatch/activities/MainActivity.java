package com.balazsholczer.stockwatch.activities;

import android.app.ActionBar;
import android.app.ActionBar.Tab;
import android.app.ActionBar.TabListener;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.support.v4.view.ViewPager;
import android.support.v4.view.ViewPager.OnPageChangeListener;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.Window;
import android.widget.Toast;

import com.balazsholczer.stockwatch.R;
import com.balazsholczer.stockwatcher.adapters.ScrollTabAdapter;

public class MainActivity extends FragmentActivity implements TabListener{

	private ActionBar actionBar;
    private ViewPager viewPager;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_INDETERMINATE_PROGRESS);
		setContentView(R.layout.fragment_container);
        
		getActionBar().setNavigationMode(ActionBar.NAVIGATION_MODE_TABS);	
		
        setupViewPager();
        setupSwipeTabs();     	
	}

	private void setupViewPager() {
		viewPager = (ViewPager) findViewById(R.id.myViewPager);
        viewPager.setAdapter(new ScrollTabAdapter(getSupportFragmentManager()));
            
        viewPager.setOnPageChangeListener(new OnPageChangeListener() {       
            @Override
            public void onPageSelected(int position) {
                actionBar.setSelectedNavigationItem(position);
            }           
            @Override
            public void onPageScrolled(int arg0, float arg1, int arg2) {}
            @Override
            public void onPageScrollStateChanged(int arg0) {}
        });
	}
	
	public void setupSwipeTabs(){
		actionBar = getActionBar();
        actionBar.setNavigationMode(ActionBar.NAVIGATION_MODE_TABS);
        
        ActionBar.Tab tab1 = actionBar.newTab();
        tab1.setTabListener(this);
        tab1.setText("Stock Market");
        
        ActionBar.Tab tab2 = actionBar.newTab();
        tab2.setTabListener(this);   
        tab2.setText("News");
      
        actionBar.addTab(tab1);
        actionBar.addTab(tab2);   
	}
	
	@Override
    public boolean onCreateOptionsMenu(Menu menu) {
        return false;
    }
 
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {            
        return false;
    }
	
	@Override
	public void onTabSelected(Tab tab, android.app.FragmentTransaction ft) {
		viewPager.setCurrentItem(tab.getPosition());
	}

	@Override
	public void onTabUnselected(Tab tab, android.app.FragmentTransaction ft) {	}

	@Override
	public void onTabReselected(Tab tab, android.app.FragmentTransaction ft) {	}
}
