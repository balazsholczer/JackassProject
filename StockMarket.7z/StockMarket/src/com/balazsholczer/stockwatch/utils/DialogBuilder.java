package com.balazsholczer.stockwatch.utils;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;

import com.balazsholczer.stockwatch.R;

public class DialogBuilder {

	public static void showAlertDialog(Context context, String title, String message, Boolean status) {
        
		AlertDialog alertDialog = new AlertDialog.Builder(context).create();
        alertDialog.setTitle(title);
        alertDialog.setMessage(message);      
        alertDialog.setIcon(R.drawable.error);
   
        alertDialog.setButton("OK", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
            }
        });
 
        alertDialog.show();
    }
	
	public static ProgressDialog buildProgressDialog(Context context, String title,String message){
	
		ProgressDialog progressDialog = new ProgressDialog(context);
		progressDialog.setTitle(title);
		progressDialog.setIndeterminate(true);
		progressDialog.setIcon(R.drawable.donwload_icon);
		progressDialog.setMessage(message);
		
		return progressDialog;
	
	}

}
