package com.balazsholczer.stockwatch.utils;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.xml.sax.SAXException;

import android.util.Log;

import com.balazsholczer.stockwatch.model.RssItem;


public class RssReader {
	
	private String rssUrl;
	
	public RssReader(String rssUrl) {
		this.rssUrl = rssUrl;
	}

	public List<RssItem> getItems()  {
		
		try {
			SAXParserFactory factory = SAXParserFactory.newInstance();
			SAXParser saxParser;
			saxParser = factory.newSAXParser();
			
			RssParseHandler handler = new RssParseHandler();
			saxParser.parse(rssUrl, handler);
			
			return handler.getItems();
	
		} catch (ParserConfigurationException | SAXException | IOException e) {
			Log.e("----------------",""+e.getMessage());
		}	
		
		return new ArrayList<>();
	}
}
