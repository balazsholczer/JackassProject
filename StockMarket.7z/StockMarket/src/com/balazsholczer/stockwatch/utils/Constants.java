package com.balazsholczer.stockwatch.utils;

public class Constants {

	public static final String RESPONSE_STRING = "response_string";
	public static final String PROCESS_RESPONSE = "process_response";
	public static final String ACTION_RESP = "action_resp";
	public static final String KEY_DATA_FRAGMENTS = "key_data_fragments";
	public static final String BASE_URL_FIRST = "http://ichart.yahoo.com/table.csv?s=";
	public static final String BASE_URL_LAST = "&a=0&b=1&c=2010";
	public static final String URL_KEY = "url_key";
	public static final String RSS_URL = "http://articlefeeds.nasdaq.com/nasdaq/categories?category=Economy";
	public static final int DATE_ID = 0;
	public static final int CLOSE_PRICE_ID = 4;
	public static final int STOCK_FRAGMENT_ID = 0;
	public static final int NEWS_FRAGMENT_ID = 1;	
	
}
