package com.balazsholczer.stockwatch.service;

public class SingleStockDataDownloader {


	
}
