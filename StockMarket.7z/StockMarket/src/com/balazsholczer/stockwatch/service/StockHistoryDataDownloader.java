package com.balazsholczer.stockwatch.service;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.List;

import android.os.AsyncTask;
import android.util.Log;

import com.balazsholczer.stockwatch.callbacks.StockDownloadCallback;
import com.balazsholczer.stockwatch.utils.Constants;

public class StockHistoryDataDownloader extends AsyncTask<String, Void, Void> {

	private List<String> stockDates;
	private List<String> stockPrices;
	private StockDownloadCallback callback;

	public StockHistoryDataDownloader(StockDownloadCallback callback) {
		this.callback = callback;
	}

	@Override
	protected Void doInBackground(String... params) {

		try {

			stockDates = new ArrayList<>();
			stockPrices = new ArrayList<>();

			String currentStockSymbol = params[0];

			String line = "";
			String cvsSplitBy = ",";
			InputStream input;

			Calendar calendar = new GregorianCalendar();

			int year = calendar.get(Calendar.YEAR);
			int month = calendar.get(Calendar.MONTH);
			int dayOfMonth = calendar.get(Calendar.DAY_OF_MONTH);

			Log.e("----------------------------",calendar.get(Calendar.YEAR)+"-"+calendar.get(Calendar.MONTH)+"-"+calendar.get(Calendar.DAY_OF_MONTH));
			
			input = new URL(Constants.BASE_URL_FIRST + currentStockSymbol+ Constants.BASE_URL_LAST + "&d=" + month + "&e="
					+ dayOfMonth + "&f=" + year + "&g=w&ignore=.csv").openStream();
			Reader reader = new InputStreamReader(input, "UTF-8");

			BufferedReader bufferedReader = new BufferedReader(reader);

			while ((line = bufferedReader.readLine()) != null) {
				String[] stock = line.split(cvsSplitBy);

				if (!stock[Constants.DATE_ID].equals("Date")) {
					stockDates.add(stock[Constants.DATE_ID]);
				}

				if (!stock[Constants.CLOSE_PRICE_ID].equals("Close")) {
					stockPrices.add(stock[Constants.CLOSE_PRICE_ID]);
				}
			}

		} catch (MalformedURLException e) {
			e.printStackTrace();
			callback.downloadFailure();
		} catch (IOException e) {
			e.printStackTrace();
			callback.downloadFailure();
		}
		return null;
	}

	@Override
	protected void onPostExecute(Void result) {
		super.onPostExecute(result);
		callback.downloadSuccess(stockDates, stockPrices);
	}
}
