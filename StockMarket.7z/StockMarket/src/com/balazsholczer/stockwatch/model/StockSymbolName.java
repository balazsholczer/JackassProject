package com.balazsholczer.stockwatch.model;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

public class StockSymbolName {

	private Map<String, String > stockSymbolAndName = new HashMap<String, String>(){{
        put("AAPL","Apple Inc.");
        put("BAC","Bank Of America Corporation");
        put("PFE","Pfizer Inc.");
        put("FB","Facebook Inc.");
        put("MSFT","Microsoft Corporation");
        put("CSCO","Cisco Systems, Inc.");
        put("GE","General Electric Company");
        put("INTC","Intel Corporation");
        put("BBRY","Blackberry Limited");
        put("AMD","Advanced Micro Devices, Inc");
        put("SCOK","SinoCoking Coal Chemical Industries");
        put("SIRI","Sirius XM Holdings Inc.");
        put("SUNE","SunEdison, Inc");
        put("IBM","International Business Machines Corporation");
        put("MU","Micron Technology, Inc");
        put("RF","Regions Financial Corporation");
        put("VALE","Vale S.A.");
        put("NCR","NCR Corp.");
        put("DAL","Delta Air Lines, Inc");
        put("F","Ford Motor CO.");
        put("ABBV","AbbVie Inc.");
        put("YHOO","Yahoo! Inc.");
        put("TWTR","Twitter, Inc.");
        put("KO","The Coca-Cola Company");
        put("ORCL","Oracle Corporation");
        put("EMC","EMC Corporation");
        put("JCP","J. C. Penney Company, Inc.");
        put("T","AT&T, Inc.");
        put("GOOGL","Google, Inc.");
        put("AA","Alcoa Inc.");
        put("FOXA","Twenty-First Century Fox, Inc.");
        put("HPQ","Hewlett-Packard Company");     
        put("C","Citigroup Inc."); 
        put("GS"," Goldman Sachs Group Inc.");   
        put("MER","Merrill Lynch & Co.");
        put("MS","Morgan Stanley");
        put("JPM","JPMorgan Chase & Co.");
    }};
    
    public String findKeyByValue(String value){
    	for (Entry<String, String> entry : stockSymbolAndName.entrySet()) {
            if (entry.getValue().equals(value)) {
               return entry.getKey();
            }
        }
    	
    	return null;
    }
    
    public String findValueByKey(String key){
    	return stockSymbolAndName.get(key);
    }
    
    public Map<String,String> getMap(){
    	return this.stockSymbolAndName;
    }
}
