package com.balazsholczer.stockwatch.model;

import java.io.Serializable;

import com.google.gson.annotations.SerializedName;

public class Stock implements Serializable {

	@SerializedName("id")
	private String id;
	
	private String companyName;
	
	@SerializedName("t")
	private String symbolOnStockMarket;
	
	@SerializedName("e")
	private String providerName; // pl: NASDAQ
	
	@SerializedName("l")
	private String price;
	
	@SerializedName("c")
	private String changeInPrice;
	
	@SerializedName("cp")
	private String changeInPercent;

	public Stock() {

	}

	public Stock(String id, String companyName, String symbolOnStockMarket,String providerName, String price, String changeInPrice,String changeInPercent) {
		this.id = id;
		this.companyName = companyName;
		this.symbolOnStockMarket = symbolOnStockMarket;
		this.providerName = providerName;
		this.price = price;
		this.changeInPrice = changeInPrice;
		this.changeInPercent = changeInPercent;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public String getSymbolOnStockMarket() {
		return symbolOnStockMarket;
	}

	public void setSymbolOnStockMarket(String symbolOnStockMarket) {
		this.symbolOnStockMarket = symbolOnStockMarket;
	}

	public String getProviderName() {
		return providerName;
	}

	public void setProviderName(String providerName) {
		this.providerName = providerName;
	}

	public String getPrice() {
		return price;
	}

	public void setPrice(String price) {
		this.price = price;
	}

	public String getChangeInPrice() {
		return changeInPrice;
	}

	public void setChangeInPrice(String changeInPrice) {
		this.changeInPrice = changeInPrice;
	}

	public String getChangeInPercent() {
		return changeInPercent;
	}

	public void setChangeInPercent(String changeInPercent) {
		this.changeInPercent = changeInPercent;
	}

	@Override
	public String toString() {
		return "Stock [id=" + id + ", companyName=" + companyName
				+ ", symbolOnStockMarket=" + symbolOnStockMarket
				+ ", providerName=" + providerName + ", price=" + price
				+ ", changeInPrice=" + changeInPrice + ", changeInPercent="
				+ changeInPercent + "]";
	}
}
