package com.balazsholczer.stockwatch.model;

import java.util.ArrayList;
import java.util.List;

public enum Database {

	INSTANCE;
	
	private List<Stock> stockDatabase = new ArrayList<>();
	
	public void addStock(Stock stock){
		this.stockDatabase.add(stock);
	}
	
	public List<Stock> getStocks(){
		return this.stockDatabase;
	}
	
	public void clearDatabase(){
		this.stockDatabase.clear();
	}
}
