package com.balazsholczer.stockwatcher.adapters;

import java.util.ArrayList;
import java.util.List;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.TextView;

import com.balazsholczer.stockwatch.R;
import com.balazsholczer.stockwatch.model.Stock;


public class StockAdapter extends BaseAdapter implements Filterable {

    private List<Stock> stockList;
    private Context context;
    private List<Stock> updatedCurrencies;
    
    public StockAdapter(Context context,List<Stock> currencies){        
        this.context=context;    
        this.stockList=currencies;   
        this.updatedCurrencies = new ArrayList<Stock>();
    }

	public void refreshCurrencies(List<Stock> currencyList){
    	this.stockList=currencyList;
    	notifyDataSetChanged();
    }
    
    @Override
    public int getCount() {      
        return stockList.size();
    }

    @Override
    public Object getItem(int position) {      
        return stockList.get(position);
    }

    @Override
    public long getItemId(int position) {      
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {  
     
        View row = convertView;
        ViewHolder holder = null;
        
        if( row == null ){
            LayoutInflater layoutInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);           
            row = layoutInflater.inflate(R.layout.single_stock_listitem_layout, parent,false);         
            holder = new ViewHolder(row);
            row.setTag(holder);
        }else{
            holder = (ViewHolder) row.getTag();
        }
        
        Stock currentStock = stockList.get(position);
        holder.getFirmName().setText(currentStock.getCompanyName());
        holder.getFirmIdentifier().setText(currentStock.getSymbolOnStockMarket());
        holder.getFirmName().setTag(currentStock.getCompanyName());
        
        return row;
    }
    
    private class ViewHolder {

    	private TextView companyName;
    	private TextView companySymbol;

    	ViewHolder(View view) {
    		companyName = (TextView) view.findViewById(R.id.companyNameTextView);
    		companySymbol = (TextView) view.findViewById(R.id.companyIdentifierTextView);
    	}

    	public TextView getFirmName() {
    		return companyName;
    	}

    	public TextView getFirmIdentifier() {
    		return companySymbol;
    	}
    }

	@Override
	public Filter getFilter() {
		
		Filter filter = new Filter() {
			
			@Override
			protected void publishResults(CharSequence constraint, FilterResults results) {
				updatedCurrencies = (List<Stock>) results.values;
	            notifyDataSetChanged();
			}
			
			@Override
			protected FilterResults performFiltering(CharSequence constraint) {
				 FilterResults results = new FilterResults();
	                
				 List<Stock> filteredList = new ArrayList<Stock>();

	                // perform your search here using the searchConstraint String.

	                constraint = constraint.toString().toLowerCase();
	                for (int i = 0; i < stockList.size(); i++) {
	                    Stock actualStock = stockList.get(i);
	                    if (actualStock.getCompanyName().toLowerCase().startsWith(constraint.toString()))  {
	                    	filteredList.add(actualStock);
	                    }
	                }

	                results.count = filteredList.size();
	                results.values = filteredList;
	                Log.e("VALUES", results.values.toString());

	                return results;
			}
		};
		
		return filter;
	}
}
