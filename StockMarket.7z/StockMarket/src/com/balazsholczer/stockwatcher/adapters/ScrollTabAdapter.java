package com.balazsholczer.stockwatcher.adapters;

import com.balazsholczer.stockwatch.fragments.ArticlesListFragment;
import com.balazsholczer.stockwatch.fragments.StockListFragment;
import com.balazsholczer.stockwatch.utils.Constants;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;

public class ScrollTabAdapter extends FragmentStatePagerAdapter {

    public ScrollTabAdapter(FragmentManager fragmentManager) {
        super(fragmentManager);     
    }

    @Override
    public Fragment getItem(int arg) {
     
        switch (arg) {
        case Constants.STOCK_FRAGMENT_ID:
            return new StockListFragment();
        case Constants.NEWS_FRAGMENT_ID:
            return new ArticlesListFragment();
        default: return null;
        }
    }

    @Override
    public int getCount() {
        return 2;
    }
    
    @Override
    public CharSequence getPageTitle(int position) {
        switch (position) {
        case Constants.STOCK_FRAGMENT_ID:
            return "Stock Market";
        case Constants.NEWS_FRAGMENT_ID:
            return "News";
        default: return null;
        }
    }
}
