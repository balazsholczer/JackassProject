package com.balazsholczer.stockwatcher.adapters;

import java.util.List;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;
import com.balazsholczer.stockwatch.R;
import com.balazsholczer.stockwatch.model.RssItem;

public class RssAdapter extends BaseAdapter {

	private List<RssItem> rssItems;
	private Context context;

	public RssAdapter(Context context, List<RssItem> rssItems) {
		this.context = context;
		this.rssItems = rssItems;
	}

	@Override
	public int getCount() {
		return rssItems.size();
	}

	@Override
	public Object getItem(int position) {
		return rssItems.get(position);
	}

	@Override
	public long getItemId(int position) {
		return position;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {

		View row = convertView;
		ViewHolder holder = null;

		if (row == null) {
			LayoutInflater layoutInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			row = layoutInflater.inflate(R.layout.single_rss_listitem_layout,parent, false);
			holder = new ViewHolder(row);
			row.setTag(holder);
		} else {
			holder = (ViewHolder) row.getTag();
		}

		RssItem currentRssItem = rssItems.get(position);
		holder.getRssTitle().setText(currentRssItem.getTitle());
		holder.getRssPublicationDate().setText(currentRssItem.getPublicationDate());

		return row;
	}

	private class ViewHolder {

		private TextView rssTitle;
		private TextView rssPublicationDate;

		ViewHolder(View view) {
			rssTitle = (TextView) view.findViewById(R.id.rssTitle);
			rssPublicationDate = (TextView) view.findViewById(R.id.rssPublicationDate);
		}

		public TextView getRssPublicationDate() {
			return rssPublicationDate;
		}
		
		public TextView getRssTitle() {
			return rssTitle;
		}
	}
}