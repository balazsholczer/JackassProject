package com.example.videostreaming;

import android.app.Activity;
import android.net.Uri;
import android.os.Bundle;
import android.widget.MediaController;
import android.widget.VideoView;

public class MainActivity extends Activity {

	private VideoView vidView;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		// http://code.tutsplus.com/tutorials/streaming-video-in-android-apps--cms-19888
		// ugyanezt meg lehetne csinalni egy SurfaceView-vel es MediaPlayer segitsegevel
		
		vidView = (VideoView)findViewById(R.id.myVideo);
		
		String vidAddress = "https://archive.org/download/ksnn_compilation_master_the_internet/ksnn_compilation_master_the_internet_512kb.mp4";
		Uri vidUri = Uri.parse(vidAddress);
		vidView.setVideoURI(vidUri);
		
		MediaController mediaController = new MediaController(this);
		mediaController.setAnchorView(vidView);
		
		vidView.setMediaController(mediaController);
		
		vidView.start();
		
	}
}
