package com.example.androidjsonserverdatabase;

import java.util.List;

import org.w3c.dom.Text;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.example.interfaces.DownloadUsersCallback;

public class MainActivity extends Activity implements DownloadUsersCallback{

    private TextView textView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        textView = (TextView) findViewById(R.id.users_id);
        
    }
    
    
    public void loadUsers(View view){
        UserDownloader userDownloader = new UserDownloader();
        userDownloader.setListener(this);
        userDownloader.execute();
    }
   
    public void addUser(View view) {
        Intent intent = new Intent(this,AddUserActivity.class);
        startActivity(intent);
    }


    @Override
    public void downloadUsersSuccess(List<User> users) {
        Toast.makeText(this, "Count: "+users.size(), Toast.LENGTH_SHORT).show();
        
        for(User user : users){
            textView.append(user.getUsername()+" - "+user.getPassword()+"\n");
        }
        
    }
}
