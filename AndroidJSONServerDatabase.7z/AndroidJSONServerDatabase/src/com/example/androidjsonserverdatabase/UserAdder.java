package com.example.androidjsonserverdatabase;

import java.util.ArrayList;
import java.util.List;

import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.protocol.HTTP;
import org.apache.http.util.EntityUtils;

import com.example.interfaces.AddUserCallback;

import android.content.Context;
import android.os.AsyncTask;
import android.util.Log;
import android.widget.EditText;
import android.widget.Toast;

public class UserAdder extends AsyncTask<String, Void, Void> {

    private Context context;
    private AddUserCallback listener;

    public UserAdder(Context context) {
        this.context = context;
    }

    @Override
    protected Void doInBackground(String... params) {

        try {

            List<NameValuePair> postParams = new ArrayList<NameValuePair>(2);
            postParams.add(new BasicNameValuePair("username", params[0]));
            postParams.add(new BasicNameValuePair("password", params[1]));

            HttpClient client = new DefaultHttpClient();
            HttpPost post = new HttpPost("http://holczerbalazs.esy.es/insert.php");
            UrlEncodedFormEntity entity = new UrlEncodedFormEntity(postParams);
            entity.setContentEncoding(HTTP.UTF_8);
            post.setEntity(entity);

            HttpResponse res = client.execute(post);
            String responseString = EntityUtils.toString(res.getEntity(), "UTF-8");

        } catch (Exception e) {
            Log.e("-----------------------------", e.toString());

        }

        return null;
    }

    @Override
    protected void onPostExecute(Void result) {
        listener.addUserToDatabaseSuccess();
        super.onPostExecute(result);
    }

    public void setAddUserListener(AddUserCallback listener) {
        this.listener = listener;
    }
}
