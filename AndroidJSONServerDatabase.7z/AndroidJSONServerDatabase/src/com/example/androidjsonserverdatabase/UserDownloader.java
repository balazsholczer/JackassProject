package com.example.androidjsonserverdatabase;

import java.util.ArrayList;
import java.util.List;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;

import android.os.AsyncTask;

import com.example.interfaces.DownloadUsersCallback;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

public class UserDownloader extends AsyncTask<Void, Void, Void>{

    private DownloadUsersCallback listener;
    private List<User> users = new ArrayList<User>();

    @Override
    protected Void doInBackground(Void... params) {
      
        try{
            
            HttpClient client = new DefaultHttpClient();
            HttpGet post = new HttpGet("http://holczerbalazs.esy.es/getdata.php");         
            HttpResponse response = client.execute(post);
            String jsonResponse = EntityUtils.toString(response.getEntity(), "UTF-8");
                    
            users = new Gson().fromJson(jsonResponse, new TypeToken<List<User>>() {}.getType());                   
            
        }catch(Exception e){
            
        }
        
        return null;
    }

    @Override
    protected void onPostExecute(Void result) {
      listener.downloadUsersSuccess(users);
      super.onPostExecute(result);
    }

    public void setListener(DownloadUsersCallback listener) {
        this.listener=listener;
    }

}
