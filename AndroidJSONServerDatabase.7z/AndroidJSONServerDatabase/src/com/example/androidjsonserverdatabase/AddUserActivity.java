package com.example.androidjsonserverdatabase;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import com.example.interfaces.AddUserCallback;

public class AddUserActivity extends Activity implements AddUserCallback{

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_user);
    }

    public void addUser(View view){
        
        EditText username = (EditText) findViewById(R.id.adduser_username_id);
        EditText password = (EditText) findViewById(R.id.adduser_password_id);
        
        UserAdder userAdder = new UserAdder(getApplicationContext());
        userAdder.setAddUserListener(this);
        userAdder.execute(username.getText().toString(),password.getText().toString());
    }

    @Override
    public void addUserToDatabaseSuccess() {
        Intent intent = new Intent(this,MainActivity.class);
        startActivity(intent);
    }
}
