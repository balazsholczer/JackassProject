package com.example.interfaces;

public interface AddUserCallback {
    public void addUserToDatabaseSuccess();
}
