package com.example.interfaces;

import java.util.List;

import com.example.androidjsonserverdatabase.User;

public interface DownloadUsersCallback {
    public void downloadUsersSuccess(List<User> users);
}
