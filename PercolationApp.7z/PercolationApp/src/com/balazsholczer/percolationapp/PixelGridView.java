package com.balazsholczer.percolationapp;

import java.util.Random;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;

public class PixelGridView extends View {
	
	private int numberOfColumns;
	private int numberOfRows;
	private int cellWidth;
	private int cellHeight;
	private Paint blackPaint;
	private boolean[][] cellChecked;

	public PixelGridView(Context context) {
		this(context, null);
	}

	public PixelGridView(Context context, AttributeSet attrs) {
		super(context, attrs);
		
		setWillNotDraw(false);
		blackPaint = new Paint();
		blackPaint.setStyle(Paint.Style.FILL_AND_STROKE);
	}

	@Override
	protected void onSizeChanged(int width, int height, int oldWidth, int oldHeight) {
		super.onSizeChanged(width, height, oldWidth, oldHeight);
		calculateDimensions();
	}

	private void calculateDimensions() {
		
		if (numberOfColumns == 0 || numberOfRows == 0) return;

		cellWidth = getWidth() / numberOfColumns;
		cellHeight = getHeight() / numberOfRows;

		cellChecked = new boolean[numberOfColumns][numberOfRows];

		invalidate();
	}
	
	public void simulation(){	
			
		this.cellChecked[5][5] = true;							
		invalidate();
		
		if(cellChecked[5][5]) Log.e("-----","It is true...");
	}

	@Override
	protected void onDraw(Canvas canvas) {
		super.onDraw(canvas);

		canvas.drawColor(Color.WHITE);
		
		Log.e("************","Invalidated called...");

		if (numberOfColumns == 0 || numberOfRows == 0) return;

		int width = getWidth();
		int height = getHeight();

		for (int i = 0; i < numberOfColumns; i++) {			
			for (int j = 0; j < numberOfRows; j++) {			
				if (this.cellChecked[5][5]) {
					Log.e("Adatok a dupla for ciklusban: ",""+i+"-"+j);
					canvas.drawRect(i * cellWidth, j * cellHeight, (i + 1) * cellWidth, (j + 1) * cellHeight, blackPaint);
				}
			}
		}

		for (int i = 1; i < numberOfColumns; i++) {
			canvas.drawLine(i * cellWidth, 0, i * cellWidth, height, blackPaint);
		}

		for (int i = 1; i < numberOfRows; i++) {
			canvas.drawLine(0, i * cellHeight, width, i * cellHeight, blackPaint);
		}
	}

//	@Override
//	public boolean onTouchEvent(MotionEvent event) {
//		
//		if (event.getAction() != MotionEvent.ACTION_DOWN) return true;
//
//		int column = (int) (event.getX() / cellWidth);
//		int row = (int) (event.getY() / cellHeight);
//
//		cellChecked[column][row] = !cellChecked[column][row];
//		invalidate();
//
//		return true;
//	}
	
	public void setNumColumns(int numColumns) {
		this.numberOfColumns = numColumns;
		calculateDimensions();
	}

	public int getNumColumns() {
		return numberOfColumns;
	}

	public void setNumRows(int numRows) {
		this.numberOfRows = numRows;
		calculateDimensions();
	}

	public int getNumRows() {
		return numberOfRows;
	}
}
