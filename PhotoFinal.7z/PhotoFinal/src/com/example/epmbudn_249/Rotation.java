package com.example.epmbudn_249;

public enum Rotation {

	RIGHT,LEFT,NONE;
	
}
