/** Automatically generated file. DO NOT MODIFY */
package com.balazsholczer.differentialequations;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}