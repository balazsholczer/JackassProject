package com.balazsholczer.differentialequations;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.widget.LinearLayout;

import com.jjoe64.graphview.GraphView;
import com.jjoe64.graphview.GraphView.GraphViewData;
import com.jjoe64.graphview.GraphViewSeries;
import com.jjoe64.graphview.LineGraphView;

public class RungeKutta

extends Activity {

	private double dx = 0.2;
	private double x = 0;
	private double y = 1;
	private double k1;
	private double k2;
	private double k3;
	private double k4;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		GraphViewData[] dataSet = new GraphViewData[150];

		for(int count = 0; count < 150; count++){
			
			k1 = f2(x,y);
			Log.e("--------------","k1 "+k1);
			
			k2 = f2(x+dx/2,y+k1*dx/2);
			Log.e("--------------","k2 "+k2);
			
			k3 = f2(x+dx/2,y+k2*dx/2);
			Log.e("--------------","k3 "+k3);
			
			k4 = f2(x+dx,y+k3*dx);
			Log.e("--------------","k4 "+k4);
			
			y = y + (1/6.f)*(k1+2*k2+2*k3+k4)*dx;
			
			x += dx;

			Log.e("-------------","x:"+x+" - y:"+y);
			Log.e("--------------","End of results...");
			
			dataSet[count++] = new GraphViewData(x,y);
		}

//		GraphViewSeries randomWalkSeries = new GraphViewSeries("z(t)", null,dataSet);
//		GraphView graphView = new LineGraphView(this, "Oscillator");
//		graphView.addSeries(randomWalkSeries);
//
//		graphView.setViewPort(-10, 10);
//
//		graphView.setScalable(true);
//		graphView.setShowLegend(true);
//
//		LinearLayout layout = (LinearLayout) findViewById(R.id.subLayout);
//		layout.addView(graphView);

	}

	public double f(double x, double y) {
		return 0.5 * x + 1.75 - 0.75 * Math.exp(-2 * x);
	}
	
	public double f2(double x, double y) {
		return -2*y+x+4;
	}
}
