package com.balazsholczer.differentialequations;

import java.util.Arrays;
import java.util.Random;

import com.jjoe64.graphview.GraphView;
import com.jjoe64.graphview.GraphViewSeries;
import com.jjoe64.graphview.LineGraphView;
import com.jjoe64.graphview.GraphView.GraphViewData;
import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.LinearLayout;

public class MainActivity extends Activity {

	private double k = 0.5;
	private double v = 0;
	private double V = 0;
	private double t = 0;
	private double dt = 0.1;
	private double x = 1;
	private double y = 2;
	private int count = 0;
	private double b = 0.01;
	private double r = 1;
	private double alpha=0.2;
	private double betha=0.2;
	private double gamma=0.2;
	private double delta=0.2;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		GraphViewData[] dataSet = new GraphViewData[500];
		
		while( t < 50 ){		
			v=v+f(x)*dt;
			x=x+v*dt;
			t=t+dt;
			
			dataSet[count++] = new GraphViewData(t,x);
		}
		
		
		GraphViewSeries randomWalkSeries = new GraphViewSeries("z(t)", null, dataSet);
		GraphView graphView = new LineGraphView(this, "Oscillator");
		graphView.addSeries(randomWalkSeries);
		
		graphView.setViewPort(-10, 10);
		
		graphView.setScalable(true);
		graphView.setShowLegend(true);

		LinearLayout layout = (LinearLayout) findViewById(R.id.subLayout);
		layout.addView(graphView);

	}

	public double f(double x) { // oscillator without friction
		return -k*x;
	}
	
	public double f2(double x,double v) { // oscillator with friction
		return -k*x-b*v;
	}
	
	public double f3(double x){ // exponential function such as compounded interests in Black-Scholes model
		return r*x;
	}
	
	public double f4(double x,double y){
		return x*(alpha-betha*y);
	}
	
	public double f5(double x,double y){
		return -y*(gamma-delta*x);
	}
	
	public double f6(double x, double y){
		return 0.5*x+1.75-0.75*Math.exp(-2*x);
	}
}
