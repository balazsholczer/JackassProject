package FourierTransform;

public class App {

	/**
	 * 	N*N time complexity elvileg -> gyakorlatilag meg lehet tenni N*logN time complexityvel ez a FFT
	 * 	Fontos alkalmazasi terulet a differencialegyenletek megoldasanal, foleg ha periodikus hatarfeltetel is van 
	 * 		pl: Poisson egyenletnel vagy nemlinearis Schrodinger egyenletnel 
	 * 
	 * 	Alapelv: adott hullamot fel lehet bontani kolun frekvenciaju hullamok szuperpozicioira
	 * 	- fel lehet igy imserni a periodikus dolgokat + ezek erosseget mindig -> trendeket lehet igy megallapitani akar weatherben vagy economicsban 
	 * 
	 */
	
	public static void main(String[] args) {
		
		

	}
}
