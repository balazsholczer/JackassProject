package RandomSampling;

public class App {

	/**
	 * 	Ha merjuk a gravitacios konstanst, celszeru tobbszor elvegezni a kiserletet a szoras miatt: az adatsor atlaga lesz a tenyleges ertek a szoras a pontossagot
	 * 	definialja altalaban !!!
	 * 	
	 * 	atlag = 1/n sum( xi )
	 * 
	 *  variancia = 1/(n-1) * sum ( xi - atlag )^2
	 *  
	 *  Ahogy noveljuk a minta n szamat, egy normalis eloszlast fog mutatni az atlag, ahol az atlag maga a keresett ertek (gravitacios g konstans) 
	 *  	95%os konfidencia intervallum -> 1.96 * szoras/sqrt(n) 
	 *  		- a konfidenciaintervallum meri a meresunk bizonytalansagat: ami azt jelenti, hogy ha sokszor megismeteljuk a kiserletet, akkor 95%ban a kapott ertek
	 *  			 at adott intervallumba fog esni 
	 *  		- 1.96: mivel annak a valószínűsége, hogy egy veletlen random valtozo -1.96 es +1.96 kozott van pont 95%
	 *  			Ha 90% vagy 99%os bizonyossagot akarunk: akkor ez a 1.96 valtozni fog ertelemszeruen 
	 *  		- ha kicsi az n elemszam: akkor a Student t eloszlasat kell hasznalni: akkor 1.96 helyett 2.06 lesz 
	 * 
	 * 	
	 * 
	 */
	
	private static int[] data = {1,2,3,4,5,6};
	private static double mean;
	
	public static void main(String[] args) {
		
		System.out.println(mean);
		calculateVariance();
		
	}
	
	public static void calculateMean(){
		
		double sum = 0;
		
		for(int i=0;i<data.length;i++){
			sum+=data[i];
		}
		
		mean =  sum/data.length;
		
	}
	
	public static void calculateVariance(){
		
		double xxbar = 0.0;
        for (int i = 0; i < data.length; i++) {
            xxbar += (data[i] - mean) * (data[i] - mean);
        }
        double variance = xxbar / (data.length - 1);
        double stddev = Math.sqrt(variance);
        double lo = mean - 1.96 * stddev;
        double hi = mean + 1.96 * stddev;
        
        System.out.println("Standard deviation: "+stddev);
		
	}
}
