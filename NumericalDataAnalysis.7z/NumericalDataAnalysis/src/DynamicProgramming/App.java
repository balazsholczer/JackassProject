package DynamicProgramming;

import java.math.BigInteger;
import java.util.ArrayList;

public class App {

	private static ArrayList<BigInteger> fibonacciCache = new ArrayList<BigInteger>();

	static {
		fibonacciCache.add(BigInteger.ZERO);
		fibonacciCache.add(BigInteger.ONE);
	}

	public static void main(String[] args) {
		
		    for (int i=0; i<=46; i++)
		        System.out.print(calculateFibanacci(i)+", ");
		

	}

	public static BigInteger calculateFibanacci(int n) {
		if (n >= fibonacciCache.size()) {
			fibonacciCache.add(n,
					calculateFibanacci(n - 1).add(calculateFibanacci(n - 2)));
		}
		return fibonacciCache.get(n);
	}
}